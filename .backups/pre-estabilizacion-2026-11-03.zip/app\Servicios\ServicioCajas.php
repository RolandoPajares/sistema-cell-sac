<?php

namespace App\Servicios;

use App\Models\Finanzas\Caja;
use App\Models\Organizacion\Sede;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ServicioCajas
{
    public function __construct(
        private readonly ServicioAutorizacion $authorization,
        private readonly RegistradorAuditoria $audit,
    ) {}

    /** @param array{sede_id:int,codigo:string,nombre:string} $data */
    public function crear(array $data, User $actor, ?string $ip): Caja
    {
        $this->assertAdministrator($actor, 'gestion.pagos.crear');

        return DB::transaction(function () use ($data, $actor, $ip): Caja {
            $site = Sede::query()->whereKey($data['sede_id'])->where('activa', true)->lockForUpdate()->firstOrFail();
            $this->assertSite($actor, $site, 'gestion.pagos.crear');
            $code = Str::upper(trim($data['codigo']));
            $name = trim($data['nombre']);
            abort_unless($code !== '' && $name !== '', 422, 'El código y nombre de la caja son obligatorios.');
            abort_if(Caja::query()->where('sede_id', $site->id)->where('codigo', $code)->lockForUpdate()->exists(),
                422, 'Ya existe una caja con ese código en la sede.');
            $box = Caja::query()->create([
                'sede_id' => $site->id, 'codigo' => $code, 'nombre' => $name,
                'activa' => true, 'creado_en' => now(),
            ]);
            $this->audit->record((int) $actor->getKey(), 'caja.creada', 'cajas', (int) $box->getKey(),
                null, ['sede_id' => $site->id, 'codigo' => $code, 'nombre' => $name, 'activa' => true],
                $ip, scope: ['empresa_id' => (int) $site->empresa_id, 'sede_id' => (int) $site->id]);

            return $box;
        }, 3);
    }

    /** @param array{sede_id:int,codigo:string,nombre:string} $data */
    public function actualizar(Caja $box, array $data, User $actor, ?string $ip): Caja
    {
        $this->assertAdministrator($actor, 'gestion.pagos.actualizar');

        return DB::transaction(function () use ($box, $data, $actor, $ip): Caja {
            $locked = Caja::query()->whereKey($box->getKey())->lockForUpdate()->firstOrFail();
            $site = Sede::query()->whereKey($locked->sede_id)->lockForUpdate()->firstOrFail();
            $this->assertSite($actor, $site, 'gestion.pagos.actualizar');
            abort_unless((int) $data['sede_id'] === (int) $locked->sede_id, 422, 'La sede de una caja existente no puede cambiarse.');
            $code = Str::upper(trim($data['codigo']));
            $name = trim($data['nombre']);
            abort_unless($code !== '' && $name !== '', 422, 'El código y nombre de la caja son obligatorios.');
            if ($locked->codigo === $code && $locked->nombre === $name) {
                return $locked;
            }
            abort_if($this->hasOpenSession($locked), 409, 'Cierra la sesión de caja antes de editar sus datos.');
            abort_if(Caja::query()->where('sede_id', $site->id)->where('codigo', $code)
                ->whereKeyNot($locked->getKey())->lockForUpdate()->exists(), 422, 'Ya existe una caja con ese código en la sede.');
            $before = $locked->only(['codigo', 'nombre']);
            $locked->update(['codigo' => $code, 'nombre' => $name]);
            $this->audit->record((int) $actor->getKey(), 'caja.actualizada', 'cajas', (int) $locked->getKey(),
                $before, $locked->only(['codigo', 'nombre']), $ip,
                scope: ['empresa_id' => (int) $site->empresa_id, 'sede_id' => (int) $site->id]);

            return $locked;
        }, 3);
    }

    public function cambiarEstado(Caja $box, bool $active, User $actor, ?string $ip): Caja
    {
        $this->assertAdministrator($actor, 'gestion.pagos.actualizar');

        return DB::transaction(function () use ($box, $active, $actor, $ip): Caja {
            $locked = Caja::query()->whereKey($box->getKey())->lockForUpdate()->firstOrFail();
            $site = Sede::query()->whereKey($locked->sede_id)->lockForUpdate()->firstOrFail();
            $this->assertSite($actor, $site, 'gestion.pagos.actualizar');
            if ($locked->activa === $active) {
                return $locked;
            }
            abort_if(! $active && $this->hasOpenSession($locked), 409, 'Cierra la sesión de caja antes de desactivarla.');
            $locked->update(['activa' => $active]);
            $this->audit->record((int) $actor->getKey(), $active ? 'caja.activada' : 'caja.desactivada',
                'cajas', (int) $locked->getKey(), ['activa' => ! $active], ['activa' => $active], $ip,
                scope: ['empresa_id' => (int) $site->empresa_id, 'sede_id' => (int) $site->id]);

            return $locked;
        }, 3);
    }

    private function assertAdministrator(User $actor, string $permission): void
    {
        abort_unless($this->authorization->hasRole($actor, 'administrador'), 403);
        $this->authorization->assertAllowed($actor, $permission);
    }

    private function assertSite(User $actor, Sede $site, string $permission): void
    {
        abort_unless($site->activa && (int) $site->empresa_id === $this->authorization->activeCompanyId()
            && $this->authorization->allowsRecord($actor, $permission, (int) $site->empresa_id, (int) $site->id), 403);
    }

    private function hasOpenSession(Caja $box): bool
    {
        return DB::table('sesiones_caja')->where('caja_id', $box->getKey())->where('estado', 'abierta')->exists();
    }
}
