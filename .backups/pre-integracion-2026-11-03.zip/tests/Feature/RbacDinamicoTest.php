<?php

use App\Models\User;
use App\Servicios\ServicioAutorizacion;
use App\Servicios\ServicioDelegacion;
use App\Servicios\ServicioMenuDinamico;
use Database\Seeders\RbacInicialSeeder;
use Illuminate\Support\Facades\DB;

it('seeds the seven existing roles and organization idempotently', function (): void {
    $this->seed(RbacInicialSeeder::class);
    $this->seed(RbacInicialSeeder::class);

    $roleCodes = DB::table('roles')->orderBy('codigo')->pluck('codigo')->all();
    $expectedRoleCodes = User::ROLES;
    sort($roleCodes);
    sort($expectedRoleCodes);

    expect($roleCodes)->toBe($expectedRoleCodes)
        ->and(DB::table('roles')->count())->toBe(7)
        ->and(DB::table('empresas')->where('codigo', 'TECHCELL')->count())->toBe(1)
        ->and(DB::table('sedes')->where('codigo', 'PRINCIPAL')->count())->toBe(1)
        ->and(DB::table('almacenes')->where('codigo', 'PRINCIPAL')->count())->toBe(1)
        ->and(DB::table('permisos')->count())->toBe(165)
        ->and(DB::table('permisos')->where('codigo', 'gestion.seguridad.actualizar')->exists())->toBeTrue();
});

it('does not restore revoked privileges or overwrite customized menus on a repeat seed', function (): void {
    User::factory()->create(['rol' => 'marketing']);
    $this->seed(RbacInicialSeeder::class);

    $marketingRoleId = DB::table('roles')->where('codigo', 'marketing')->value('id');
    $campaignPermissionId = DB::table('permisos')->where('codigo', 'gestion.campanias.consultar')->value('id');
    $marketingMenuId = DB::table('menus')->where('codigo', 'marketing.sidebar')->value('id');
    $campaignMenuItem = DB::table('elementos_menu')
        ->where('menu_id', $marketingMenuId)
        ->where('codigo', 'item.admin.campaigns')
        ->first();

    DB::table('rol_permiso')->where('rol_id', $marketingRoleId)->where('permiso_id', $campaignPermissionId)->delete();
    DB::table('elementos_menu')->where('id', $campaignMenuItem->id)->update([
        'etiqueta' => 'Campañas revisadas',
        'habilitado' => false,
    ]);

    $this->seed(RbacInicialSeeder::class);

    expect(DB::table('rol_permiso')->where('rol_id', $marketingRoleId)->where('permiso_id', $campaignPermissionId)->exists())->toBeFalse()
        ->and(DB::table('elementos_menu')->where('id', $campaignMenuItem->id)->value('etiqueta'))->toBe('Campañas revisadas')
        ->and(DB::table('elementos_menu')->where('id', $campaignMenuItem->id)->value('habilitado'))->toBe(0);
});

it('restricts assigned employee permissions to their company site and customer permissions to owned records', function (): void {
    $marketingUser = User::factory()->create(['rol' => 'marketing']);
    $customer = User::factory()->create(['rol' => 'cliente_minorista']);
    $otherCustomer = User::factory()->create(['rol' => 'cliente_minorista']);
    $this->seed(RbacInicialSeeder::class);

    $companyId = DB::table('empresas')->where('codigo', 'TECHCELL')->value('id');
    $principalSiteId = DB::table('sedes')->where('empresa_id', $companyId)->where('codigo', 'PRINCIPAL')->value('id');
    $otherCompanyId = DB::table('empresas')->insertGetId([
        'codigo' => 'OTRA',
        'razon_social' => 'Otra empresa de prueba',
        'moneda_base' => 'PEN',
        'activo' => true,
        'created_at' => now(),
        'updated_at' => now(),
    ]);
    $otherSiteId = DB::table('sedes')->insertGetId([
        'empresa_id' => $companyId,
        'codigo' => 'SECUNDARIA',
        'nombre' => 'Sede de prueba sin asignación',
        'zona_horaria' => 'America/Lima',
        'activa' => true,
        'created_at' => now(),
        'updated_at' => now(),
    ]);
    $otherCompanySiteId = DB::table('sedes')->insertGetId([
        'empresa_id' => $otherCompanyId,
        'codigo' => 'PRINCIPAL',
        'nombre' => 'Sede de otra empresa',
        'zona_horaria' => 'America/Lima',
        'activa' => true,
        'created_at' => now(),
        'updated_at' => now(),
    ]);

    $authorization = app(ServicioAutorizacion::class);
    $delegation = app(ServicioDelegacion::class);
    $campaignPermissionId = DB::table('permisos')->where('codigo', 'gestion.campanias.consultar')->value('id');

    expect($authorization->allowsRecord($marketingUser, 'gestion.campanias.consultar', (int) $companyId, (int) $principalSiteId))->toBeTrue()
        ->and($authorization->allowsRecord($marketingUser, 'gestion.campanias.consultar', (int) $companyId, (int) $otherSiteId))->toBeFalse()
        ->and($authorization->allowsRecord($marketingUser, 'gestion.campanias.consultar', (int) $otherCompanyId, (int) $otherCompanySiteId))->toBeFalse()
        ->and($authorization->allowsRecord($customer, 'gestion.pedidos.consultar', (int) $companyId, (int) $principalSiteId, (int) $customer->id))->toBeTrue()
        ->and($authorization->allowsRecord($otherCustomer, 'gestion.pedidos.consultar', (int) $companyId, (int) $principalSiteId, (int) $customer->id))->toBeFalse()
        ->and($delegation->puedeDelegarPermisos($marketingUser, [(int) $campaignPermissionId], 'sede'))->toBeTrue()
        ->and($delegation->puedeDelegarPermisos($marketingUser, [(int) $campaignPermissionId], 'empresa'))->toBeFalse();

    $this->withSession(['sede_actual_id' => $otherSiteId])
        ->actingAs($marketingUser)
        ->get(route('management.campaigns'))
        ->assertForbidden();
});

it('builds role-specific menus from the database and enforces route permissions', function (): void {
    $usersByRole = collect(User::ROLES)->mapWithKeys(fn (string $role): array => [$role => User::factory()->create(['rol' => $role])]);
    $administrator = $usersByRole['administrador'];
    $marketingUser = $usersByRole['marketing'];

    $this->seed(RbacInicialSeeder::class);

    $menuService = app(ServicioMenuDinamico::class);
    $administratorMenu = $menuService->paraUsuario($administrator);
    $marketingMenu = $menuService->paraUsuario($marketingUser);
    $menusByRole = $usersByRole->map(fn (User $user): array => $menuService->paraUsuario($user));
    $administratorRoutes = collect($administratorMenu['grupos'])->flatMap(fn (array $group): array => $group['items'])->pluck('route')->all();
    $marketingRoutes = collect($marketingMenu['grupos'])->flatMap(fn (array $group): array => $group['items'])->pluck('route')->all();

    expect($menusByRole->every(fn (array $menu): bool => $menu['dinamico'] && $menu['grupos'] !== []))->toBeTrue()
        ->and(DB::table('roles_menus')->count())->toBe(7)
        ->and($administratorMenu['dinamico'])->toBeTrue()
        ->and($administratorRoutes)->toContain('management.roles_permissions')
        ->and($marketingMenu['dinamico'])->toBeTrue()
        ->and($marketingRoutes)->toContain('management.campaigns')
        ->and($marketingRoutes)->not->toContain('management.roles_permissions');

    $this->actingAs($marketingUser)->get(route('management.campaigns'))->assertOk();
    $this->actingAs($marketingUser)->get(route('management.users'))->assertForbidden();

    $campaignPermissionId = DB::table('permisos')->where('codigo', 'gestion.campanias.consultar')->value('id');
    $marketingRoleId = DB::table('roles')->where('codigo', 'marketing')->value('id');
    DB::table('rol_permiso')->where('rol_id', $marketingRoleId)->where('permiso_id', $campaignPermissionId)->delete();

    $menuAfterRevocation = app(ServicioMenuDinamico::class)->paraUsuario($marketingUser);
    $routesAfterRevocation = collect($menuAfterRevocation['grupos'])->flatMap(fn (array $group): array => $group['items'])->pluck('route')->all();

    $this->actingAs($marketingUser)->get(route('management.campaigns'))->assertForbidden();
    expect($routesAfterRevocation)->not->toContain('management.campaigns');

    $securityModuleId = DB::table('modulos')->where('codigo', 'seguridad')->value('id');
    $this->actingAs($administrator)
        ->patch(route('management.modules.update', $securityModuleId), ['habilitado' => false])
        ->assertUnprocessable();
    expect(DB::table('modulos')->where('codigo', 'seguridad')->value('habilitado'))->toBe(1);
});

it('does not expose view-only placeholders as working administrative modules', function (): void {
    $administrator = User::factory()->administrator()->create();

    $this->actingAs($administrator)->get(route('management.payments'))->assertForbidden();
});

it('preserves the last active global administrator assignment', function (): void {
    $administrator = User::factory()->administrator()->create();
    $this->seed(RbacInicialSeeder::class);
    $administratorRoleId = DB::table('roles')->where('codigo', 'administrador')->value('id');

    $this->actingAs($administrator)
        ->delete(route('management.user_assignments.revoke', [$administrator->id, $administratorRoleId]))
        ->assertUnprocessable();

    $this->assertDatabaseHas('usuario_roles', [
        'usuario_id' => $administrator->id,
        'rol_id' => $administratorRoleId,
        'activo' => true,
    ]);
});
