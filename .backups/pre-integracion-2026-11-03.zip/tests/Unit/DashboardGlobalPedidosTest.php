<?php

use App\Http\Controllers\Paneles\Administrador\DashboardGlobalPedidosController;
use App\Models\User;
use App\Servicios\ExportadorTabular;
use App\Servicios\RegistradorAuditoria;
use App\Servicios\ServicioAutorizacion;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Tests\TestCase;

uses(TestCase::class);

test('filtra pedidos reales por estado y sede en una base temporal sqlite', function () {
    Schema::create('users', function (Blueprint $table): void {
        $table->id();
        $table->string('nombre');
    });
    Schema::create('sedes', function (Blueprint $table): void {
        $table->id();
        $table->string('nombre');
    });
    Schema::create('pedidos', function (Blueprint $table): void {
        $table->increments('id');
        $table->unsignedBigInteger('usuario_id');
        $table->unsignedBigInteger('sede_id');
        $table->string('canal');
        $table->string('estado');
        $table->decimal('total', 10, 2);
        $table->timestamp('creado_en');
    });
    DB::table('users')->insert(['id' => 1, 'nombre' => 'Prueba temporal']);
    DB::table('sedes')->insert([['id' => 1, 'nombre' => 'Sede 1'], ['id' => 2, 'nombre' => 'Sede 2']]);
    DB::table('pedidos')->insert([
        ['usuario_id' => 1, 'sede_id' => 1, 'canal' => 'ecommerce', 'estado' => 'Pendiente', 'total' => 40, 'creado_en' => now()],
        ['usuario_id' => 1, 'sede_id' => 2, 'canal' => 'ecommerce', 'estado' => 'Pendiente', 'total' => 50, 'creado_en' => now()],
        ['usuario_id' => 1, 'sede_id' => 1, 'canal' => 'ecommerce', 'estado' => 'Pagado', 'total' => 60, 'creado_en' => now()],
    ]);
    $request = Request::create('/gestion/dashboard-global/pedidos', 'GET', ['periodo' => 7, 'sede' => 1, 'estado' => 'Pendiente']);
    $request->setUserResolver(static function (): User {
        $user = new User;
        $user->setRawAttributes(['id' => 1, 'rol' => 'administrador']);

        return $user;
    });

    $view = (new DashboardGlobalPedidosController)->index($request, app(ServicioAutorizacion::class));

    expect($view->getData()['orders'])->toHaveCount(1)
        ->and($view->getData()['orders']->first()->total)->toBe('40.00')
        ->and($view->getData()['byStatus']['Pendiente'])->toBe(1);
});

test('exporta pedidos y registra la operación en auditoría temporal', function () {
    Schema::create('pedidos', function (Blueprint $table): void {
        $table->increments('id');
        $table->string('estado');
        $table->decimal('total', 10, 2);
        $table->timestamp('creado_en');
    });
    Schema::create('registros_auditoria', function (Blueprint $table): void {
        $table->increments('id');
        $table->unsignedBigInteger('usuario_id')->nullable();
        $table->string('accion');
        $table->string('entidad');
        $table->integer('entidad_id')->nullable();
        $table->json('valores_anteriores')->nullable();
        $table->json('valores_nuevos')->nullable();
        $table->string('direccion_ip')->nullable();
        $table->timestamp('creado_en');
    });
    DB::table('pedidos')->insert(['estado' => 'Pagado', 'total' => 40, 'creado_en' => now()]);
    $request = Request::create('/gestion/dashboard-global/pedidos/exportar/pdf', 'GET', ['periodo' => 7]);
    $request->setUserResolver(static function (): User {
        $user = new User;
        $user->setRawAttributes(['id' => 1, 'rol' => 'administrador']);

        return $user;
    });

    $response = (new DashboardGlobalPedidosController)->export($request, 'pdf', new ExportadorTabular, app(ServicioAutorizacion::class), new RegistradorAuditoria);

    expect($response->getContent())->toStartWith('%PDF-1.4')
        ->and(DB::table('registros_auditoria')->where('accion', 'exportar')->count())->toBe(1);
});
