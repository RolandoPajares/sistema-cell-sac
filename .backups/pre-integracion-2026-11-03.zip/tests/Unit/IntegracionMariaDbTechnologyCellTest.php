<?php

use App\Models\Catalogo\Producto;
use App\Models\Comercio\Pedido;
use App\Models\User;
use App\Servicios\ServicioAutorizacion;
use App\Servicios\ServicioDelegacion;
use App\Servicios\ServicioInventario;
use App\Servicios\ServicioMenuDinamico;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Tests\TestCase;

uses(TestCase::class, DatabaseTransactions::class);

beforeEach(function (): void {
    if (getenv('TECHCELL_ISOLATED_DB_TEST') !== '1'
        || DB::getDriverName() !== 'mysql'
        || ! str_starts_with(DB::getDatabaseName(), 'tc_phaseb_')) {
        $this->markTestSkipped('Requires an explicitly selected isolated MariaDB backup copy.');
    }
});

it('loads the inherited roles and protects administrative routes with the database menu', function (): void {
    $administrator = User::query()->where('rol', 'administrador')->firstOrFail();
    $buyer = User::query()->where('rol', 'compras_logistica')->firstOrFail();
    $menu = app(ServicioMenuDinamico::class)->paraUsuario($administrator);
    $routes = collect($menu['grupos'])->flatMap(fn (array $group): array => $group['items'])->pluck('route');

    expect(DB::table('roles')->where('es_sistema', true)->count())->toBe(7)
        ->and($menu['dinamico'])->toBeTrue()
        ->and($routes)->toContain('management.roles_permissions');

    $this->actingAs($buyer)->get(route('management.users'))->assertForbidden();
    $this->actingAs($administrator)->get(route('management.roles_permissions'))->assertOk();
    $this->get(route('catalog.index'))->assertOk();
});

it('refuses a second site to unassigned employees and preserves single-site stock operations', function (): void {
    $buyer = User::query()->where('rol', 'compras_logistica')->firstOrFail();
    $companyId = (int) DB::table('empresas')->where('codigo', 'TECHCELL')->value('id');
    $secondarySiteId = DB::table('sedes')->insertGetId([
        'empresa_id' => $companyId,
        'codigo' => 'AUDIT_SECONDARY',
        'nombre' => 'Sede temporal de prueba',
        'activa' => true,
        'created_at' => now(),
        'updated_at' => now(),
    ]);

    $authorization = app(ServicioAutorizacion::class);
    $delegation = app(ServicioDelegacion::class);
    $permissionId = (int) DB::table('permisos')->where('codigo', 'gestion.seguridad.asignar')->value('id');

    expect($authorization->allowsRecord($buyer, 'gestion.compras.consultar', $companyId, $secondarySiteId))->toBeFalse()
        ->and($delegation->puedeDelegarPermisos($buyer, [$permissionId], 'empresa'))->toBeFalse();

    $this->withSession(['sede_actual_id' => $secondarySiteId])
        ->actingAs($buyer)
        ->get(route('management.purchases'))
        ->assertForbidden();

    $product = Producto::query()->where('existencias', '>', 0)->firstOrFail();
    try {
        app(ServicioInventario::class)->adjust($product, 'salida', 1, 'Prueba temporal de sede', $buyer);
        $this->fail('El inventario no debe operar con dos sedes activas.');
    } catch (HttpException $exception) {
        expect($exception->getStatusCode())->toBeIn([403, 503]);
    }
});

it('keeps ecommerce checkout and the three stock balances synchronized', function (): void {
    $customer = User::query()->where('rol', 'cliente_minorista')->firstOrFail();
    $product = Producto::query()->where('activo', true)->where('existencias', '>', 1)->orderBy('id')->firstOrFail();
    $startingStock = (int) $product->existencias;

    $this->actingAs($customer)
        ->withSession(['cart' => [$product->id => 1]])
        ->post(route('checkout'))
        ->assertRedirect();

    $order = Pedido::query()->where('usuario_id', $customer->id)->latest('id')->firstOrFail();
    $variant = DB::table('producto_variantes')->where('producto_id', $product->id)->first();
    $balance = DB::table('existencias_almacen')->where('variante_id', $variant->id)->first();

    expect($order->empresa_id)->not->toBeNull()
        ->and($order->sede_id)->not->toBeNull()
        ->and((int) $product->fresh()->existencias)->toBe($startingStock - 1)
        ->and((int) $variant->stock)->toBe($startingStock - 1)
        ->and((int) $balance->cantidad_fisica)->toBe($startingStock - 1)
        ->and(DB::table('registros_auditoria')
            ->where('entidad', 'movimientos_inventario')
            ->where('origen', 'trigger')
            ->where('usuario_id', $customer->id)
            ->exists())->toBeTrue();
});
