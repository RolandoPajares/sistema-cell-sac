<?php $__env->startSection('body_class', 'modulo-comparador'); ?>
<?php $__env->startSection('title', 'Comparador inteligente'); ?>

<?php
    $selectedIds = collect(explode(',', (string) request('seleccion')))->filter()->values();
?>

<?php $__env->startSection('content'); ?>
    <section class="smart-page">
        <div class="container">
            <div class="smart-hero">
                <span class="eyebrow">MD SmartCommerce</span>
                <h1><i class="bi bi-columns-gap" aria-hidden="true"></i> Comparador inteligente</h1>
                <p>Selecciona hasta tres celulares y compara precio, disponibilidad y SmartScore por perfil.</p>
            </div>

            <form class="panel smart-form compare-picker" method="get" id="compareForm">
                <?php for($slot = 1; $slot <= 3; $slot++): ?>
                    <label>
                        Equipo <?php echo e($slot); ?>

                        <select class="compare-select">
                            <option value="">-- Opcional --</option>
                            <?php $__currentLoopData = $availableProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($option->id); ?>" <?php if((string) $selectedIds->get($slot - 1) === (string) $option->id): echo 'selected'; endif; ?>>
                                    <?php echo e($option->marca); ?> <?php echo e($option->nombre); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>
                <?php endfor; ?>
                <input type="hidden" name="seleccion" id="compareIds" value="<?php echo e($selectedIds->implode(',')); ?>">
                <button class="btn btn-primary" type="submit">Comparar ahora</button>
            </form>

            <?php if($products->isNotEmpty()): ?>
                <div class="comparison-grid">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginalaf5c77a5fb1d7446a5608952ad32ab7b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaf5c77a5fb1d7446a5608952ad32ab7b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inteligencia.comprador.comparacion','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inteligencia.comprador.comparacion'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaf5c77a5fb1d7446a5608952ad32ab7b)): ?>
<?php $attributes = $__attributesOriginalaf5c77a5fb1d7446a5608952ad32ab7b; ?>
<?php unset($__attributesOriginalaf5c77a5fb1d7446a5608952ad32ab7b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaf5c77a5fb1d7446a5608952ad32ab7b)): ?>
<?php $component = $__componentOriginalaf5c77a5fb1d7446a5608952ad32ab7b; ?>
<?php unset($__componentOriginalaf5c77a5fb1d7446a5608952ad32ab7b); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <div class="panel comparison-empty">
                    <i class="bi bi-columns-gap"></i>
                    <h2>Selecciona los equipos que quieres comparar</h2>
                    <p>Puedes elegir hasta tres productos del catálogo para revisar sus datos en paralelo.</p>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.tienda', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\publico\catalogo\comparar.blade.php ENDPATH**/ ?>