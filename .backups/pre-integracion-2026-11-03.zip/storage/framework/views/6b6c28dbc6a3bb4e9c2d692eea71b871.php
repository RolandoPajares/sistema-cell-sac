<dialog class="tc-em__dialog" data-em-dialog aria-labelledby="tc-em-price-dialog-title">
    <div class="tc-em__dialog-card">
        <header>
            <span class="tc-em__dialog-icon"><i class="bi bi-tags"></i></span>
            <div><h2 id="tc-em-price-dialog-title" data-em-dialog-title>Configuración de precios</h2><p>Vista de diseño. La gestión real permanece en Productos.</p></div>
            <button type="button" class="tc-em__close" data-em-close aria-label="Cerrar"><i class="bi bi-x-lg"></i></button>
        </header>
        <div class="tc-em__dialog-body">
            <div class="tc-em__modal-notice"><i class="bi bi-info-circle"></i> Puedes revisar los campos; esta vista no modifica precios.</div>
            <div class="tc-em__form-grid" data-em-dialog-fields="configuracion">
                <label>Moneda principal<select><option>PEN · Sol peruano (S/)</option></select></label>
                <label>Canal predeterminado<select><option>Minorista</option><option>Mayorista</option></select></label>
                <label>Redondeo de precios<select><option>Dos decimales</option><option>Precio entero</option></select></label>
                <label>Precio mayorista mínimo<input type="number" min="0" step="0.01" placeholder="0,00"></label>
            </div>
            <div class="tc-em__form-grid" data-em-dialog-fields="masiva" hidden>
                <label>Categoría<select><option>Todas las categorías</option><option>Celulares</option><option>Accesorios</option><option>Wearables</option></select></label>
                <label>Canal<select><option>Minorista</option><option>Mayorista</option></select></label>
                <label>Tipo de ajuste<select><option>Porcentaje</option><option>Importe fijo</option></select></label>
                <label>Valor del ajuste<input type="number" step="0.01" placeholder="0,00"></label>
                <label class="tc-em__form-full">Motivo<textarea placeholder="Describe la actualización masiva…"></textarea></label>
            </div>
            <div class="tc-em__form-grid" data-em-dialog-fields="editar" hidden>
                <label class="tc-em__form-full">Producto<input type="text" data-em-dialog-product readonly></label>
                <label>Canal<select><option>Minorista</option><option>Mayorista</option></select></label>
                <label>Nuevo precio (S/)<input type="number" min="0" step="0.01" placeholder="0,00"></label>
                <label class="tc-em__form-full">Motivo<textarea placeholder="Describe el cambio de precio…"></textarea></label>
            </div>
            <div class="tc-em__form-grid" data-em-dialog-fields="detalle" hidden>
                <label class="tc-em__form-full">Producto<input type="text" data-em-dialog-product readonly></label>
                <label>Precio minorista<input type="text" data-em-detail-minorista readonly></label>
                <label>Precio mayorista<input type="text" data-em-detail-mayorista readonly></label>
                <label>Precio base<input type="text" data-em-detail-base readonly></label>
                <label>Stock de ejemplo<input type="text" data-em-detail-stock readonly></label>
            </div>
        </div>
        <footer>
            <button type="button" class="tc-em__button" data-em-close>Cancelar</button>
            <button type="button" class="tc-em__button tc-em__button--primary" data-em-demo-save>Guardar cuando se integre</button>
        </footer>
    </div>
</dialog>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\paneles\administrador\ecommerce-marketing\componentes\modal-precios.blade.php ENDPATH**/ ?>