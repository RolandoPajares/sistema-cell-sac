<?php $__env->startSection('body_class', 'modulo-catalog'); ?>
<?php $__env->startSection('title', 'Catálogo | MD Technology Cell'); ?>

<?php $__env->startSection('content'); ?>
<?php
$baseFilters = request()->except('page');
$selectedCategory = request('categoria');
$selectedBrand = request('marca');
?>
<section class="catalog-page">
    <div class="container">
        <nav class="catalog-breadcrumbs" aria-label="Ruta de navegación">
            <a href="<?php echo e(route('home')); ?>">Inicio</a><span aria-hidden="true">›</span><span aria-current="page">Catálogo</span>
        </nav>

        <div class="catalog-layout">
            <aside class="catalog-sidebar" aria-label="Filtros del catálogo">
                <section class="catalog-filter-section">
                    <h2>Categorías</h2>
                    <nav class="catalog-filter-list" aria-label="Categorías">
                        <a class="<?php echo e($selectedCategory ? '' : 'is-active'); ?>" href="<?php echo e(route('catalog.index', collect($baseFilters)->except('categoria')->all())); ?>">Todas las categorías</a>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="<?php echo e((string) $selectedCategory === (string) $category->id ? 'is-active' : ''); ?>" href="<?php echo e(route('catalog.index', array_merge($baseFilters, ['categoria' => $category->id]))); ?>"><?php echo e($category->nombre); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </nav>
                </section>

                <section class="catalog-filter-section">
                    <h2>Marca</h2>
                    <nav class="catalog-filter-list" aria-label="Marcas">
                        <a class="<?php echo e($selectedBrand ? '' : 'is-active'); ?>" href="<?php echo e(route('catalog.index', collect($baseFilters)->except('marca')->all())); ?>">Todas las marcas</a>
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="<?php echo e($selectedBrand === $brand ? 'is-active' : ''); ?>" href="<?php echo e(route('catalog.index', array_merge($baseFilters, ['marca' => $brand]))); ?>"><?php echo e($brand); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </nav>
                </section>

                <form class="catalog-price-filter" method="get" action="<?php echo e(route('catalog.index')); ?>">
                    <h2>Rango de precio</h2>
                    <input type="hidden" name="q" value="<?php echo e($query); ?>">
                    <input
                        type="hidden"
                        name="marca"
                        value="<?php echo e($selectedBrand); ?>">
                    <input
                        type="hidden"
                        name="categoria"
                        value="<?php echo e($selectedCategory); ?>">
                    <input
                        type="hidden"
                        name="orden"
                        value="<?php echo e(request('orden')); ?>">
                    <label for="catalog-min-price">Mínimo</label>
                    <input
                        class="input"
                        id="catalog-min-price"
                        name="min"
                        type="number"
                        min="0"
                        step="0.01"
                        value="<?php echo e(request('min')); ?>">
                    <label for="catalog-max-price">Máximo</label>
                    <input
                        class="input"
                        id="catalog-max-price"
                        name="max"
                        type="number"
                        min="0"
                        step="0.01"
                        value="<?php echo e(request('max')); ?>">
                    <button class="btn btn-ghost" type="submit">Aplicar</button>
                </form>
            </aside>

            <div class="catalog-content">
                <div class="catalog-toolbar">
                    <div class="catalog-heading">
                        <h1><?php echo e($selectedCategory ? $categories->firstWhere('id', (int) $selectedCategory)?->nombre : 'Catálogo'); ?></h1>
                        <p>Encuentra el celular ideal para ti.</p>
                    </div>
                    <form id="catalog-search-form" class="catalog-search" method="get" action="<?php echo e(route('catalog.index')); ?>" role="search">
                        <input type="hidden" name="marca" value="<?php echo e($selectedBrand); ?>">
                        <input type="hidden" name="categoria" value="<?php echo e($selectedCategory); ?>">
                        <input type="hidden" name="min" value="<?php echo e(request('min')); ?>">
                        <input type="hidden" name="max" value="<?php echo e(request('max')); ?>">
                        <label class="visually-hidden" for="catalog-search-input">Buscar productos</label>
                        <input class="input" id="catalog-search-input" name="q"
                            value="<?php echo e($query); ?>"
                            placeholder="Buscar celulares, marcas o modelos...">
                        <button class="btn btn-primary" type="submit" aria-label="Buscar">
                            <i class="bi bi-search" aria-hidden="true"></i>
                        </button>
                        <label class="visually-hidden" for="catalog-sort">Ordenar por</label>
                        <select id="catalog-sort" name="orden" data-catalog-sort>
                            <option value="nuevo" <?php if(request('orden')==='nuevo' ): echo 'selected'; endif; ?>>Más recientes</option>
                            <option value="precio_asc" <?php if(request('orden')==='precio_asc' ): echo 'selected'; endif; ?>>Menor precio</option>
                            <option value="precio_desc" <?php if(request('orden')==='precio_desc' ): echo 'selected'; endif; ?>>Mayor precio</option>
                            <option value="nombre" <?php if(request('orden')==='nombre' ): echo 'selected'; endif; ?>>Nombre</option>
                        </select>
                    </form>
                </div>

                <div class="product-grid catalog-product-grid">
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if (isset($component)) { $__componentOriginal12677853955b8e9c1988b3df5c2cab75 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal12677853955b8e9c1988b3df5c2cab75 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.publico.catalogo.tarjeta-producto','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('publico.catalogo.tarjeta-producto'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal12677853955b8e9c1988b3df5c2cab75)): ?>
<?php $attributes = $__attributesOriginal12677853955b8e9c1988b3df5c2cab75; ?>
<?php unset($__attributesOriginal12677853955b8e9c1988b3df5c2cab75); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal12677853955b8e9c1988b3df5c2cab75)): ?>
<?php $component = $__componentOriginal12677853955b8e9c1988b3df5c2cab75; ?>
<?php unset($__componentOriginal12677853955b8e9c1988b3df5c2cab75); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="empty panel catalog-empty">No encontramos productos con esos filtros.</div>
                    <?php endif; ?>
                </div>
                <nav class="pagination" aria-label="Paginación"><?php echo e($products->links()); ?></nav>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.tienda', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views/publico/catalogo/index.blade.php ENDPATH**/ ?>