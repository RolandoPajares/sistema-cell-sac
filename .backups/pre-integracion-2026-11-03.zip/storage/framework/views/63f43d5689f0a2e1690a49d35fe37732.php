<?php $__env->startSection('title', 'Envíos y entregas'); ?>
<?php $__env->startSection('body_class', 'modulo-envios-entregas'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('gestion.componentes.tablero-operacion', [
    'module' => require resource_path('views/gestion/envios-entregas/datos.php'),
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.administracion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\gestion\envios-entregas\listar.blade.php ENDPATH**/ ?>