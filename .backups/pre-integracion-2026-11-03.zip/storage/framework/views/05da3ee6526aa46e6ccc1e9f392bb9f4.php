<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['quotations']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['quotations']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php $__currentLoopData = $quotations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quotation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <article class="data-row">
        <div><b>Cotización #<?php echo e($quotation->id); ?> · <?php echo e($quotation->customer->nombre_contacto); ?></b><small><?php echo e($quotation->estado); ?> · <?php echo e($quotation->creado_en); ?></small></div>
        <strong>S/ <?php echo e(number_format((float) $quotation->total, 2)); ?></strong>
    </article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo e($quotations->links()); ?>

<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\components\inteligencia\cotizador\resumen.blade.php ENDPATH**/ ?>