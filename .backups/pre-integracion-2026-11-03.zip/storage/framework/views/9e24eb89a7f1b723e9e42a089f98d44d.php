<?php $__env->startSection('title', 'Gestión de cotizaciones'); ?>
<?php $__env->startSection('body_class', 'modulo-cotizaciones'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $statusClass = static fn (string $status): string => match ($status) {
            'Borrador' => 'draft',
            'Pendiente', 'Enviada' => 'pending',
            'Aprobada' => 'approved',
            'Convertida' => 'converted',
            'Rechazada', 'Vencida' => 'rejected',
            default => 'muted',
        };
    ?>

    <section class="cotizaciones-page">
        <header class="cotizaciones-hero">
            <div>
                <nav class="cotizaciones-breadcrumb" aria-label="Ruta de navegación">
                    <a href="<?php echo e(route('management.dashboard')); ?>">Administración</a>
                    <span aria-hidden="true">/</span>
                    <span>Operaciones comerciales</span>
                    <span aria-hidden="true">/</span>
                    <span aria-current="page">Cotizaciones</span>
                </nav>
                <h1>Gestión de cotizaciones</h1>
                <p>Administra las propuestas comerciales y da seguimiento a cada cotización mayorista.</p>
            </div>
            <button class="cotizaciones-primary-button" type="button" data-admin-dialog-open="nueva-cotizacion" <?php if($customers->isEmpty() || $products->isEmpty()): echo 'disabled'; endif; ?>>
                <i class="bi bi-plus-lg" aria-hidden="true"></i> Nueva cotización
            </button>
        </header>

        <section class="cotizaciones-kpi-grid" aria-label="Resumen de cotizaciones">
            <article class="cotizaciones-kpi cotizaciones-kpi--blue">
                <span class="cotizaciones-kpi-icon"><i class="bi bi-file-earmark-text" aria-hidden="true"></i></span>
                <div><small>Cotizaciones generadas</small><strong><?php echo e(number_format($totalQuotations)); ?></strong><span>Registros activos</span></div>
            </article>
            <article class="cotizaciones-kpi cotizaciones-kpi--orange">
                <span class="cotizaciones-kpi-icon"><i class="bi bi-clock-history" aria-hidden="true"></i></span>
                <div><small>Pendientes</small><strong><?php echo e(number_format($pendingQuotations)); ?></strong><span>Borradores y enviadas</span></div>
            </article>
            <article class="cotizaciones-kpi cotizaciones-kpi--green">
                <span class="cotizaciones-kpi-icon"><i class="bi bi-check-circle" aria-hidden="true"></i></span>
                <div><small>Aprobadas</small><strong><?php echo e(number_format($approvedQuotations)); ?></strong><span>Propuestas aprobadas</span></div>
            </article>
            <article class="cotizaciones-kpi cotizaciones-kpi--purple">
                <span class="cotizaciones-kpi-icon"><i class="bi bi-cash-stack" aria-hidden="true"></i></span>
                <div><small>Monto cotizado</small><strong>S/ <?php echo e(number_format($quotedTotal, 2)); ?></strong><span>Importe de cotizaciones activas</span></div>
            </article>
        </section>

        <form class="cotizaciones-filters" method="GET" action="<?php echo e(route('management.quotations')); ?>">
            <label class="cotizaciones-search">
                <i class="bi bi-search" aria-hidden="true"></i>
                <input type="search" name="buscar" value="<?php echo e($filters['buscar'] ?? ''); ?>" placeholder="Buscar cliente, código o producto..." aria-label="Buscar cotización, cliente o producto">
            </label>
            <label>
                <select name="cliente" aria-label="Cliente mayorista">
                    <option value="">Cliente: todos</option>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($customer->id); ?>" <?php if((string) ($filters['cliente'] ?? '') === (string) $customer->id): echo 'selected'; endif; ?>><?php echo e($customer->nombre_contacto); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>
            <label>
                <select name="estado" aria-label="Estado de cotización">
                    <option value="">Estado: todos</option>
                    <?php $__currentLoopData = $statusSummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status['label']); ?>" <?php if(($filters['estado'] ?? '') === $status['label']): echo 'selected'; endif; ?>><?php echo e($status['label']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>
            <label class="cotizaciones-date-filter">
                <input type="date" name="desde" value="<?php echo e($filters['desde'] ?? ''); ?>" aria-label="Fecha desde">
            </label>
            <label class="cotizaciones-date-filter">
                <input type="date" name="hasta" value="<?php echo e($filters['hasta'] ?? ''); ?>" aria-label="Fecha hasta">
            </label>
            <button class="cotizaciones-filter-button" type="submit"><i class="bi bi-funnel" aria-hidden="true"></i> Filtrar</button>
            <a class="cotizaciones-clear-button" href="<?php echo e(route('management.quotations')); ?>">Limpiar</a>
        </form>

        <section class="cotizaciones-table-card" aria-labelledby="cotizaciones-list-title">
            <header class="cotizaciones-table-header">
                <div><h2 id="cotizaciones-list-title">Listado de cotizaciones</h2><span><?php echo e(number_format($quotations->total())); ?> registros</span></div>
            </header>
            <div class="cotizaciones-table-scroll">
                <table class="cotizaciones-table">
                    <thead>
                        <tr>
                            <th scope="col">Cotización</th>
                            <th scope="col">Cliente</th>
                            <th scope="col">Tipo</th>
                            <th scope="col">Emisión</th>
                            <th scope="col">Productos</th>
                            <th scope="col">Total</th>
                            <th scope="col">Estado</th>
                            <th scope="col"><span class="visually-hidden">Acciones</span></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $quotations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quotation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $status = (string) $quotation->estado;
                                $customerName = $quotation->customer?->nombre_contacto ?? 'Cliente no disponible';
                            ?>
                            <tr>
                                <td><strong class="cotizaciones-code">COT-<?php echo e($quotation->creado_en?->format('Y') ?? now()->format('Y')); ?>-<?php echo e(str_pad((string) $quotation->id, 4, '0', STR_PAD_LEFT)); ?></strong></td>
                                <td><span class="cotizaciones-customer"><?php echo e($customerName); ?></span><small><?php echo e($quotation->customer?->documento ?? '—'); ?></small></td>
                                <td><span class="cotizaciones-type">Mayorista</span></td>
                                <td><?php echo e($quotation->creado_en?->format('d/m/Y') ?? '—'); ?></td>
                                <td><?php echo e($quotation->details_count); ?></td>
                                <td><strong>S/ <?php echo e(number_format((float) $quotation->total, 2)); ?></strong></td>
                                <td><span class="cotizaciones-status cotizaciones-status--<?php echo e($statusClass($status)); ?>"><i class="bi bi-circle-fill" aria-hidden="true"></i><?php echo e($status); ?></span></td>
                                <td>
                                    <details class="cotizaciones-row-details">
                                        <summary aria-label="Ver detalle de cotización <?php echo e($quotation->id); ?>" title="Ver detalle"><i class="bi bi-eye" aria-hidden="true"></i></summary>
                                        <div class="cotizaciones-detail-popover">
                                            <strong>Detalle de la cotización</strong>
                                            <span><?php echo e($customerName); ?> · <?php echo e($quotation->creado_en?->format('d/m/Y H:i') ?? 'Fecha no disponible'); ?></span>
                                            <ul>
                                                <?php $__currentLoopData = $quotation->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><span><?php echo e($detail->product?->nombre ?? 'Producto no disponible'); ?> × <?php echo e($detail->cantidad); ?></span><b>S/ <?php echo e(number_format((float) $detail->precio_unitario * (int) $detail->cantidad, 2)); ?></b></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                            <?php if($quotation->notas): ?>
                                                <p><?php echo e($quotation->notas); ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </details>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td class="cotizaciones-empty" colspan="8"><i class="bi bi-inbox" aria-hidden="true"></i><strong>No hay cotizaciones para mostrar</strong><span>Prueba cambiando los filtros o crea una nueva cotización.</span></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <footer class="cotizaciones-table-footer">
                <span>
                    <?php if($quotations->total() > 0): ?>
                        Mostrando <?php echo e($quotations->firstItem()); ?>–<?php echo e($quotations->lastItem()); ?> de <?php echo e($quotations->total()); ?> cotizaciones
                    <?php else: ?>
                        Sin registros
                    <?php endif; ?>
                </span>
                <?php echo e($quotations->links()); ?>

            </footer>
        </section>

        <div class="cotizaciones-bottom-grid">
            <section class="cotizaciones-summary-card">
                <header><span class="cotizaciones-summary-icon"><i class="bi bi-activity" aria-hidden="true"></i></span><div><h2>Actividad comercial reciente</h2><p>Últimas cotizaciones registradas</p></div></header>
                <?php $__empty_1 = true; $__currentLoopData = $recentQuotations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="cotizaciones-recent-row">
                        <span class="cotizaciones-recent-dot"></span>
                        <div><strong>COT-<?php echo e($recent->creado_en?->format('Y') ?? now()->format('Y')); ?>-<?php echo e(str_pad((string) $recent->id, 4, '0', STR_PAD_LEFT)); ?> · <?php echo e($recent->customer?->nombre_contacto ?? 'Cliente no disponible'); ?></strong><small><?php echo e($recent->creado_en?->format('d/m/Y') ?? 'Fecha no disponible'); ?> · S/ <?php echo e(number_format((float) $recent->total, 2)); ?></small></div>
                        <span class="cotizaciones-status cotizaciones-status--<?php echo e($statusClass((string) $recent->estado)); ?>"><?php echo e($recent->estado); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="cotizaciones-summary-empty">Las cotizaciones recientes aparecerán aquí.</p>
                <?php endif; ?>
            </section>

            <section class="cotizaciones-summary-card">
                <header><span class="cotizaciones-summary-icon cotizaciones-summary-icon--green"><i class="bi bi-pie-chart" aria-hidden="true"></i></span><div><h2>Cotizaciones por estado</h2><p>Distribución de los registros activos</p></div></header>
                <?php $__empty_1 = true; $__currentLoopData = $statusSummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="cotizaciones-status-row">
                        <div><span><?php echo e($status['label']); ?></span><strong><?php echo e(number_format($status['count'])); ?></strong></div>
                        <div class="cotizaciones-progress" role="progressbar" aria-label="<?php echo e($status['label']); ?>" aria-valuenow="<?php echo e($status['percent']); ?>" aria-valuemin="0" aria-valuemax="100"><span style="width: <?php echo e($status['percent']); ?>%"></span></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="cotizaciones-summary-empty">Aún no hay cotizaciones registradas.</p>
                <?php endif; ?>
            </section>
        </div>

        <dialog class="admin-dialog cotizaciones-create-dialog" id="nueva-cotizacion" aria-labelledby="nueva-cotizacion-title">
            <header class="admin-dialog-header">
                <div><h2 id="nueva-cotizacion-title">Nueva cotización</h2><p>Registra una propuesta para un cliente mayorista.</p></div>
                <button class="admin-dialog-close" type="button" data-admin-dialog-close aria-label="Cerrar"><i class="bi bi-x-lg" aria-hidden="true"></i></button>
            </header>
            <div class="admin-dialog-body">
                <?php if($customers->isNotEmpty() && $products->isNotEmpty()): ?>
                    <?php echo $__env->make('gestion.cotizaciones.crear', ['customers' => $customers, 'products' => $products], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php else: ?>
                    <p class="cotizaciones-summary-empty">Para crear una cotización, primero registra un cliente mayorista y al menos un producto activo.</p>
                <?php endif; ?>
            </div>
        </dialog>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.administracion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\gestion\cotizaciones\administrador.blade.php ENDPATH**/ ?>