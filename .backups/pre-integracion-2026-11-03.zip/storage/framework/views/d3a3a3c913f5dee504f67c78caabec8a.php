<?php
    $isAdministrator = auth()->user()?->isRole('administrador') ?? false;
    $brandRoute = $isAdministrator ? 'management.dashboard' : 'dashboard';
    $accountRoute = $isAdministrator ? 'management.account' : 'dashboard';
    $menuViews = [
        'administrador' => 'paneles.administrador.menu',
        'compras_logistica' => 'paneles.compras-logistica.menu',
        'marketing' => 'paneles.marketing.menu',
        'ventas_mayoristas' => 'paneles.ventas-mayoristas.menu',
        'ventas_minoristas' => 'paneles.ventas-minoristas.menu',
        'cliente_mayorista' => 'paneles.cliente-mayorista.menu',
        'cliente_minorista' => 'paneles.cliente-minorista.menu',
    ];
    $menuView = $isAdministrator ? 'paneles.administrador.menu' : ($menuViews[auth()->user()?->rol] ?? 'components.panel.menu-enlaces');
    $usesDynamicMenu = ($links['dinamico'] ?? false) === true;
?>

<aside class="admin-sidebar" id="adminSidebar" aria-label="Navegación del panel">
    <div class="admin-sidebar-brand">
        <a href="<?php echo e(route($brandRoute)); ?>" title="MD Technology Digital Cell">
            <span class="admin-brand-mark"><i class="bi bi-phone" aria-hidden="true"></i></span>
            <span class="admin-brand-copy">
                <strong>TECHNOLOGY <b>CELL</b></strong>
                <small>MD Technology Digital Cell S.A.C.</small>
            </span>
        </a>
    </div>

    <nav class="admin-sidebar-nav">
        <?php if($isAdministrator): ?>
            <?php echo $__env->make($menuView, ['links' => $links ?? []], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php elseif($usesDynamicMenu): ?>
            <?php echo app('Illuminate\Foundation\Vite')(['resources/css/paneles/administrador/index.css']); ?>
            <?php if (isset($component)) { $__componentOriginal2b4f6439bac91ed467f1d617f48da3d5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b4f6439bac91ed467f1d617f48da3d5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.panel.menu-dinamico','data' => ['menu' => $links]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel.menu-dinamico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['menu' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($links)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b4f6439bac91ed467f1d617f48da3d5)): ?>
<?php $attributes = $__attributesOriginal2b4f6439bac91ed467f1d617f48da3d5; ?>
<?php unset($__attributesOriginal2b4f6439bac91ed467f1d617f48da3d5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b4f6439bac91ed467f1d617f48da3d5)): ?>
<?php $component = $__componentOriginal2b4f6439bac91ed467f1d617f48da3d5; ?>
<?php unset($__componentOriginal2b4f6439bac91ed467f1d617f48da3d5); ?>
<?php endif; ?>
        <?php else: ?>
            <?php echo $__env->make($menuView, ['links' => $links ?? []], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
    </nav>

    <div class="admin-sidebar-footer">
        <a class="<?php echo e(request()->routeIs($accountRoute) ? 'is-active' : ''); ?>" href="<?php echo e(route($accountRoute)); ?>" title="<?php echo e($isAdministrator ? 'Configuración' : 'Mi cuenta'); ?>">
            <i class="bi bi-gear" aria-hidden="true"></i>
            <span><?php echo e($isAdministrator ? 'Configuración' : 'Mi cuenta'); ?></span>
        </a>
        <form method="post" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" title="Cerrar sesión">
                <i class="bi bi-box-arrow-right" aria-hidden="true"></i>
                <span>Cerrar sesión</span>
            </button>
        </form>
    </div>
</aside>
<?php if($isAdministrator): ?>
    <div class="admin-sidebar-resizer" data-admin-sidebar-resizer role="separator" aria-orientation="vertical" tabindex="0" aria-label="Ajustar ancho de la barra lateral" aria-controls="adminSidebar" aria-valuemin="82" aria-valuemax="480" aria-valuenow="298"></div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views/layouts/panel/menu-lateral.blade.php ENDPATH**/ ?>