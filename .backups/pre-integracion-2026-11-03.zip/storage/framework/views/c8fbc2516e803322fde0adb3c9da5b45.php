<?php $__env->startSection('title', 'Asignación de responsables'); ?>
<?php $__env->startSection('body_class', 'modulo-organizacion'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $asignaciones = [
        ['celdas' => ['Sede Principal', 'Sede', 'Oficina Central', 'Carlos Mendoza', 'Gerente de Sede', '15/09/2026', 'Asignado'], 'filtros' => ['tipo' => 'Sede', 'sede' => 'Oficina Central', 'estado' => 'Asignado']],
        ['celdas' => ['Almacén Central', 'Almacén', 'Sede Principal', 'Ana Torres', 'Jefe de Almacén', '18/09/2026', 'Asignado'], 'filtros' => ['tipo' => 'Almacén', 'sede' => 'Sede Principal', 'estado' => 'Asignado']],
        ['celdas' => ['Almacén Norte', 'Almacén', 'Sede Norte', 'Luis Rojas', 'Coordinador', '20/09/2026', 'Asignado'], 'filtros' => ['tipo' => 'Almacén', 'sede' => 'Sede Norte', 'estado' => 'Asignado']],
        ['celdas' => ['Área de Logística', 'Área', 'Sede Principal', 'María Gómez', 'Jefa de Logística', '22/09/2026', 'Asignado'], 'filtros' => ['tipo' => 'Área', 'sede' => 'Sede Principal', 'estado' => 'Asignado']],
        ['celdas' => ['Sede Norte', 'Sede', 'Sede Norte', 'Javier Salazar', 'Gerente de Sede', '10/09/2026', 'Asignado'], 'filtros' => ['tipo' => 'Sede', 'sede' => 'Sede Norte', 'estado' => 'Asignado']],
        ['celdas' => ['Área de Ventas', 'Área', 'Sede Principal', 'Elena Paredes', 'Jefa de Ventas', '12/09/2026', 'Asignado'], 'filtros' => ['tipo' => 'Área', 'sede' => 'Sede Principal', 'estado' => 'Asignado']],
        ['celdas' => ['Almacén Sur', 'Almacén', 'Sede Sur', '—', '—', '—', 'Pendiente'], 'filtros' => ['tipo' => 'Almacén', 'sede' => 'Sede Sur', 'estado' => 'Pendiente']],
        ['celdas' => ['Sede Sur', 'Sede', 'Sede Sur', 'Ricardo Vega', 'Gerente de Sede', '05/09/2026', 'Asignado'], 'filtros' => ['tipo' => 'Sede', 'sede' => 'Sede Sur', 'estado' => 'Asignado']],
        ['celdas' => ['Área de Compras', 'Área', 'Sede Principal', '—', '—', '—', 'Pendiente'], 'filtros' => ['tipo' => 'Área', 'sede' => 'Sede Principal', 'estado' => 'Pendiente']],
        ['celdas' => ['Área de TI', 'Área', 'Sede Principal', 'Daniel Castro', 'Jefe de TI', '01/09/2026', 'Asignado'], 'filtros' => ['tipo' => 'Área', 'sede' => 'Sede Principal', 'estado' => 'Asignado']],
    ];
?>
<section class="tc-org" data-organizacion="responsables">
    <?php echo $__env->make('paneles.administrador.organizacion.componentes.cabecera', ['titulo' => 'Asignación de responsables', 'icono' => 'bi-person-check', 'descripcion' => 'Asigna usuarios responsables a sedes, almacenes o áreas de la organización.', 'acciones' => [['texto' => 'Nueva asignación', 'icono' => 'bi-person-plus', 'primaria' => true, 'modal' => 'nuevo']]], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('paneles.administrador.organizacion.componentes.aviso', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="tc-org__metrics">
        <?php echo $__env->make('paneles.administrador.organizacion.componentes.metrica', ['titulo' => 'Responsables asignados', 'valor' => '24', 'icono' => 'bi-people', 'detalle' => '↑ 3 este mes'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('paneles.administrador.organizacion.componentes.metrica', ['titulo' => 'Pendientes de asignación', 'valor' => '5', 'icono' => 'bi-clock', 'tono' => 'verde', 'detalle' => '↑ 2 respecto al mes anterior'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('paneles.administrador.organizacion.componentes.metrica', ['titulo' => 'Sedes cubiertas', 'valor' => '8 / 10', 'icono' => 'bi-buildings', 'tono' => 'violeta', 'detalle' => '80 % de sedes con responsable'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('paneles.administrador.organizacion.componentes.metrica', ['titulo' => 'Reasignaciones recientes', 'valor' => '4', 'icono' => 'bi-arrow-repeat', 'detalle' => 'En los últimos 7 días'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    <?php echo $__env->make('paneles.administrador.organizacion.componentes.filtros', ['buscar' => 'Buscar por recurso, responsable, sede o cargo…', 'filtros' => [['titulo' => 'Tipo de recurso', 'campo' => 'tipo', 'todos' => 'Todos', 'opciones' => ['Sede', 'Almacén', 'Área']], ['titulo' => 'Sede', 'campo' => 'sede', 'todos' => 'Todas', 'opciones' => ['Oficina Central', 'Sede Principal', 'Sede Norte', 'Sede Sur']], ['titulo' => 'Estado', 'campo' => 'estado', 'todos' => 'Todos', 'opciones' => ['Asignado', 'Pendiente']]]], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="tc-org__grid tc-org__grid--responsibles">
        <?php echo $__env->make('paneles.administrador.organizacion.componentes.tabla', ['titulo' => 'Asignaciones de responsables', 'total' => 29, 'columnas' => ['Recurso o unidad', 'Tipo', 'Sede', 'Responsable actual', 'Cargo', 'Fecha de asignación', 'Estado'], 'filas' => $asignaciones, 'accionesFila' => ['ver' => 'detalle', 'editar' => 'reasignar']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <article class="tc-org__card tc-org__assignment"><div class="tc-org__tabs"><button class="is-active" type="button" data-org-tab="asignar">Asignar responsable</button><button type="button" data-org-tab="historial">Historial</button><button type="button" data-org-tab="niveles">Niveles de aprobación</button></div>
            <div data-org-panel="asignar"><div class="tc-org__assignment-intro"><i class="bi bi-person-check"></i><span><strong>Asignar responsable</strong><small>Selecciona un usuario responsable de una sede, almacén o área.</small></span></div><div class="tc-org__assignment-fields"><label>Recurso o unidad <span>*</span><select disabled><option>Selecciona un recurso…</option></select></label><label>Responsable <span>*</span><select disabled><option>Selecciona un usuario…</option></select></label><label>Cargo <span>*</span><input type="text" placeholder="Ej. Gerente de Sede" disabled></label><label>Fecha de asignación <span>*</span><input type="text" placeholder="Selecciona una fecha…" disabled></label></div><div class="tc-org__flow"><strong>Flujo de asignación</strong><div><span><i class="bi bi-check"></i> Solicitud</span><span><i class="bi bi-circle"></i> Revisión</span><span><i class="bi bi-circle"></i> Confirmación</span></div></div><button class="tc-org__button tc-org__button--primary tc-org__wide-button" type="button" disabled>Asignar responsable</button></div>
            <div data-org-panel="historial" hidden><div class="tc-org__assignment-intro"><i class="bi bi-clock-history"></i><span><strong>Historial de reasignaciones</strong><small>Se mostrará cuando exista el registro transaccional.</small></span></div></div>
            <div data-org-panel="niveles" hidden><div class="tc-org__assignment-intro"><i class="bi bi-layers"></i><span><strong>Niveles de aprobación</strong><small>Se configurarán cuando las políticas de delegación estén integradas.</small></span></div></div>
        </article>
    </div>
    <?php echo $__env->make('paneles.administrador.organizacion.componentes.modales', ['tipo' => 'responsables'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.administracion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\paneles\administrador\organizacion\responsables\listar.blade.php ENDPATH**/ ?>