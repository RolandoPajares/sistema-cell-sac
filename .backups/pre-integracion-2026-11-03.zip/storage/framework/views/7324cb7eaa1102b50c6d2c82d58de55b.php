<?php $__env->startSection('title', 'Datos de empresa'); ?>
<?php $__env->startSection('body_class', 'modulo-configuracion-empresa'); ?>

<?php $__env->startSection('content'); ?>
<?php ($module = require resource_path('views/gestion/configuracion-empresa/datos.php')); ?>

<?php if(auth()->user()?->rol === 'administrador'): ?>
    <?php echo $__env->make('paneles.administrador.configuracion.configuracion-empresa.listar', ['module' => $module], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('gestion.componentes.modulo-pendiente', ['module' => $module], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.administracion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\gestion\configuracion-empresa\listar.blade.php ENDPATH**/ ?>