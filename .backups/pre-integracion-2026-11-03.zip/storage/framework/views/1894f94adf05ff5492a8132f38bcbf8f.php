<?php $__env->startSection('title', 'Módulos y pantallas'); ?>
<?php $__env->startSection('content'); ?>
    <section class="admin-page">
        <header class="admin-page-head"><div><span class="eyebrow">Seguridad y delegación</span><h1>Módulos y pantallas</h1><p>El catálogo central controla qué pantallas registradas se muestran en la navegación.</p></div></header>
        <?php if (! ($ready)): ?>
            <div class="admin-alert admin-alert--error" role="status">El catálogo dinámico queda pendiente hasta aplicar las migraciones RBAC.</div>
        <?php else: ?>
            <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <section class="form-card module-registry-card"><header><div><h2><i class="bi <?php echo e($module->icono); ?>" aria-hidden="true"></i> <?php echo e($module->nombre); ?></h2><small><?php echo e($module->codigo); ?> · <?php echo e($module->habilitado ? 'Activo' : 'Inactivo'); ?></small></div><form method="post" action="<?php echo e(route('management.modules.update', $module->id)); ?>" data-confirm="¿Cambiar el estado del módulo?"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><input type="hidden" name="habilitado" value="<?php echo e($module->habilitado ? 0 : 1); ?>"><button class="btn btn-outline-primary btn-sm" type="submit" <?php if($module->codigo === 'seguridad' && $module->habilitado): echo 'disabled'; endif; ?>><?php echo e($module->habilitado ? 'Desactivar módulo' : 'Activar módulo'); ?></button></form></header>
                    <div class="table-responsive"><table class="table align-middle"><thead><tr><th>Pantalla</th><th>Ruta registrada</th><th>Estado</th><th>Acción</th></tr></thead><tbody>
                        <?php $__currentLoopData = $module->screens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $screen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr><td><?php echo e($screen->nombre); ?></td><td><?php echo e($screen->ruta ?? 'Sin ruta'); ?></td><td><?php echo e($screen->habilitada ? 'Activa' : 'Pendiente / inactiva'); ?></td><td>
                                <form method="post" action="<?php echo e(route('management.modules.screens.update', $screen->id)); ?>" data-confirm="¿Cambiar el estado de esta pantalla?">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="habilitada" value="<?php echo e($screen->habilitada ? 0 : 1); ?>">
                                    <button class="btn btn-outline-primary btn-sm" type="submit"><?php echo e($screen->habilitada ? 'Desactivar' : 'Activar'); ?></button>
                                </form>
                            </td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody></table></div>
                </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.administracion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\gestion\roles-permisos\modulos.blade.php ENDPATH**/ ?>