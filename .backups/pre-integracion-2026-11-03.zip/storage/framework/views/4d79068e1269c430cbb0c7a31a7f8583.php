<?php
    $paginas = [
        'globales' => [
            'titulo' => 'Reportes globales', 'icono' => 'bi-bar-chart-line', 'descripcion' => 'Consulta los principales indicadores comerciales y operativos del negocio.',
            'acciones' => [['Exportar', 'bi-download', 'exportar'], ['Generar reporte', 'bi-bar-chart', 'generar']],
            'metricas' => [['Ventas registradas', 'S/ 48 750,00', 'bi-cart3', 'azul'], ['Pedidos procesados', '326', 'bi-receipt', 'verde'], ['Clientes atendidos', '215', 'bi-people', 'violeta'], ['Productos activos', '1 248', 'bi-box-seam', 'ambar']],
            'filtros' => [['Periodo', 'Todos los periodos'], ['Canal', 'Todos los canales'], ['Módulo', 'Todos los módulos'], ['Estado', 'Todos los estados']],
            'tabla' => 'Resultados globales', 'columnas' => ['Indicador', 'Módulo', 'Periodo', 'Valor actual', 'Periodo anterior', 'Variación', 'Estado'],
            'filas' => [
                ['Ventas netas', 'Ventas', 'Octubre 2026', 'S/ 48 750,00', 'S/ 43 210,00', '+12,8 %', 'Disponible'],
                ['Pedidos procesados', 'Pedidos', 'Octubre 2026', '326', '298', '+9,4 %', 'Disponible'],
                ['Clientes atendidos', 'Clientes', 'Octubre 2026', '215', '203', '+6,0 %', 'Disponible'],
                ['Productos activos', 'Catálogo', 'Octubre 2026', '1 248', '1 186', '+5,2 %', 'Disponible'],
            ],
            'grafico' => 'Indicadores por área', 'barras' => [['Ventas', 88, '48 750'], ['Pedidos', 67, '326'], ['Clientes', 53, '215'], ['Catálogo', 72, '1 248']],
            'resumen' => 'Cobertura del reporte', 'resumen_filas' => [['Datos comerciales', 'Incluidos'], ['Datos de ecommerce', 'Incluidos'], ['Datos financieros', 'Pendientes de integración'], ['Datos por sede', 'Vista separada']],
        ],
        'sedes' => [
            'titulo' => 'Reportes por sede', 'icono' => 'bi-geo-alt', 'descripcion' => 'Compara el rendimiento de ventas, pedidos e inventario entre las sedes.',
            'acciones' => [['Actualizar', 'bi-arrow-clockwise', 'actualizar'], ['Exportar', 'bi-download', 'exportar'], ['Generar reporte', 'bi-bar-chart', 'generar']],
            'metricas' => [['Sedes consideradas', '4', 'bi-building', 'azul'], ['Ventas registradas', 'S/ 48 750,00', 'bi-cart3', 'verde'], ['Pedidos procesados', '326', 'bi-file-earmark-text', 'violeta'], ['Clientes atendidos', '215', 'bi-people', 'ambar']],
            'filtros' => [['Periodo', 'Todos los periodos'], ['Sede', 'Todas las sedes'], ['Tipo de informe', 'Resumen general'], ['Canal', 'Todos los canales']],
            'tabla' => 'Resultados por sede', 'columnas' => ['Sede', 'Ventas netas', 'Pedidos', 'Clientes', 'Ticket promedio', 'Variación'],
            'filas' => [
                ['Sede Principal · Lima', 'S/ 22 430,00', '152', '98', 'S/ 147,57', '+14,8 %'],
                ['Sede San Miguel', 'S/ 11 950,00', '76', '54', 'S/ 157,24', '+11,2 %'],
                ['Sede Surco', 'S/ 8 420,00', '61', '42', 'S/ 137,99', '+9,6 %'],
                ['Tienda virtual', 'S/ 5 950,00', '37', '21', 'S/ 160,81', '+18,5 %'],
            ],
            'grafico' => 'Ventas por sede', 'barras' => [['Lima', 95, '22 430'], ['San Miguel', 51, '11 950'], ['Surco', 36, '8 420'], ['Online', 25, '5 950']],
            'resumen' => 'Participación de ventas', 'resumen_filas' => [['Lima', '46,0 %'], ['San Miguel', '24,5 %'], ['Surco', '17,3 %'], ['Tienda virtual', '12,2 %']],
        ],
        'operaciones' => [
            'titulo' => 'Auditoría de operaciones', 'icono' => 'bi-shield-check', 'descripcion' => 'Consulta el registro de actividades y modificaciones realizadas en el sistema.',
            'acciones' => [['Exportar registros', 'bi-download', 'exportar'], ['Consultar historial', 'bi-clock-history', 'historial']],
            'metricas' => [['Operaciones registradas', '12 480', 'bi-file-earmark-text', 'azul'], ['Acciones exitosas', '11 950', 'bi-check-lg', 'verde'], ['Advertencias', '320', 'bi-exclamation-triangle', 'ambar'], ['Operaciones fallidas', '210', 'bi-shield-exclamation', 'rojo']],
            'filtros' => [['Usuario', 'Todos los usuarios'], ['Módulo', 'Todos los módulos'], ['Acción', 'Todas las acciones'], ['Resultado', 'Todos los resultados']],
            'tabla' => 'Registros de auditoría de operaciones', 'columnas' => ['Fecha y hora', 'Usuario', 'Módulo', 'Acción', 'Descripción', 'Dirección IP', 'Resultado'],
            'filas' => [
                ['31/10/2026 10:24', 'Administrador Demo', 'Ventas', 'Crear', 'Registró una venta de prueba', '192.0.2.15', 'Exitoso'],
                ['31/10/2026 10:18', 'Vendedor 01', 'Inventario', 'Actualizar', 'Ajustó existencias de un producto', '192.0.2.18', 'Exitoso'],
                ['31/10/2026 09:41', 'Administrador Demo', 'Roles', 'Modificar', 'Cambió privilegios de un rol', '192.0.2.15', 'Exitoso'],
                ['30/10/2026 17:26', 'Supervisor 01', 'Compras', 'Aprobar', 'Intento de aprobación sin permiso', '192.0.2.22', 'Denegado'],
                ['30/10/2026 16:04', 'Vendedor 02', 'Clientes', 'Editar', 'Actualizó información del cliente', '192.0.2.27', 'Exitoso'],
            ],
            'grafico' => 'Operaciones por módulo', 'barras' => [['Ventas', 88, '3 420'], ['Inventario', 72, '2 780'], ['Usuarios', 42, '1 630'], ['Compras', 33, '1 280'], ['Otros', 87, '3 380']],
            'resumen' => 'Resultado de operaciones', 'resumen_filas' => [['Exitosas', '11 950'], ['Advertencias', '320'], ['Fallidas', '210']],
        ],
        'roles' => [
            'titulo' => 'Historial de roles y permisos', 'icono' => 'bi-clock-history', 'descripcion' => 'Supervisa asignaciones, revocaciones y cambios de privilegios con trazabilidad.',
            'acciones' => [['Comparar cambios', 'bi-clock-history', 'comparar'], ['Exportar historial', 'bi-download', 'exportar']],
            'metricas' => [['Asignaciones registradas', '428', 'bi-people', 'azul'], ['Cambios de permisos', '124', 'bi-key', 'violeta'], ['Roles modificados', '18', 'bi-shield-check', 'verde'], ['Revocaciones', '13', 'bi-exclamation-triangle', 'ambar']],
            'filtros' => [['Usuario responsable', 'Todos los usuarios'], ['Rol afectado', 'Todos los roles'], ['Tipo de cambio', 'Todos'], ['Periodo', 'Todos los periodos']],
            'tabla' => 'Registros del historial de roles y permisos', 'columnas' => ['Fecha y hora', 'Responsable', 'Tipo de cambio', 'Usuario afectado', 'Rol / permiso', 'Descripción', 'Estado'],
            'filas' => [
                ['31/10/2026 10:23', 'Administrador Demo', 'Asignación', 'Vendedor 02', 'ventas_minoristas', 'Asignó rol a un usuario', 'Aplicado'],
                ['31/10/2026 09:18', 'Administrador Demo', 'Modificación', 'Vendedor 01', 'ventas.exportar', 'Revocó permiso de exportación', 'Aplicado'],
                ['30/10/2026 14:52', 'Supervisor 01', 'Solicitud', 'Operador 02', 'Inventario', 'Solicitó autorización adicional', 'Pendiente'],
                ['29/10/2026 11:09', 'Administrador Demo', 'Creación', '—', 'Nuevo rol auxiliar', 'Creó un rol personalizado', 'Aplicado'],
                ['28/10/2026 16:42', 'Administrador Demo', 'Revocación', 'Vendedor 03', 'Compras', 'Retiró asignación temporal', 'Aplicado'],
            ],
            'grafico' => 'Cambios por tipo', 'barras' => [['Asignaciones', 95, '128'], ['Permisos', 92, '124'], ['Roles', 14, '18'], ['Revocaciones', 10, '13']],
            'resumen' => 'Trazabilidad y controles', 'resumen_filas' => [['Eventos con responsable', '100 %'], ['Cambios con justificación', '96 %'], ['Asignaciones temporales', '18'], ['Cambios pendientes', '6']],
        ],
        'seguridad' => [
            'titulo' => 'Eventos de seguridad', 'icono' => 'bi-shield-exclamation', 'descripcion' => 'Monitorea inicios de sesión, accesos fallidos, bloqueos y alertas de seguridad.',
            'acciones' => [['Configurar alertas', 'bi-bell', 'alertas'], ['Exportar eventos', 'bi-download', 'exportar']],
            'metricas' => [['Eventos registrados', '2 410', 'bi-shield-check', 'azul'], ['Accesos exitosos', '2 320', 'bi-check-lg', 'verde'], ['Intentos fallidos', '68', 'bi-lock', 'rojo'], ['Eventos críticos', '22', 'bi-exclamation-triangle', 'ambar']],
            'filtros' => [['Tipo de evento', 'Todos los eventos'], ['Nivel de riesgo', 'Todos los niveles'], ['Usuario / IP', 'Todos los usuarios'], ['Periodo', 'Todos los periodos']],
            'tabla' => 'Registros de eventos de seguridad', 'columnas' => ['Fecha y hora', 'Evento', 'Usuario', 'Dirección IP', 'Severidad', 'Detalle', 'Resultado'],
            'filas' => [
                ['31/10/2026 10:27', 'Inicio de sesión', 'Administrador Demo', '192.0.2.15', 'Bajo', 'Autenticación correcta', 'Exitoso'],
                ['31/10/2026 09:55', 'Acceso no autorizado', 'Vendedor 01', '192.0.2.18', 'Alto', 'Permiso insuficiente', 'Denegado'],
                ['30/10/2026 17:12', 'Intentos de acceso fallidos', 'Cuenta externa', '192.0.2.80', 'Crítico', '5 intentos consecutivos', 'Bloqueado'],
                ['30/10/2026 13:09', 'Cambio de contraseña', 'Supervisor 01', '192.0.2.21', 'Medio', 'Contraseña actualizada', 'Exitoso'],
                ['29/10/2026 11:47', 'Revocación de sesión', 'Administrador Demo', '192.0.2.15', 'Bajo', 'Sesión anterior finalizada', 'Exitoso'],
            ],
            'grafico' => 'Eventos por categoría', 'barras' => [['Accesos', 95, '2 320'], ['Alertas', 14, '68'], ['Bloqueos', 8, '12'], ['Cambios', 7, '10']],
            'resumen' => 'Acciones prioritarias', 'resumen_filas' => [['Revisar accesos sospechosos', '8 eventos'], ['Validar bloqueos automáticos', '5 cuentas'], ['Verificar sesiones activas', '36 usuarios'], ['Incidentes resueltos', '14']],
        ],
        'exportaciones' => [
            'titulo' => 'Exportaciones autorizadas', 'icono' => 'bi-download', 'descripcion' => 'Controla las solicitudes, aprobaciones y descargas de información del sistema.',
            'acciones' => [['Exportar historial', 'bi-file-earmark-arrow-down', 'exportar'], ['Solicitar exportación', 'bi-plus-lg', 'solicitar']],
            'metricas' => [['Exportaciones realizadas', '146', 'bi-file-earmark-text', 'azul'], ['Autorizadas', '138', 'bi-check-lg', 'verde'], ['En revisión', '6', 'bi-clock', 'ambar'], ['Denegadas', '2', 'bi-lock', 'rojo']],
            'filtros' => [['Módulo', 'Todos los módulos'], ['Solicitante', 'Todos los usuarios'], ['Formato', 'Todos los formatos'], ['Estado', 'Todos los estados']],
            'tabla' => 'Registros de exportaciones autorizadas', 'columnas' => ['Fecha y hora', 'Solicitante', 'Módulo', 'Archivo / reporte', 'Formato', 'Registros', 'Estado'],
            'filas' => [
                ['31/10/2026 10:42', 'Administrador Demo', 'Ventas', 'ventas_octubre_2026.xlsx', 'XLSX', '1 245', 'Autorizada'],
                ['30/10/2026 15:17', 'Analista 01', 'Inventario', 'existencias_por_sede.xlsx', 'XLSX', '2 430', 'Autorizada'],
                ['30/10/2026 09:06', 'Supervisor 01', 'Clientes', 'clientes_activos.pdf', 'PDF', '846', 'En revisión'],
                ['29/10/2026 16:35', 'Vendedor 02', 'Finanzas', 'movimientos_caja.csv', 'CSV', '235', 'Denegada'],
                ['28/10/2026 12:11', 'Administrador Demo', 'Auditoría', 'eventos_seguridad.pdf', 'PDF', '135', 'Autorizada'],
            ],
            'grafico' => 'Exportaciones por área', 'barras' => [['Ventas', 95, '50'], ['Inventario', 68, '36'], ['Clientes', 47, '25'], ['Auditoría', 38, '20'], ['Finanzas', 29, '15']],
            'resumen' => 'Políticas de exportación', 'resumen_filas' => [['Exportación sujeta a permisos', 'Activada'], ['Registro de auditoría', 'Obligatorio'], ['Documentos sensibles', 'Con aprobación'], ['Retención de archivos', 'Configurable']],
        ],
    ];
    $pagina = $paginas[$tipo];
?>

<section class="tc-aa" data-analisis-auditoria>
    <nav class="tc-aa__breadcrumb" aria-label="Ruta de navegación"><i class="bi bi-house"></i><span>Análisis y Auditoría</span><i class="bi bi-chevron-right"></i><strong><?php echo e($pagina['titulo']); ?></strong></nav>
    <header class="tc-aa__header">
        <div class="tc-aa__heading"><span class="tc-aa__heading-icon"><i class="bi <?php echo e($pagina['icono']); ?>"></i></span><div><h1><?php echo e($pagina['titulo']); ?></h1><p><?php echo e($pagina['descripcion']); ?></p></div></div>
        <div class="tc-aa__actions"><?php $__currentLoopData = $pagina['acciones']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><button type="button" class="tc-aa__button <?php echo e($loop->last ? 'tc-aa__button--primary' : ''); ?>" data-aa-action="<?php echo e($accion[2]); ?>"><i class="bi <?php echo e($accion[1]); ?>"></i><?php echo e($accion[0]); ?></button><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
    </header>
    <div class="tc-aa__notice"><i class="bi bi-eye"></i><strong>Vista de diseño</strong><span>Datos ilustrativos. Las operaciones reales permanecen en los módulos actuales.</span><?php if($tipo === 'globales'): ?><a href="<?php echo e(route('management.reports')); ?>">Abrir reportes actuales <i class="bi bi-arrow-right"></i></a><?php elseif($tipo === 'operaciones'): ?><a href="<?php echo e(route('management.audit')); ?>">Abrir auditoría actual <i class="bi bi-arrow-right"></i></a><?php endif; ?></div>
    <div class="tc-aa__metrics"><?php $__currentLoopData = $pagina['metricas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metrica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><article class="tc-aa__metric tc-aa__metric--<?php echo e($metrica[3]); ?>"><span class="tc-aa__metric-icon"><i class="bi <?php echo e($metrica[2]); ?>"></i></span><div><span><?php echo e($metrica[0]); ?></span><strong><?php echo e($metrica[1]); ?></strong><small>Datos de demostración</small></div></article><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
    <section class="tc-aa__card tc-aa__filters" aria-label="Filtros de consulta"><h2><i class="bi bi-funnel"></i> Filtros de consulta</h2><div class="tc-aa__filter-grid"><?php $__currentLoopData = $pagina['filtros']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filtro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><label><?php echo e($filtro[0]); ?><select data-aa-filter="<?php echo e($loop->index); ?>"><option value=""><?php echo e($filtro[1]); ?></option><?php if($tipo === 'sedes' && $loop->index === 1): ?><option>Sede Principal · Lima</option><option>Sede San Miguel</option><option>Sede Surco</option><option>Tienda virtual</option><?php elseif($loop->index === 0): ?><option>Ventas</option><option>Inventario</option><option>Clientes</option><option>Seguridad</option><?php endif; ?></select></label><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><button type="button" class="tc-aa__button tc-aa__button--primary" data-aa-apply><i class="bi bi-search"></i> Aplicar filtros</button></div></section>
    <section class="tc-aa__card tc-aa__records"><div class="tc-aa__card-heading"><div><h2><?php echo e($pagina['tabla']); ?></h2><small>Mostrando <span data-aa-count><?php echo e(count($pagina['filas'])); ?></span> registros · Datos de demostración</small></div><span>Acciones disponibles según permisos</span></div><div class="tc-aa__table-wrap"><table><thead><tr><?php $__currentLoopData = $pagina['columnas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $columna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th><?php echo e($columna); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><th>Acciones</th></tr></thead><tbody><?php $__currentLoopData = $pagina['filas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr data-aa-row><?php $__currentLoopData = $fila; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $celda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><td><?php if($loop->last && in_array($celda, ['Autorizada', 'Disponible', 'Exitoso', 'Aplicado', 'Denegado', 'Denegada', 'Bloqueado', 'En revisión', 'Pendiente', 'Crítico', 'Alto', 'Medio', 'Bajo'], true)): ?><span class="tc-aa__badge <?php echo e(in_array($celda, ['Denegado', 'Denegada', 'Bloqueado', 'Crítico'], true) ? 'tc-aa__badge--red' : (in_array($celda, ['En revisión', 'Pendiente', 'Alto', 'Medio'], true) ? 'tc-aa__badge--amber' : '')); ?>"><?php echo e($celda); ?></span><?php else: ?><?php echo e($celda); ?><?php endif; ?></td><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><td><div class="tc-aa__row-actions"><button type="button" data-aa-detail="<?php echo e($loop->index); ?>" aria-label="Ver detalle de ejemplo"><i class="bi bi-eye"></i></button><button type="button" data-aa-detail="<?php echo e($loop->index); ?>" aria-label="Ver ficha de ejemplo"><i class="bi bi-file-earmark-text"></i></button></div></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody></table></div><p class="tc-aa__empty" data-aa-empty hidden>No hay registros de ejemplo con ese filtro.</p></section>
    <div class="tc-aa__bottom"><section class="tc-aa__card"><h2><?php echo e($pagina['grafico']); ?></h2><div class="tc-aa__chart"><?php $__currentLoopData = $pagina['barras']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div class="tc-aa__bar"><strong><?php echo e($barra[2]); ?></strong><span style="--altura: <?php echo e($barra[1]); ?>%"></span><small><?php echo e($barra[0]); ?></small></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></section><section class="tc-aa__card"><h2><?php echo e($pagina['resumen']); ?></h2><ul class="tc-aa__summary"><?php $__currentLoopData = $pagina['resumen_filas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><span><i></i><?php echo e($fila[0]); ?></span><strong><?php echo e($fila[1]); ?></strong></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></section></div>
    <dialog class="tc-aa__dialog" data-aa-dialog aria-labelledby="tc-aa-dialog-title"><div class="tc-aa__dialog-card"><header><span class="tc-aa__heading-icon"><i class="bi <?php echo e($pagina['icono']); ?>"></i></span><div><h2 id="tc-aa-dialog-title" data-aa-dialog-title>Detalle</h2><p>Vista de diseño. No se guardan cambios.</p></div><button type="button" data-aa-close aria-label="Cerrar"><i class="bi bi-x-lg"></i></button></header><div class="tc-aa__dialog-body"><div class="tc-aa__dialog-fields" data-aa-dialog-fields></div><p class="tc-aa__dialog-note">Los datos y formularios mostrados son ilustrativos; no se envían a la base de datos.</p></div><footer><button type="button" class="tc-aa__button" data-aa-close>Cancelar</button><button type="button" class="tc-aa__button tc-aa__button--primary" data-aa-dialog-confirm hidden>Continuar cuando se integre</button></footer></div></dialog>
</section>

<script type="application/json" data-aa-config><?php echo json_encode(['columnas' => $pagina['columnas'], 'filas' => $pagina['filas'], 'tipo' => $tipo]) ?></script>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views/paneles/administrador/analisis-auditoria/componentes/pagina.blade.php ENDPATH**/ ?>