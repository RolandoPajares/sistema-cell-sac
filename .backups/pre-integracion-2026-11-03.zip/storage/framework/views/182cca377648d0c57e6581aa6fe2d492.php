<?php $__env->startSection('title', 'Mis notificaciones'); ?>
<?php $__env->startSection('content'); ?>
    <section class="admin-page">
        <header class="admin-page-head"><div><span class="eyebrow">Cuenta personal</span><h1>Mis notificaciones</h1><p>Avisos asociados a tu cuenta.</p></div></header>
        <?php echo $__env->make('paneles.administrador.perfil.navegacion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php if (! ($available)): ?>
            <div class="admin-alert admin-alert--error" role="status">Las notificaciones persistentes requieren la migración de seguridad de cuenta.</div>
        <?php else: ?>
            <div class="form-card">
                <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <article class="notification-row"><div><strong><?php echo e(data_get($notification->data, 'title', class_basename($notification->type))); ?></strong><p><?php echo e(data_get($notification->data, 'message', 'Aviso del sistema')); ?></p><small><?php echo e($notification->created_at?->diffForHumans()); ?></small></div><?php if(! $notification->read_at): ?><form method="post" action="<?php echo e(route('management.account.notifications.read', $notification->id)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><button class="btn btn-outline-primary btn-sm" type="submit">Marcar como leída</button></form><?php else: ?><span class="badge text-bg-light">Leída</span><?php endif; ?></article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No tienes notificaciones.</p>
                <?php endif; ?>
                <?php echo e($notifications->links()); ?>

            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.administracion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views/paneles/administrador/perfil/notificaciones.blade.php ENDPATH**/ ?>