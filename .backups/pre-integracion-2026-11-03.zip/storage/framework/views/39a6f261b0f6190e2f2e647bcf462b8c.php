<div class="tc-dg__empty">
    <i class="bi <?php echo e($icono ?? 'bi-graph-up'); ?>" aria-hidden="true"></i>
    <strong><?php echo e($titulo ?? 'Sin datos disponibles'); ?></strong>
    <span><?php echo e($descripcion ?? 'La información aparecerá cuando este módulo esté conectado a los registros reales.'); ?></span>
</div>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\paneles\administrador\dashboard-global\componentes\vacio.blade.php ENDPATH**/ ?>