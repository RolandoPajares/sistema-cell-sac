
<?php echo app('Illuminate\Foundation\Vite')('resources/css/paneles/administrador/index.css'); ?>
<?php echo $__env->make('paneles.administrador.componentes.menu-lateral-desplegable', ['links' => $links ?? []], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\paneles\administrador\menu.blade.php ENDPATH**/ ?>