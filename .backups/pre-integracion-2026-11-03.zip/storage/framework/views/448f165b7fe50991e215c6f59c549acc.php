<nav class="profile-account-links" aria-label="Secciones de mi cuenta">
    <a href="<?php echo e(route('management.account')); ?>">Mi perfil</a>
    <a href="<?php echo e(route('management.account.security')); ?>">Seguridad</a>
    <a href="<?php echo e(route('management.account.sessions')); ?>">Sesiones activas</a>
    <a href="<?php echo e(route('management.account.preferences')); ?>">Preferencias</a>
    <a href="<?php echo e(route('management.account.notifications')); ?>">Notificaciones</a>
    <a href="<?php echo e(route('management.account.activity')); ?>">Actividad reciente</a>
</nav>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views/paneles/administrador/perfil/navegacion.blade.php ENDPATH**/ ?>