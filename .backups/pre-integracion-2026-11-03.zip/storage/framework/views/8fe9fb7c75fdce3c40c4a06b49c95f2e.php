<section class="cuenta-fondo">
    <div class="container cuenta-migas"><a href="<?php echo e(route('dashboard')); ?>">Panel</a><i class="bi bi-chevron-right"></i><span>Mi cuenta</span></div>
    <div class="container cuenta-diseno">
        <main class="cuenta-contenido">
            <header class="cuenta-banner">
                <div>
                    <span class="cuenta-banner-etiqueta"><i class="bi bi-stars"></i> Cliente <?php echo e(str_replace('cliente_', '', $role)); ?></span>
                    <h1>Tu espacio en CELL SAC</h1>
                    <p>Gestiona tus pedidos, consulta el catálogo y encuentra tu próximo equipo.</p>
                    <div class="cuenta-banner-botones">
                        <a class="cuenta-btn-blanco" href="<?php echo e(route('catalog.index')); ?>"><i class="bi bi-grid"></i> Ver catálogo</a>
                        <a class="cuenta-btn-borde" href="<?php echo e(route('recommendations')); ?>"><i class="bi bi-stars"></i> Probar SmartMatch</a>
                    </div>
                </div>
                <img src="<?php echo e(asset('assets/cell-legacy/img/publico/inicio/secciones/hero-devices.png')); ?>" alt="Celulares y accesorios">
            </header>

            <div class="cuenta-resumen">
                <article><i class="bi bi-receipt"></i><div><strong><?php echo e($orderCount); ?></strong><span>Pedidos registrados</span></div></article>
                <article><i class="bi bi-clock-history"></i><div><strong><?php echo e($pendingCount); ?></strong><span>Pedidos en proceso</span></div></article>
                <article><i class="bi bi-cart3"></i><div><strong><?php echo e($cartUnits); ?></strong><span>Unidades en carrito</span></div></article>
                <article><i class="bi bi-person-check"></i><div><strong>Activa</strong><span>Estado de cuenta</span></div></article>
            </div>

            <section class="cuenta-panel">
                <div class="cuenta-panel-titulo"><h2>Pedidos recientes</h2><a href="<?php echo e(route('orders.index')); ?>">Ver todos <i class="bi bi-chevron-right"></i></a></div>
                <div class="lista-pedidos-cuenta">
                    <?php $__empty_1 = true; $__currentLoopData = $orders->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php ($firstProduct = $order->details->first()?->product); ?>
                        <article>
                            <div class="pedido-codigo"><b>#<?php echo e($order->id); ?></b><small><?php echo e($order->creado_en?->format('d/m/Y')); ?></small></div>
                            <div class="pedido-producto"><span><i class="bi bi-phone"></i></span><div><b><?php echo e($firstProduct?->nombre ?: 'Pedido CELL SAC'); ?></b><small><?php echo e($order->details->count()); ?> producto(s)</small></div></div>
                            <span class="pedido-estado"><i class="bi bi-check-circle"></i><?php echo e($order->estado); ?></span>
                            <div class="pedido-total"><b>S/ <?php echo e(number_format((float) $order->total, 2)); ?></b><small>Total</small></div>
                            <a href="<?php echo e(route('orders.show', $order)); ?>">Ver detalle</a>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="cuenta-vacio"><i class="bi bi-receipt"></i><p>Aún no tienes pedidos registrados.</p><a class="btn btn-primary" href="<?php echo e(route('catalog.index')); ?>">Explorar catálogo</a></div>
                    <?php endif; ?>
                </div>
            </section>

            <div class="cuenta-dos-columnas">
                <section class="cuenta-panel">
                    <div class="cuenta-panel-titulo"><h2>Accesos rápidos</h2></div>
                    <div class="cuenta-accesos">
                        <a href="<?php echo e(route('orders.index')); ?>"><i class="bi bi-box-seam"></i> Mis pedidos</a>
                        <a href="<?php echo e(route('cart.index')); ?>"><i class="bi bi-cart3"></i> Mi carrito</a>
                        <a href="<?php echo e(route('comparison')); ?>"><i class="bi bi-columns-gap"></i> Comparar equipos</a>
                        <a href="<?php echo e(route('pages.contact')); ?>"><i class="bi bi-headset"></i> Contactar asesor</a>
                    </div>
                </section>
                <section class="cuenta-panel cuenta-recomendado">
                    <i class="bi bi-stars"></i>
                    <div><h2>Recomendado para ti</h2><p>Encuentra equipos según tus necesidades y presupuesto.</p><a class="btn btn-primary" href="<?php echo e(route('recommendations')); ?>">Probar SmartMatch</a></div>
                </section>
            </div>

            <div class="cuenta-dos-columnas">
                <form method="post" action="<?php echo e(route('account.profile')); ?>" class="cuenta-panel">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="cuenta-panel-titulo"><h2>Mis datos</h2></div>
                    <label>
                        Nombre
                        <input
                            name="nombre"
                            value="<?php echo e(old('nombre', auth()->user()->nombre)); ?>"
                            required
                            maxlength="120"
                        >
                    </label>

                    <label>
                        Correo
                        <input
                            type="email"
                            name="correo"
                            value="<?php echo e(old('correo', auth()->user()->correo)); ?>"
                            required
                            maxlength="160"
                        >
                    </label>
                    <button class="btn btn-primary" type="submit">Guardar datos</button>
                </form>
                <form method="post" action="<?php echo e(route('account.password')); ?>" class="cuenta-panel">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="cuenta-panel-titulo"><h2>Seguridad</h2></div>
                    <label>
                        Contraseña actual
                        <input type="password" name="password_actual" required>
                    </label>

                    <label>
                        Nueva contraseña
                        <input
                            type="password"
                            name="password"
                            required
                            minlength="10"
                        >
                    </label>

                    <label>
                        Confirmar contraseña
                        <input
                            type="password"
                            name="password_confirmation"
                            required
                        >
                    </label>
                    <button class="btn btn-primary" type="submit">Cambiar contraseña</button>
                </form>
            </div>
        </main>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views/components/comunes/dashboard-cliente.blade.php ENDPATH**/ ?>