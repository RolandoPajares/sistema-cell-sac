<?php echo $__env->make('gestion.componentes.modulo-pendiente-formulario', ['module' => $module, 'mode' => $mode], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\gestion\notificaciones\formulario.blade.php ENDPATH**/ ?>