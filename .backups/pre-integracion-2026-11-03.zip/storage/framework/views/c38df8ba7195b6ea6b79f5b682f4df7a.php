<?php $__env->startSection('title', 'Panel de ventas mayoristas'); ?>
<?php $__env->startSection('body_class', 'modulo-dashboard modulo-ventas-mayoristas'); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.comunes.dashboard-rol-interno', ['role' => 'ventas_mayoristas'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.administracion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\paneles\ventas-mayoristas\dashboard.blade.php ENDPATH**/ ?>