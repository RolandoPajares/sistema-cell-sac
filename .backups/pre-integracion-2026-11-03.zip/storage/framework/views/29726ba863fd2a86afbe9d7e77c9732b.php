<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['role' => 'bot', 'name' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['role' => 'bot', 'name' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<article class="assistant-message assistant-message-<?php echo e($role); ?>">
    <div class="assistant-message-avatar"><?php echo e($role === 'user' ? 'TÚ' : 'MD'); ?></div>
    <div class="assistant-bubble">
        <?php if($name): ?><b><?php echo e($name); ?></b><?php endif; ?>
        <?php echo e($slot); ?>

    </div>
</article>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\components\inteligencia\asistente\mensaje.blade.php ENDPATH**/ ?>