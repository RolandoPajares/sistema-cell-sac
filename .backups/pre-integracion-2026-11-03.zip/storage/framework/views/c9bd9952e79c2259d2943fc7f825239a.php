<?php $__env->startSection('body_class', 'modulo-asistente'); ?>
<?php $__env->startSection('title', 'MD Assistant'); ?>

<?php $__env->startSection('content'); ?>
    <section class="smart-page">
        <div class="container narrow">
            <div class="smart-hero">
                <span class="eyebrow">Asistente virtual del catálogo</span>
                <h1><i class="bi bi-robot" aria-hidden="true"></i> MD Assistant</h1>
                <p>Conversa con el asistente de forma continua. Puedes preguntar por precios, presupuesto, gaming, cámara, batería, estudio, trabajo o pedir recomendaciones del catálogo.</p>
            </div>

            <?php if (isset($component)) { $__componentOriginal03da490406e8bb8ef5ffc378bae61fa7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal03da490406e8bb8ef5ffc378bae61fa7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inteligencia.asistente.chat','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inteligencia.asistente.chat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal03da490406e8bb8ef5ffc378bae61fa7)): ?>
<?php $attributes = $__attributesOriginal03da490406e8bb8ef5ffc378bae61fa7; ?>
<?php unset($__attributesOriginal03da490406e8bb8ef5ffc378bae61fa7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal03da490406e8bb8ef5ffc378bae61fa7)): ?>
<?php $component = $__componentOriginal03da490406e8bb8ef5ffc378bae61fa7; ?>
<?php unset($__componentOriginal03da490406e8bb8ef5ffc378bae61fa7); ?>
<?php endif; ?>
        </div>
    </section>


    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.tienda', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views/publico/asistente/index.blade.php ENDPATH**/ ?>