<?php $__env->startSection('body_class', 'modulo-producto'); ?>
<?php $__env->startSection('title', $product->nombre.' | MD Technology Cell'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $categoryName = $product->category?->nombre ?: $product->categoria;
    $imageItems = $product->images->map(function ($image): array {
        $path = ltrim((string) preg_replace('~^assets/~', '', $image->ruta_imagen), '/');
        return ['url' => asset('assets/cell-legacy/'.$path), 'path' => $path];
    });
    $primaryImage = $imageItems->first()['url'] ?? null;
    $salePrice = (float) ($product->precio_oferta ?? $product->precio);
    $originalPrice = (float) ($product->precio_original ?? $product->precio);
    $discount = $originalPrice > $salePrice && $originalPrice > 0 ? round((1 - ($salePrice / $originalPrice)) * 100) : 0;
    $visualType = str_contains(mb_strtolower((string) $categoryName), 'audio') ? 'audio' : (str_contains(mb_strtolower((string) $categoryName), 'celular') ? 'celular' : 'accesorio');
?>
<section class="product-page-light" data-product-detail>
    <div class="container product-detail-container">
        <nav class="product-breadcrumbs" aria-label="Ruta de navegación"><a href="<?php echo e(route('home')); ?>">Inicio</a><span aria-hidden="true">›</span><a href="<?php echo e(route('catalog.index')); ?>">Catálogo</a><span aria-hidden="true">›</span><span aria-current="page"><?php echo e($product->nombre); ?></span></nav>
        <div class="product-detail-modern">
            <div class="detail-gallery" aria-label="Imágenes del producto">
                <div class="gallery-thumbs" data-gallery-thumbs <?php if(!$primaryImage): ?> hidden <?php endif; ?>>
                    <?php $__currentLoopData = $imageItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><button class="gallery-thumb <?php echo e($index === 0 ? 'active' : ''); ?>" type="button" data-src="<?php echo e($image['url']); ?>" aria-label="Ver imagen <?php echo e($index + 1); ?>" <?php if($index === 0): ?> aria-current="true" <?php endif; ?>><img src="<?php echo e($image['url']); ?>" alt=""></button><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="detail-main-image">
                    <?php if($primaryImage): ?><img data-main-product-image src="<?php echo e($primaryImage); ?>" alt="<?php echo e($product->marca); ?> <?php echo e($product->nombre); ?>"><?php endif; ?>
                    <div class="detail-product-placeholder detail-product-placeholder--<?php echo e($visualType); ?>" data-image-placeholder <?php if($primaryImage): ?> hidden <?php endif; ?> role="img" aria-label="Imagen no disponible"><span class="detail-product-icon"><strong><?php echo e($product->marca); ?></strong><i class="bi <?php echo e($visualType === 'audio' ? 'bi-headphones' : ($visualType === 'celular' ? 'bi-phone' : 'bi-box-seam')); ?>" aria-hidden="true"></i></span><span><?php echo e($product->marca); ?></span></div>
                    <button class="gallery-arrow prev" type="button" data-gallery-prev aria-label="Imagen anterior" hidden><i class="bi bi-chevron-left" aria-hidden="true"></i></button>
                    <button class="gallery-arrow next" type="button" data-gallery-next aria-label="Imagen siguiente" hidden><i class="bi bi-chevron-right" aria-hidden="true"></i></button>
                </div>
            </div>
            <div class="detail-info">
                <div class="product-detail-heading"><div class="product-detail-meta"><span><?php echo e($product->marca); ?></span><span><?php echo e($categoryName); ?></span><?php if($product->etiqueta): ?><span class="product-detail-badge"><?php echo e($product->etiqueta); ?></span><?php endif; ?></div><h1><?php echo e($product->nombre); ?></h1></div>
                <div class="product-detail-price"><strong>S/ <?php echo e(number_format($salePrice, 2)); ?></strong><?php if($discount > 0): ?><div class="product-detail-old-price"><del>S/ <?php echo e(number_format($originalPrice, 2)); ?></del><span class="product-detail-discount">-<?php echo e($discount); ?>%</span></div><?php endif; ?></div>
                <p class="product-detail-stock <?php echo e($product->existencias > 0 ? 'is-available' : 'is-unavailable'); ?>"><i class="bi <?php echo e($product->existencias > 0 ? 'bi-check-circle' : 'bi-x-circle'); ?>" aria-hidden="true"></i><?php echo e($product->existencias > 0 ? $product->existencias.' unidades disponibles' : 'Sin stock'); ?></p>
                <?php if(auth()->guard()->check()): ?>
                    <form
                        class="product-detail-cart"
                        action="<?php echo e(route('cart.add', $product)); ?>"
                        method="post"
                    >
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="cantidad" value="1">
                        <button
                            class="product-detail-buy"
                            type="submit"
                            <?php if($product->existencias <= 0): echo 'disabled'; endif; ?>
                        >
                            <i class="bi bi-cart3" aria-hidden="true"></i>
                            <?php echo e($product->existencias > 0 ? 'Agregar al carrito' : 'Sin stock'); ?>

                        </button>
                    </form>
                <?php else: ?>
                    <a class="product-detail-buy" href="<?php echo e(route('login')); ?>"><i class="bi bi-cart3" aria-hidden="true"></i>Inicia sesión para comprar</a>
                <?php endif; ?>
                <?php if($product->descripcion): ?><section class="product-detail-description"><h2>Descripción</h2><p><?php echo nl2br(e($product->descripcion)); ?></p></section><?php endif; ?>
                <?php if($product->features->isNotEmpty()): ?><section class="product-detail-specs"><h2>Información del producto</h2><ul><?php $__currentLoopData = $product->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><span><?php echo e($feature->nombre); ?></span><strong><?php echo e($feature->valor); ?></strong></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></section><?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.tienda', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\publico\catalogo\detalle.blade.php ENDPATH**/ ?>