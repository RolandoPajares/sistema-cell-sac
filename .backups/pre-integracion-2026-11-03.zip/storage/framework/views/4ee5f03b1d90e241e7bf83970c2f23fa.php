<?php $__env->startSection('title', 'Gestión de cotizaciones'); ?>
<?php $__env->startSection('body_class', 'modulo-cotizaciones'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $statusClass = static fn (string $status): string => match ($status) {
            'Borrador' => 'draft',
            'Pendiente', 'Enviada' => 'pending',
            'Aprobada' => 'approved',
            'Convertida' => 'converted',
            'Rechazada', 'Vencida' => 'rejected',
            default => 'muted',
        };
    ?>

    <section class="cotizaciones-page">
        <header class="cotizaciones-hero">
            <div>
                <nav class="cotizaciones-breadcrumb" aria-label="Ruta de navegación">
                    <a href="<?php echo e(route('management.dashboard')); ?>">Administración</a>
                    <span aria-hidden="true">/</span>
                    <span>Operaciones comerciales</span>
                    <span aria-hidden="true">/</span>
                    <span aria-current="page">Cotizaciones</span>
                </nav>
                <h1>Gestión de cotizaciones</h1>
                <p>Administra las propuestas comerciales y da seguimiento a cada cotización mayorista.</p>
            </div>
            <button class="cotizaciones-primary-button" type="button" data-admin-dialog-open="nueva-cotizacion" <?php if($customers->isEmpty() || $products->isEmpty()): echo 'disabled'; endif; ?>>
                <i class="bi bi-plus-lg" aria-hidden="true"></i> Nueva cotización
            </button>
        </header>

        <section class="cotizaciones-kpi-grid" aria-label="Resumen de cotizaciones">
            <article class="cotizaciones-kpi cotizaciones-kpi--blue">
                <span class="cotizaciones-kpi-icon"><i class="bi bi-file-earmark-text" aria-hidden="true"></i></span>
                <div><small>Cotizaciones generadas</small><strong><?php echo e(number_format($totalQuotations)); ?></strong><span>Registros activos</span></div>
            </article>
            <article class="cotizaciones-kpi cotizaciones-kpi--orange">
                <span class="cotizaciones-kpi-icon"><i class="bi bi-clock-history" aria-hidden="true"></i></span>
                <div><small>Pendientes</small><strong><?php echo e(number_format($pendingQuotations)); ?></strong><span>Borradores y enviadas</span></div>
            </article>
            <article class="cotizaciones-kpi cotizaciones-kpi--green">
                <span class="cotizaciones-kpi-icon"><i class="bi bi-check-circle" aria-hidden="true"></i></span>
                <div><small>Aprobadas</small><strong><?php echo e(number_format($approvedQuotations)); ?></strong><span>Propuestas aprobadas</span></div>
            </article>
            <article class="cotizaciones-kpi cotizaciones-kpi--purple">
                <span class="cotizaciones-kpi-icon"><i class="bi bi-cash-stack" aria-hidden="true"></i></span>
                <div><small>Monto cotizado</small><strong>S/ <?php echo e(number_format($quotedTotal, 2)); ?></strong><span>Importe de cotizaciones activas</span></div>
            </article>
        </section>

        <form class="cotizaciones-filters" method="GET" action="<?php echo e(route('management.quotations')); ?>">
            <label class="cotizaciones-search">
                <i class="bi bi-search" aria-hidden="true"></i>
                <input type="search" name="buscar" value="<?php echo e($filters['buscar'] ?? ''); ?>" placeholder="Buscar cliente, código o producto..." aria-label="Buscar cotización, cliente o producto">
            </label>
            <label>
                <select name="cliente" aria-label="Cliente mayorista">
                    <option value="">Cliente: todos</option>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($customer->id); ?>" <?php if((string) ($filters['cliente'] ?? '') === (string) $customer->id): echo 'selected'; endif; ?>><?php echo e($customer->nombre_contacto); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>
            <label>
                <select name="estado" aria-label="Estado de cotización">
                    <option value="">Estado: todos</option>
                    <?php $__currentLoopData = $statusSummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status['label']); ?>" <?php if(($filters['estado'] ?? '') === $status['label']): echo 'selected'; endif; ?>><?php echo e($status['label']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>
            <label class="cotizaciones-date-filter">
                <input type="date" name="desde" value="<?php echo e($filters['desde'] ?? ''); ?>" aria-label="Fecha desde">
            </label>
            <label class="cotizaciones-date-filter">
                <input type="date" name="hasta" value="<?php echo e($filters['hasta'] ?? ''); ?>" aria-label="Fecha hasta">
            </label>
            <button class="cotizaciones-filter-button" type="submit"><i class="bi bi-funnel" aria-hidden="true"></i> Filtrar</button>
            <a class="cotizaciones-clear-button" href="<?php echo e(route('management.quotations')); ?>">Limpiar</a>
        </form>

        <section class="cotizaciones-table-card" aria-labelledby="cotizaciones-list-title">
            <header class="cotizaciones-table-header">
                <div><h2 id="cotizaciones-list-title">Listado de cotizaciones</h2><span><?php echo e(number_format($quotations->total())); ?> registros</span></div>
            </header>
            <div class="cotizaciones-table-scroll">
                <table class="cotizaciones-table">
                    <thead>
                        <tr>
                            <th scope="col">Cotización</th>
                            <th scope="col">Cliente</th>
                            <th scope="col">Tipo</th>
                            <th scope="col">Emisión</th>
                            <th scope="col">Productos</th>
                            <th scope="col">Total</th>
                            <th scope="col">Estado</th>
                            <th scope="col"><span class="visually-hidden">Acciones</span></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $quotations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quotation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $status = (string) $quotation->estado;
                                $customerName = $quotation->customer?->nombre_contacto ?? 'Cliente no disponible';
                                $quotationReference = 'COT-' . ($quotation->creado_en?->format('Y') ?? now()->format('Y')) . '-' . str_pad((string) $quotation->id, 4, '0', STR_PAD_LEFT);
                            ?>
                            <tr>
                                <td><strong class="cotizaciones-code">COT-<?php echo e($quotation->creado_en?->format('Y') ?? now()->format('Y')); ?>-<?php echo e(str_pad((string) $quotation->id, 4, '0', STR_PAD_LEFT)); ?></strong></td>
                                <td><span class="cotizaciones-customer"><?php echo e($customerName); ?></span><small><?php echo e($quotation->customer?->documento ?? '—'); ?></small></td>
                                <td><span class="cotizaciones-type">Mayorista</span></td>
                                <td><?php echo e($quotation->creado_en?->format('d/m/Y') ?? '—'); ?></td>
                                <td><?php echo e($quotation->details_count); ?></td>
                                <td><strong>S/ <?php echo e(number_format((float) $quotation->total, 2)); ?></strong></td>
                                <td><span class="cotizaciones-status cotizaciones-status--<?php echo e($statusClass($status)); ?>"><i class="bi bi-circle-fill" aria-hidden="true"></i><?php echo e($status); ?></span></td>
                                <td>
                                    <details class="cotizaciones-row-details">
                                        <summary aria-label="Ver detalle de cotización <?php echo e($quotation->id); ?>" title="Ver detalle"><i class="bi bi-eye" aria-hidden="true"></i></summary>
                                        <div class="cotizaciones-detail-popover">
                                            <strong>Detalle de la cotización</strong>
                                            <span><?php echo e($customerName); ?> · <?php echo e($quotation->creado_en?->format('d/m/Y H:i') ?? 'Fecha no disponible'); ?></span>
                                            <ul>
                                                <?php $__currentLoopData = $quotation->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><span><?php echo e($detail->product?->nombre ?? 'Producto no disponible'); ?> × <?php echo e($detail->cantidad); ?></span><b>S/ <?php echo e(number_format((float) $detail->precio_unitario * (int) $detail->cantidad, 2)); ?></b></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                            <?php if($quotation->notas): ?>
                                                <p><?php echo e($quotation->notas); ?></p>
                                            <?php endif; ?>
                                            <div class="cotizaciones-demo-actions" aria-label="Acciones demostrativas de cotización">
                                                <?php if(in_array($status, ['Borrador', 'Pendiente'], true)): ?>
                                                    <button type="button" data-quotation-demo-action="enviar" data-reference="<?php echo e($quotationReference); ?>" data-customer="<?php echo e($customerName); ?>">Enviar cotización</button>
                                                <?php endif; ?>
                                                <?php if(in_array($status, ['Pendiente', 'Enviada'], true)): ?>
                                                    <button type="button" data-quotation-demo-action="aprobar" data-reference="<?php echo e($quotationReference); ?>" data-customer="<?php echo e($customerName); ?>">Aprobar cotización</button>
                                                <?php endif; ?>
                                                <?php if($status === 'Aprobada'): ?>
                                                    <button type="button" data-quotation-demo-action="convertir" data-reference="<?php echo e($quotationReference); ?>" data-customer="<?php echo e($customerName); ?>">Convertir en venta</button>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </details>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td class="cotizaciones-empty" colspan="8"><i class="bi bi-inbox" aria-hidden="true"></i><strong>No hay cotizaciones para mostrar</strong><span>Prueba cambiando los filtros o crea una nueva cotización.</span></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <footer class="cotizaciones-table-footer">
                <span>
                    <?php if($quotations->total() > 0): ?>
                        Mostrando <?php echo e($quotations->firstItem()); ?>–<?php echo e($quotations->lastItem()); ?> de <?php echo e($quotations->total()); ?> cotizaciones
                    <?php else: ?>
                        Sin registros
                    <?php endif; ?>
                </span>
                <?php echo e($quotations->links()); ?>

            </footer>
        </section>

        <div class="cotizaciones-bottom-grid">
            <section class="cotizaciones-summary-card">
                <header><span class="cotizaciones-summary-icon"><i class="bi bi-activity" aria-hidden="true"></i></span><div><h2>Actividad comercial reciente</h2><p>Últimas cotizaciones registradas</p></div></header>
                <?php $__empty_1 = true; $__currentLoopData = $recentQuotations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="cotizaciones-recent-row">
                        <span class="cotizaciones-recent-dot"></span>
                        <div><strong>COT-<?php echo e($recent->creado_en?->format('Y') ?? now()->format('Y')); ?>-<?php echo e(str_pad((string) $recent->id, 4, '0', STR_PAD_LEFT)); ?> · <?php echo e($recent->customer?->nombre_contacto ?? 'Cliente no disponible'); ?></strong><small><?php echo e($recent->creado_en?->format('d/m/Y') ?? 'Fecha no disponible'); ?> · S/ <?php echo e(number_format((float) $recent->total, 2)); ?></small></div>
                        <span class="cotizaciones-status cotizaciones-status--<?php echo e($statusClass((string) $recent->estado)); ?>"><?php echo e($recent->estado); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="cotizaciones-summary-empty">Las cotizaciones recientes aparecerán aquí.</p>
                <?php endif; ?>
            </section>

            <section class="cotizaciones-summary-card">
                <header><span class="cotizaciones-summary-icon cotizaciones-summary-icon--green"><i class="bi bi-pie-chart" aria-hidden="true"></i></span><div><h2>Cotizaciones por estado</h2><p>Distribución de los registros activos</p></div></header>
                <?php $__empty_1 = true; $__currentLoopData = $statusSummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="cotizaciones-status-row">
                        <div><span><?php echo e($status['label']); ?></span><strong><?php echo e(number_format($status['count'])); ?></strong></div>
                        <div class="cotizaciones-progress" role="progressbar" aria-label="<?php echo e($status['label']); ?>" aria-valuenow="<?php echo e($status['percent']); ?>" aria-valuemin="0" aria-valuemax="100"><span style="width: <?php echo e($status['percent']); ?>%"></span></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="cotizaciones-summary-empty">Aún no hay cotizaciones registradas.</p>
                <?php endif; ?>
            </section>
        </div>

        <dialog class="admin-dialog cotizaciones-create-dialog" id="nueva-cotizacion" aria-labelledby="nueva-cotizacion-title">
            <header class="admin-dialog-header">
                <div><h2 id="nueva-cotizacion-title">Nueva cotización</h2><p>Registra una propuesta para un cliente mayorista.</p></div>
                <button class="admin-dialog-close" type="button" data-admin-dialog-close aria-label="Cerrar"><i class="bi bi-x-lg" aria-hidden="true"></i></button>
            </header>
            <div class="admin-dialog-body">
                <?php if($customers->isNotEmpty() && $products->isNotEmpty()): ?>
                    <?php echo $__env->make('gestion.cotizaciones.crear', ['customers' => $customers, 'products' => $products], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php else: ?>
                    <p class="cotizaciones-summary-empty">Para crear una cotización, primero registra un cliente mayorista y al menos un producto activo.</p>
                <?php endif; ?>
            </div>
        </dialog>

        <dialog class="admin-dialog cotizaciones-demo-dialog" id="accion-demostrativa-cotizacion" aria-labelledby="accion-demostrativa-title" data-quotation-demo-dialog>
            <header class="admin-dialog-header">
                <div><h2 id="accion-demostrativa-title" data-quotation-demo-title>Acción de cotización</h2><p data-quotation-demo-description>Revisa la acción seleccionada.</p></div>
                <button class="admin-dialog-close" type="button" data-close-quotation-demo aria-label="Cerrar"><i class="bi bi-x-lg" aria-hidden="true"></i></button>
            </header>
            <div class="admin-dialog-body cotizaciones-demo-body">
                <div class="cotizaciones-demo-warning"><i class="bi bi-info-circle" aria-hidden="true"></i><p>Interfaz demostrativa: no se enviará, aprobará ni convertirá la cotización y no se crearán ventas.</p></div>
                <dl><div><dt>Cotización</dt><dd data-quotation-demo-reference>—</dd></div><div><dt>Cliente</dt><dd data-quotation-demo-customer>—</dd></div></dl>
                <p class="cotizaciones-demo-feedback" data-quotation-demo-feedback role="status" aria-live="polite" hidden></p>
            </div>
            <footer class="cotizaciones-demo-footer"><button class="cotizaciones-filter-button" type="button" data-close-quotation-demo>Cancelar</button><button class="cotizaciones-primary-button" type="button" data-confirm-quotation-demo>Confirmar (demostración)</button></footer>
        </dialog>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        (() => {
            const dialog = document.querySelector('[data-quotation-demo-dialog]');
            if (!dialog) {
                return;
            }

            const actionTitles = {
                enviar: ['Preparar envío de cotización', 'El envío real requiere una integración de comunicación.'],
                aprobar: ['Revisar aprobación de cotización', 'La aprobación real requiere una política y una acción autorizada.'],
                convertir: ['Revisar conversión a venta', 'La conversión real requiere un flujo transaccional autorizado.'],
            };
            const title = dialog.querySelector('[data-quotation-demo-title]');
            const description = dialog.querySelector('[data-quotation-demo-description]');
            const reference = dialog.querySelector('[data-quotation-demo-reference]');
            const customer = dialog.querySelector('[data-quotation-demo-customer]');
            const feedback = dialog.querySelector('[data-quotation-demo-feedback]');
            let selectedAction = '';

            document.querySelectorAll('[data-quotation-demo-action]').forEach((button) => {
                button.addEventListener('click', () => {
                    selectedAction = button.dataset.quotationDemoAction ?? '';
                    const copy = actionTitles[selectedAction] ?? ['Acción de cotización', 'La integración de esta acción está pendiente.'];
                    title.textContent = copy[0];
                    description.textContent = copy[1];
                    reference.textContent = button.dataset.reference ?? '—';
                    customer.textContent = button.dataset.customer ?? 'Cliente no disponible';
                    feedback.hidden = true;
                    dialog.showModal();
                });
            });

            dialog.querySelectorAll('[data-close-quotation-demo]').forEach((button) => button.addEventListener('click', () => dialog.close()));
            dialog.querySelector('[data-confirm-quotation-demo]')?.addEventListener('click', () => {
                const actions = { enviar: 'no se envió', aprobar: 'no se aprobó', convertir: 'no se convirtió en venta' };
                feedback.textContent = `Integración pendiente: ${actions[selectedAction] ?? 'no se ejecutó la acción'}; la cotización y las ventas reales no cambiaron.`;
                feedback.hidden = false;
            });
            dialog.addEventListener('click', (event) => {
                if (event.target === dialog) {
                    dialog.close();
                }
            });
        })();
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.administracion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views/gestion/cotizaciones/administrador.blade.php ENDPATH**/ ?>