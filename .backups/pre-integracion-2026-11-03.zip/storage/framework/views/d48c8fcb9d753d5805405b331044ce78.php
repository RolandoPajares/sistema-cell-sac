<?php $__env->startSection('title', 'Panel de cliente minorista'); ?>
<?php $__env->startSection('body_class', 'modulo-cuenta rol-cliente-minorista'); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.comunes.dashboard-cliente', ['role' => 'cliente_minorista'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.administracion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views/paneles/cliente-minorista/dashboard.blade.php ENDPATH**/ ?>