<section class="assistant-chat panel" id="assistantChat" data-endpoint="<?php echo e(route('assistant.ask')); ?>">
    <div class="assistant-chat-head">
        <div class="assistant-avatar">MD</div>
        <div>
            <strong>MD Assistant</strong>
            <small><span class="assistant-online-dot"></span> Asistente del catálogo disponible</small>
        </div>
        <button type="button" class="btn btn-ghost assistant-clear" id="assistantClear">Nueva conversación</button>
    </div>

    <div class="assistant-messages" id="assistantMessages" aria-live="polite">
        <?php if (isset($component)) { $__componentOriginal836576f85d786e6f0df9817b5248526e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal836576f85d786e6f0df9817b5248526e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inteligencia.asistente.mensaje','data' => ['name' => 'MD Assistant']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inteligencia.asistente.mensaje'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'MD Assistant']); ?>
            <p>¡Hola! Puedo ayudarte a elegir un celular, buscar opciones por presupuesto, comparar necesidades o revisar productos disponibles. Escríbeme, por ejemplo: <em>“quiero un celular para gaming menor a S/1500”</em>.</p>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal836576f85d786e6f0df9817b5248526e)): ?>
<?php $attributes = $__attributesOriginal836576f85d786e6f0df9817b5248526e; ?>
<?php unset($__attributesOriginal836576f85d786e6f0df9817b5248526e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal836576f85d786e6f0df9817b5248526e)): ?>
<?php $component = $__componentOriginal836576f85d786e6f0df9817b5248526e; ?>
<?php unset($__componentOriginal836576f85d786e6f0df9817b5248526e); ?>
<?php endif; ?>
    </div>

    <?php if (isset($component)) { $__componentOriginal4df5c3c9b0e8ff6c3563db6e54fd79d1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4df5c3c9b0e8ff6c3563db6e54fd79d1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inteligencia.asistente.sugerencias','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inteligencia.asistente.sugerencias'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4df5c3c9b0e8ff6c3563db6e54fd79d1)): ?>
<?php $attributes = $__attributesOriginal4df5c3c9b0e8ff6c3563db6e54fd79d1; ?>
<?php unset($__attributesOriginal4df5c3c9b0e8ff6c3563db6e54fd79d1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4df5c3c9b0e8ff6c3563db6e54fd79d1)): ?>
<?php $component = $__componentOriginal4df5c3c9b0e8ff6c3563db6e54fd79d1; ?>
<?php unset($__componentOriginal4df5c3c9b0e8ff6c3563db6e54fd79d1); ?>
<?php endif; ?>

    <form class="assistant-composer" id="assistantForm">
        <?php echo csrf_field(); ?>
        <input
            class="input"
            id="assistantInput"
            name="message"
            autocomplete="off"
            maxlength="300"
            placeholder="Escribe otro mensaje..."
            required
        >
        <button class="btn btn-primary" id="assistantSend" type="submit">
            <i class="bi bi-send-fill"></i>
            Enviar
        </button>
    </form>
    <small class="assistant-disclaimer">Las recomendaciones se generan con los productos y datos disponibles en el catálogo.</small>
</section>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views/components/inteligencia/asistente/chat.blade.php ENDPATH**/ ?>