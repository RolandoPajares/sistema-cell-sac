<details>
    <summary>Datos</summary>
    <pre><?php echo e(json_encode(['antes' => $log->valores_anteriores, 'despues' => $log->valores_nuevos], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)); ?></pre>
</details>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\gestion\auditoria\ver.blade.php ENDPATH**/ ?>