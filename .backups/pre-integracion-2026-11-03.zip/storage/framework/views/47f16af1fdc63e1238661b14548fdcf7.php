<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['menu' => []]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['menu' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="admin-menu-desplegable" data-admin-menu-desplegable>
    <div class="admin-menu-desplegable__groups">
        <?php $__currentLoopData = $menu['grupos'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $hasActiveItem = collect($group['items'])->contains(fn (array $item): bool => $item['active'] ?? false);
                $submenuId = 'admin-menu-submenu-'.\Illuminate\Support\Str::slug($group['id']);
            ?>

            <?php if($group['direct'] ?? false): ?>
                <?php $__currentLoopData = $group['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item['enabled'] && $item['route']): ?>
                        <a class="admin-menu-desplegable__dashboard <?php echo e($item['active'] ? 'is-active' : ''); ?>" href="<?php echo e(route($item['route'])); ?>" <?php if($item['active']): ?> aria-current="page" <?php endif; ?>>
                            <i class="bi <?php echo e($item['icon']); ?>" aria-hidden="true"></i>
                            <span class="admin-menu-desplegable__label"><?php echo e($item['label']); ?></span>
                        </a>
                    <?php else: ?>
                        <span class="admin-menu-desplegable__dashboard admin-menu-desplegable__item--disabled" aria-disabled="true" title="Módulo pendiente de implementación">
                            <i class="bi <?php echo e($item['icon']); ?>" aria-hidden="true"></i>
                            <span class="admin-menu-desplegable__label"><?php echo e($item['label']); ?> · Próximamente</span>
                        </span>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php ($isOpen = $hasActiveItem); ?>
                <section class="admin-menu-desplegable__group <?php echo e($hasActiveItem ? 'is-active' : ''); ?> <?php echo e($isOpen ? 'is-open' : ''); ?>" data-admin-menu-group>
                    <button class="admin-menu-desplegable__toggle" type="button" aria-expanded="<?php echo e($isOpen ? 'true' : 'false'); ?>" aria-controls="<?php echo e($submenuId); ?>" data-admin-menu-toggle>
                        <span class="admin-menu-desplegable__toggle-main">
                            <i class="bi <?php echo e($group['icon']); ?>" aria-hidden="true"></i>
                            <span class="admin-menu-desplegable__label"><?php echo e($group['label']); ?></span>
                        </span>
                        <i class="bi bi-chevron-down admin-menu-desplegable__chevron" aria-hidden="true"></i>
                    </button>
                    <div class="admin-menu-desplegable__submenu" id="<?php echo e($submenuId); ?>" data-admin-menu-submenu <?php if(! $isOpen): ?> hidden <?php endif; ?>>
                        <?php $__currentLoopData = $group['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item['enabled'] && $item['route']): ?>
                                <a class="admin-menu-desplegable__item <?php echo e($item['active'] ? 'is-active' : ''); ?>" href="<?php echo e(route($item['route'])); ?>" title="<?php echo e($item['label']); ?>" <?php if($item['active']): ?> aria-current="page" <?php endif; ?>>
                                    <i class="bi <?php echo e($item['icon']); ?>" aria-hidden="true"></i>
                                    <span class="admin-menu-desplegable__label"><?php echo e($item['label']); ?></span>
                                </a>
                            <?php else: ?>
                                <span class="admin-menu-desplegable__item admin-menu-desplegable__item--disabled" aria-disabled="true" title="Módulo pendiente de implementación">
                                    <i class="bi <?php echo e($item['icon']); ?>" aria-hidden="true"></i>
                                    <span class="admin-menu-desplegable__label"><?php echo e($item['label']); ?> · Próximamente</span>
                                </span>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </section>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\components\panel\menu-dinamico.blade.php ENDPATH**/ ?>