<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['product', 'position']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['product', 'position']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $path = $product->images->first()?->ruta_imagen ?: $product->url_imagen;
    $path = ltrim((string) preg_replace('~^assets/~', '', $path ?: 'img/marca/logo.jpeg'), '/');
?>

<article class="smartmatch-tarjeta">
    <span class="smartmatch-puesto">#<?php echo e($position); ?></span>
    <img class="smartmatch-product-photo" src="<?php echo e(asset('assets/cell-legacy/'.$path)); ?>" alt="<?php echo e($product->marca); ?> <?php echo e($product->nombre); ?>" loading="lazy">
    <div class="smartmatch-tarjeta-arriba">
        <div>
            <small><?php echo e($product->marca ?: 'CELL SAC'); ?></small>
            <h3><?php echo e($product->nombre); ?></h3>
            <p class="smartmatch-precio">S/ <?php echo e(number_format((float) $product->effective_price, 2)); ?></p>
        </div>
        <div class="smartmatch-porcentaje"><b><?php echo e((int) $product->recommendation_score); ?>%</b><small>coincide</small></div>
    </div>
    <ul>
        <li><i class="bi bi-check-circle-fill"></i> Precio dentro del catálogo vigente</li>
        <li><i class="bi bi-check-circle-fill"></i> Stock disponible: <?php echo e($product->existencias); ?></li>
        <li><i class="bi bi-check-circle-fill"></i> Puntaje calculado según tu selección</li>
    </ul>
    <div class="smartmatch-botones">
        <a class="btn btn-primary" href="<?php echo e(route('catalog.show', $product)); ?>">Ver equipo</a>
        <a class="btn btn-ghost" href="<?php echo e(route('comparison', ['seleccion' => $product->id])); ?>">Comparar</a>
    </div>
</article>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\components\inteligencia\comprador\recomendaciones.blade.php ENDPATH**/ ?>