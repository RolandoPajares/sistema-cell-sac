<form method="post" class="form-card compact-form" action="<?php echo e(route('management.coupons.store')); ?>">
    <?php echo csrf_field(); ?>

    <label>
        Código
        <input name="codigo" required>
    </label>

    <label>
        Tipo
        <select name="tipo_descuento">
            <option value="porcentaje">Porcentaje</option>
            <option value="fijo">Monto fijo</option>
        </select>
    </label>

    <label>
        Valor
        <input
            type="number"
            name="valor"
            step="0.01"
            min="0.01"
            required
        >
    </label>

    <label>
        Compra mínima
        <input
            type="number"
            name="minimo_compra"
            step="0.01"
            min="0"
            value="0"
            required
        >
    </label>

    <label>
        Límite usos
        <input type="number" name="limite_usos" min="1">
    </label>

    <label>
        Inicio
        <input type="datetime-local" name="inicia_en" required>
    </label>

    <label>
        Fin
        <input type="datetime-local" name="finaliza_en" required>
    </label>

    <button class="btn btn-primary">Guardar cupón</button>
</form>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\gestion\cupones\crear.blade.php ENDPATH**/ ?>