<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['product']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['product']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $path = $product->images->first()?->ruta_imagen ?: $product->url_imagen;
    $path = ltrim((string) preg_replace('~^assets/~', '', $path ?: 'img/marca/logo.jpeg'), '/');
    $score = $product->intelligenceProfile?->puntuacion_valor ?? 70;
?>

<article class="panel comparison-card">
    <img class="comparison-product-photo" src="<?php echo e(asset('assets/cell-legacy/'.$path)); ?>" alt="<?php echo e($product->marca); ?> <?php echo e($product->nombre); ?>" loading="lazy">
    <span class="eyebrow"><?php echo e($product->marca ?: 'CELL SAC'); ?></span>
    <h2><?php echo e($product->nombre); ?></h2>
    <div class="price">S/ <?php echo e(number_format((float) $product->effective_price, 2)); ?></div>
    <p><?php echo e($product->category?->nombre ?: 'Equipo'); ?> · Stock <?php echo e((int) $product->existencias); ?></p>
    <div class="score-row">
        <span>SmartScore</span>
        <b><?php echo e((int) $score); ?>/100</b>
        <div class="scorebar"><i style="width: <?php echo e((int) $score); ?>%"></i></div>
    </div>
    <a class="btn btn-ghost" href="<?php echo e(route('catalog.show', $product)); ?>">Ver detalles</a>
</article>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\components\inteligencia\comprador\comparacion.blade.php ENDPATH**/ ?>