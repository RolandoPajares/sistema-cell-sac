<?php echo $__env->make('gestion.componentes.modulo-pendiente-crud-formulario', ['module' => $module, 'mode' => 'editar'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\gestion\soporte-reclamos\editar.blade.php ENDPATH**/ ?>