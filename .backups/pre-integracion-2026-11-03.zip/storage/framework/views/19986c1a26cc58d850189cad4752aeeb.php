<?php $__env->startSection('title', 'Indicadores de ventas e ingresos'); ?>
<?php $__env->startSection('body_class', 'modulo-dashboard-global'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $maxDaily = max(1, (float) $dailyTotals->max());
    $maxChannel = max(1, (float) $channelTotals->max());
    $channelBars = $channelTotals->map(fn ($amount, $name) => [
        'etiqueta' => $name,
        'valor' => 'S/ '.number_format($amount, 2),
        'altura' => max(4, round($amount / $maxChannel * 100)),
    ])->values();
    $exportParameters = array_filter(['periodo' => $filters['periodo'], 'sede' => $filters['sede'], 'canal' => $filters['canal']]);
?>
<section class="tc-dg" data-dashboard-global="ventas">
    <?php echo $__env->make('paneles.administrador.dashboard-global.componentes.cabecera', [
        'titulo' => 'Indicadores de ventas e ingresos',
        'icono' => 'bi-graph-up-arrow',
        'descripcion' => 'Analiza el desempeño de ventas e ingresos de tu negocio.',
        'exportRoute' => $canExport ? 'management.reports.dashboard_sales.export' : null,
        'exportParameters' => $exportParameters,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <form class="tc-dg__filters" method="GET" action="<?php echo e(route('management.dashboard.sales')); ?>">
        <label><span><i class="bi bi-calendar3"></i> Rango de fechas</span><select name="periodo">
            <?php $__currentLoopData = [7 => 'Últimos 7 días', 30 => 'Últimos 30 días', 90 => 'Últimos 90 días']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $days => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($days); ?>" <?php if($filters['periodo'] === $days): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select></label>
        <label><span><i class="bi bi-shop"></i> Sede</span><select name="sede" <?php if(! $hasSite): echo 'disabled'; endif; ?>>
            <option value="">Todas las sedes</option>
            <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($site->id); ?>" <?php if($filters['sede'] == $site->id): echo 'selected'; endif; ?>><?php echo e($site->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select></label>
        <label><span><i class="bi bi-tag"></i> Canal de venta</span><select name="canal" <?php if(! $hasChannel): echo 'disabled'; endif; ?>>
            <option value="">Todos los canales</option>
            <?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($channel); ?>" <?php if($filters['canal'] === $channel): echo 'selected'; endif; ?>><?php echo e($channel); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select></label>
        <button type="submit"><i class="bi bi-arrow-repeat"></i> Aplicar filtros</button>
    </form>

    <div class="tc-dg__metrics tc-dg__metrics--six">
        <?php echo $__env->make('paneles.administrador.dashboard-global.componentes.metrica', ['titulo' => 'Ventas totales', 'icono' => 'bi-cart3', 'valor' => number_format($orderCount), 'detalle' => 'Pedidos no cancelados del período'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('paneles.administrador.dashboard-global.componentes.metrica', ['titulo' => 'Ingresos registrados', 'icono' => 'bi-coin', 'tono' => 'verde', 'valor' => 'S/ '.number_format($income, 2), 'detalle' => 'Total de pedidos no cancelados'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('paneles.administrador.dashboard-global.componentes.metrica', ['titulo' => 'Ticket promedio', 'icono' => 'bi-tag', 'tono' => 'violeta', 'valor' => 'S/ '.number_format($averageTicket, 2), 'detalle' => 'Por pedido no cancelado'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('paneles.administrador.dashboard-global.componentes.metrica', ['titulo' => 'Margen bruto', 'icono' => 'bi-percent', 'tono' => 'ambar', 'valor' => '—', 'detalle' => 'Sin costos de venta integrados'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('paneles.administrador.dashboard-global.componentes.metrica', ['titulo' => 'Pedidos completados', 'icono' => 'bi-check-circle', 'valor' => number_format($completedCount), 'detalle' => 'Estados pagado, completado o entregado'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('paneles.administrador.dashboard-global.componentes.metrica', ['titulo' => 'Crecimiento mensual', 'icono' => 'bi-graph-up', 'tono' => 'verde', 'valor' => '—', 'detalle' => 'Pendiente de comparación homogénea'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <div class="tc-dg__grid tc-dg__grid--wide">
        <article class="tc-dg__card"><div class="tc-dg__card-head"><i class="bi bi-bar-chart-line"></i><div><h2>Ventas e ingresos</h2><p>Ingresos diarios del período seleccionado (S/).</p></div><span>Diario</span></div>
            <div class="tc-dg__chart tc-dg__chart--large">
                <?php if($dailyTotals->isEmpty()): ?>
                    <p class="tc-dg__empty">No hay ventas registradas en el período.</p>
                <?php else: ?>
                    <?php echo $__env->make('paneles.administrador.dashboard-global.componentes.grafico-barras', ['descripcion' => 'Ingresos diarios reales', 'barras' => $dailyTotals->map(fn ($amount, $day) => ['etiqueta' => \Illuminate\Support\Carbon::parse($day)->format('d/m'), 'valor' => 'S/ '.number_format($amount, 2), 'altura' => max(4, round($amount / $maxDaily * 100))])->values()], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endif; ?>
            </div>
        </article>
        <article class="tc-dg__card"><div class="tc-dg__card-head"><i class="bi bi-bar-chart"></i><div><h2>Ventas por canal</h2><p>Ingresos registrados por canal de venta.</p></div></div><div class="tc-dg__chart tc-dg__chart--large">
            <?php if($channelBars->isEmpty()): ?>
                <p class="tc-dg__empty">Sin datos de canal disponibles.</p>
            <?php else: ?>
                <?php echo $__env->make('paneles.administrador.dashboard-global.componentes.grafico-barras', ['descripcion' => 'Ingresos reales por canal', 'barras' => $channelBars], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>
        </div></article>
    </div>

    <div class="tc-dg__grid tc-dg__grid--thirds">
        <article class="tc-dg__card"><div class="tc-dg__card-head"><i class="bi bi-pie-chart"></i><div><h2>Distribución de ingresos</h2><p>Participación por categoría.</p></div></div><p class="tc-dg__empty">Pendiente de vincular el detalle de venta y las categorías.</p></article>
        <article class="tc-dg__card"><div class="tc-dg__card-head"><i class="bi bi-trophy"></i><div><h2>Productos más vendidos</h2><p>Ranking por unidades vendidas.</p></div></div><p class="tc-dg__empty">Pendiente de integrar el ranking con el detalle de venta.</p></article>
        <article class="tc-dg__card"><div class="tc-dg__card-head"><i class="bi bi-bullseye"></i><div><h2>Metas vs. resultados</h2><p>Cumplimiento de metas del período.</p></div></div><p class="tc-dg__empty">No hay metas configuradas para este período.</p></article>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.administracion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\paneles\administrador\dashboard-global\ventas\listar.blade.php ENDPATH**/ ?>