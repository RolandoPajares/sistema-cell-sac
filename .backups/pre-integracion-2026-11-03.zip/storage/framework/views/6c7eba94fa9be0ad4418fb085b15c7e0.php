<?php if (isset($component)) { $__componentOriginal798cd313f5325fa7d8414c0891e5ecb2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal798cd313f5325fa7d8414c0891e5ecb2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inteligencia.cotizador.formulario','data' => ['customers' => $customers,'products' => $products]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inteligencia.cotizador.formulario'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['customers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($customers),'products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($products)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal798cd313f5325fa7d8414c0891e5ecb2)): ?>
<?php $attributes = $__attributesOriginal798cd313f5325fa7d8414c0891e5ecb2; ?>
<?php unset($__attributesOriginal798cd313f5325fa7d8414c0891e5ecb2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal798cd313f5325fa7d8414c0891e5ecb2)): ?>
<?php $component = $__componentOriginal798cd313f5325fa7d8414c0891e5ecb2; ?>
<?php unset($__componentOriginal798cd313f5325fa7d8414c0891e5ecb2); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\gestion\cotizaciones\crear.blade.php ENDPATH**/ ?>