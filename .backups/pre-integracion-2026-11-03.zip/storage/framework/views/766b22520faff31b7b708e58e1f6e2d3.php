<?php $__env->startSection('title', 'Roles y permisos'); ?>
<?php $__env->startSection('content'); ?>
    <section class="admin-page">
        <header class="admin-page-head"><div><span class="eyebrow">Seguridad y delegación</span><h1>Roles y matriz de privilegios</h1><p>Los permisos se verifican en rutas y servicios. La matriz solo administra concesiones RBAC.</p></div></header>

        <?php if (! ($ready)): ?>
            <div class="admin-alert admin-alert--error" role="status">Las tablas RBAC no están presentes en la base actual. Esta pantalla no crea ni simula roles hasta que se aplique la migración aprobada.</div>
        <?php else: ?>
            <div class="admin-page-actions"><a class="btn btn-outline-primary" href="<?php echo e(route('management.user_assignments')); ?>"><i class="bi bi-person-gear" aria-hidden="true"></i> Asignaciones de usuarios</a><a class="btn btn-outline-primary" href="<?php echo e(route('management.menus')); ?>"><i class="bi bi-list-nested" aria-hidden="true"></i> Configurar menús</a><a class="btn btn-outline-primary" href="<?php echo e(route('management.modules')); ?>"><i class="bi bi-grid" aria-hidden="true"></i> Módulos y pantallas</a></div>

            <form method="post" action="<?php echo e(route('management.roles_permissions.store')); ?>" class="form-card role-create-form">
                <?php echo csrf_field(); ?>
                <h2>Crear rol configurable</h2>
                <div class="two-column">
                    <label>Código<input name="codigo" maxlength="40" pattern="[a-z][a-z0-9_]*" required placeholder="supervisor_sede"></label>
                    <label>Nombre<input name="nombre" maxlength="120" required></label>
                    <label>Alcance máximo<select name="alcance_permitido" required><option value="sede">Sede</option><option value="propio">Registros propios</option><option value="empresa">Empresa</option></select></label>
                    <label>Descripción<textarea name="descripcion" maxlength="255"></textarea></label>
                </div>
                <button class="btn btn-primary" type="submit">Crear rol sin permisos</button>
            </form>

            <div class="role-matrix-summary"><strong><?php echo e($roles->count()); ?> roles configurados</strong><span><?php echo e($permissionCount); ?> permisos activos disponibles</span></div>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php ($rolePermissions = $role->permisos->keyBy('id')); ?>
                <details class="form-card role-matrix-card" <?php if($loop->first): ?> open <?php endif; ?>>
                    <summary><span><strong><?php echo e($role->nombre); ?></strong><small><?php echo e($role->codigo); ?> · alcance <?php echo e($role->alcance_permitido); ?> · <?php echo e($role->usuarios_count); ?> asignaciones globales</small></span><i class="bi bi-chevron-down" aria-hidden="true"></i></summary>
                    <?php if($role->codigo === 'administrador'): ?>
                        <p class="admin-alert admin-alert--success">Rol global del sistema. Conserva privilegios completos y no puede editarse desde esta matriz para evitar bloquear la administración.</p>
                    <?php else: ?>
                        <form method="post" action="<?php echo e(route('management.roles_permissions.permissions', $role)); ?>">
                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                            <label>Alcance de todas las concesiones
                                <select name="alcance" required>
                                    <option value="empresa" <?php if($role->alcance_permitido === 'empresa'): echo 'selected'; endif; ?>>Empresa</option>
                                    <option value="sede" <?php if($role->alcance_permitido === 'sede'): echo 'selected'; endif; ?>>Sede</option>
                                    <option value="propio" <?php if($role->alcance_permitido === 'propio'): echo 'selected'; endif; ?>>Registros propios</option>
                                </select>
                            </label>
                            <div class="permission-modules">
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moduleCode => $modulePermissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <fieldset class="permission-module">
                                        <legend><?php echo e($modulePermissions->first()->modulo_nombre); ?></legend>
                                        <div class="permission-grid">
                                            <?php $__currentLoopData = $modulePermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <label><input type="checkbox" name="permisos[]" value="<?php echo e($permission->id); ?>" <?php if($rolePermissions->has($permission->id)): echo 'checked'; endif; ?>> <?php echo e($permission->nombre); ?></label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </fieldset>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button class="btn btn-primary" type="submit">Guardar privilegios</button>
                        </form>
                    <?php endif; ?>
                </details>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.administracion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\gestion\roles-permisos\listar.blade.php ENDPATH**/ ?>