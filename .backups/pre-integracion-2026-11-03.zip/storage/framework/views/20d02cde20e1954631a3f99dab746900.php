<form method="post" class="form-card compact-form" action="<?php echo e(route('management.segments.store')); ?>">
    <?php echo csrf_field(); ?>
    <label>
        Nombre
        <input name="nombre" required maxlength="120">
    </label>

    <fieldset>
        <legend>Roles incluidos</legend>
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label class="check">
                <input type="checkbox" name="roles[]" value="<?php echo e($role); ?>">
                <?php echo e(str_replace('_', ' ', $role)); ?>

            </label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </fieldset>
    <button class="btn btn-primary">Crear segmento</button>
</form>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\gestion\segmentos\crear.blade.php ENDPATH**/ ?>