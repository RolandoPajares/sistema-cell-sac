<form method="post" class="form-card compact-form" action="<?php echo e(route('management.purchases.store')); ?>">
    <?php echo csrf_field(); ?>
    <h2>Registrar recepción</h2>

    <label>
        Proveedor
        <select name="proveedor_id" required>
            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </label>

    <label>
        Fecha
        <input
            type="date"
            name="fecha_compra"
            required
            value="<?php echo e(now()->toDateString()); ?>"
        >
    </label>

    <label>
        Producto
        <select name="items[0][producto_id]" required>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($product->id); ?>"><?php echo e($product->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </label>

    <label>
        Cantidad
        <input type="number" name="items[0][cantidad]" min="1" required>
    </label>

    <label>
        Costo unitario
        <input
            type="number"
            name="items[0][costo_unitario]"
            step="0.01"
            min="0"
            required
        >
    </label>

    <button class="btn btn-primary">Registrar compra y entrada</button>
</form>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\gestion\compras\crear.blade.php ENDPATH**/ ?>