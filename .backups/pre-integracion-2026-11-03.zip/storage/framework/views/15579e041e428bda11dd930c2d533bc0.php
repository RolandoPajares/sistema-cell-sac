<?php $__env->startSection('title', 'Menús dinámicos'); ?>
<?php $__env->startSection('content'); ?>
    <section class="admin-page">
        <header class="admin-page-head"><div><span class="eyebrow">Seguridad y delegación</span><h1>Menús y submenús</h1><p>La navegación se guarda en MySQL y se filtra por permisos en cada petición.</p></div></header>
        <?php if (! ($ready)): ?>
            <div class="admin-alert admin-alert--error" role="status">Las tablas RBAC aún no existen. La navegación permanece en el esquema de compatibilidad hasta aplicar las migraciones.</div>
        <?php else: ?>
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <section class="form-card menu-editor-card">
                    <header><div><h2><?php echo e($menu->nombre); ?></h2><small><?php echo e($menu->codigo); ?> · <?php echo e($menu->contexto); ?></small></div></header>
                    <form method="post" action="<?php echo e(route('management.menus.roles', $menu)); ?>" class="menu-role-form">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <fieldset><legend>Roles con acceso a esta navegación</legend>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label><input type="checkbox" name="roles[]" value="<?php echo e($role->id); ?>" <?php if($menu->roles->contains('id', $role->id)): echo 'checked'; endif; ?>> <?php echo e($role->nombre); ?></label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </fieldset>
                        <button class="btn btn-primary btn-sm" type="submit">Guardar roles</button>
                    </form>
                    <div class="table-responsive"><table class="table align-middle"><thead><tr><th>Opción / grupo</th><th>Ruta</th><th>Orden</th><th>Estado</th><th></th></tr></thead><tbody>
                        <?php $__currentLoopData = $menu->elementos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="menu-editor-group"><td><i class="bi <?php echo e($element->icono); ?>" aria-hidden="true"></i> <?php echo e($element->etiqueta); ?> <small><?php echo e($element->tipo); ?></small></td><td>—</td><td><?php echo e($element->orden); ?></td><td><?php echo e($element->habilitado ? 'Activo' : 'Inactivo'); ?></td><td>Grupo</td></tr>
                            <?php $__currentLoopData = $element->elementosHijos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr><td>↳ <?php echo e($child->etiqueta); ?></td><td><?php echo e($child->pantalla?->ruta ?? 'Sin ruta'); ?></td><td><?php echo e($child->orden); ?></td><td><?php echo e($child->habilitado ? 'Activo' : 'Inactivo'); ?><?php if(! $child->pantalla?->habilitada || ! $child->pantalla?->ruta): ?><small> · Pendiente</small><?php endif; ?></td><td>
                                <form method="post" action="<?php echo e(route('management.menus.elements.update', $child)); ?>" class="menu-element-form">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <label class="visually-hidden" for="orden-<?php echo e($child->id); ?>">Orden de <?php echo e($child->etiqueta); ?></label><input id="orden-<?php echo e($child->id); ?>" type="number" name="orden" min="0" max="10000" value="<?php echo e($child->orden); ?>" required>
                                        <input type="hidden" name="habilitado" value="0">
                                        <label><input type="checkbox" name="habilitado" value="1" <?php if($child->habilitado): echo 'checked'; endif; ?>> Habilitada</label>
                                        <button class="btn btn-outline-primary btn-sm" type="submit">Guardar</button>
                                    </form>
                                </td></tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody></table></div>
                </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.administracion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\gestion\menus\listar.blade.php ENDPATH**/ ?>