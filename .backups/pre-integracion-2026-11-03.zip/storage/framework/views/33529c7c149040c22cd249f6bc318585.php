<?php $__env->startSection('title', 'Auditoría'); ?>

<?php $__env->startSection('content'); ?>
<section class="container content-page">
    <h1>Auditoría</h1>

    
    <form method="GET" class="filter-form">
        <label>
            Entidad
            <input type="text" name="entidad" value="<?php echo e(request('entidad')); ?>">
        </label>

        <label>
            Desde
            <input type="date" name="desde" value="<?php echo e(request('desde')); ?>">
        </label>

        <label>
            Hasta
            <input type="date" name="hasta" value="<?php echo e(request('hasta')); ?>">
        </label>

        <button type="submit" class="btn btn-primary">Filtrar</button>
    </form>

    
    <div class="logs-list">
        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="data-row">
                <div>
                    <b><?php echo e($log->accion); ?> · <?php echo e($log->entidad); ?> #<?php echo e($log->entidad_id); ?></b>
                    <small>Usuario <?php echo e($log->usuario_id ?? 'sistema'); ?> · <?php echo e($log->creado_en); ?> · <?php echo e($log->direccion_ip); ?></small>
                </div>

                <?php echo $__env->make('gestion.auditoria.ver', ['log' => $log], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div class="pagination-container">
        <?php echo e($logs->links()); ?>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.administracion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\gestion\auditoria\listar.blade.php ENDPATH**/ ?>