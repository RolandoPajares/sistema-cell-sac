<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['mode' => 'mostrar', 'role' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['mode' => 'mostrar', 'role' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $user = auth()->user();
    $role ??= $user?->rol;
    $profileRoute = $role === 'administrador' ? 'management.account.profile' : 'account.profile';
    $passwordRoute = $role === 'administrador' ? 'management.account.password' : 'account.password';
    $backRoute = $role === 'administrador' ? 'management.account' : 'dashboard';
    $isAdministrator = $role === 'administrador';
?>

<section class="admin-page">
    <header class="admin-page-head">
        <div>
            <span class="eyebrow"><?php echo e(str_replace('_', ' ', $role)); ?></span>
            <h1><?php echo e($mode === 'editar' ? 'Editar perfil' : 'Perfil de usuario'); ?></h1>
            <p>Consulta y actualiza únicamente los datos de tu propia cuenta.</p>
        </div>
    </header>

    <?php if($mode === 'mostrar'): ?>
        <section class="form-card profile-card">
            <?php if($user->foto_perfil): ?>
                <img src="<?php echo e(\Illuminate\Support\Facades\Storage::disk('public')->url($user->foto_perfil)); ?>" alt="Fotografía de <?php echo e($user->nombre); ?>" width="96" height="96" style="border-radius:50%;object-fit:cover">
            <?php else: ?>
                <span class="avatar-grande"><?php echo e(mb_strtoupper(mb_substr($user->nombre, 0, 1))); ?></span>
            <?php endif; ?>
            <h2><?php echo e($user->nombre); ?></h2>
            <p><?php echo e($user->correo); ?></p>
            <p><strong>Rol:</strong> <?php echo e(str_replace('_', ' ', $role)); ?></p>
            <a class="btn btn-primary" href="<?php echo e(route($backRoute)); ?>">Editar perfil</a>
            <?php if($isAdministrator): ?>
                <nav class="profile-account-links" aria-label="Seguridad y actividad de la cuenta">
                    <a href="<?php echo e(route('management.account.security')); ?>">Seguridad de la cuenta</a>
                    <a href="<?php echo e(route('management.account.sessions')); ?>">Sesiones y dispositivos</a>
                    <a href="<?php echo e(route('management.account.preferences')); ?>">Preferencias</a>
                    <a href="<?php echo e(route('management.account.notifications')); ?>">Mis notificaciones</a>
                    <a href="<?php echo e(route('management.account.activity')); ?>">Mi actividad reciente</a>
                </nav>
            <?php endif; ?>
        </section>
    <?php else: ?>
        <div class="two-column">
            <form method="post" action="<?php echo e(route($profileRoute)); ?>" class="form-card">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <h2>Datos personales</h2>
                <label>
                    Nombre
                    <input
                        name="nombre"
                        value="<?php echo e(old('nombre', $user->nombre)); ?>"
                        required
                        maxlength="120"
                    >
                </label>

                <label>
                    Correo
                    <input
                        type="email"
                        name="correo"
                        value="<?php echo e(old('correo', $user->correo)); ?>"
                        required
                        maxlength="160"
                    >
                </label>
                <button class="btn btn-primary" type="submit">Guardar perfil</button>
            </form>
            <?php if($isAdministrator): ?>
                <form method="post" action="<?php echo e(route('management.account.avatar')); ?>" class="form-card" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <h2>Fotografía de perfil</h2>
                    <?php if($user->foto_perfil): ?>
                        <img src="<?php echo e(\Illuminate\Support\Facades\Storage::disk('public')->url($user->foto_perfil)); ?>" alt="Fotografía actual de <?php echo e($user->nombre); ?>" width="96" height="96" style="border-radius:50%;object-fit:cover">
                    <?php endif; ?>
                    <label>Seleccionar imagen<input type="file" name="foto_perfil" accept="image/jpeg,image/png,image/webp" required></label>
                    <small>JPG, PNG o WebP. Máximo 2 MB.</small>
                    <button class="btn btn-primary" type="submit">Actualizar fotografía</button>
                </form>
            <?php endif; ?>
            <form method="post" action="<?php echo e(route($passwordRoute)); ?>" class="form-card" id="cambiar-contrasena">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <h2>Cambiar contraseña</h2>
                <label>
                    Contraseña actual
                    <input type="password" name="password_actual" required>
                </label>

                <label>
                    Nueva contraseña
                    <input
                        type="password"
                        name="password"
                        required
                        minlength="10"
                    >
                </label>

                <label>
                    Confirmar contraseña
                    <input
                        type="password"
                        name="password_confirmation"
                        required
                    >
                </label>
                <button class="btn btn-primary" type="submit">Actualizar contraseña</button>
            </form>
        </div>
    <?php endif; ?>
</section>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\components\perfil\pagina.blade.php ENDPATH**/ ?>