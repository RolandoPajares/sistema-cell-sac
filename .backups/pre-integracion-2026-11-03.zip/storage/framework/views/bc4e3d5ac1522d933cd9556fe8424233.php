<?php $__env->startSection('title', 'Inventario'); ?>
<?php $__env->startSection('body_class', 'modulo-inventario'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $productImage = static function (?string $path): ?string {
            if (!$path) {
                return null;
            }

            return str_starts_with($path, 'http') ? $path : asset(ltrim($path, '/'));
        };
        $statusForStock = static function (int $stock): array {
            return match (true) {
                $stock > 10 => ['label' => 'Óptimo', 'class' => 'optimal'],
                $stock > 0 => ['label' => 'Bajo', 'class' => 'low'],
                default => ['label' => 'Crítico', 'class' => 'critical'],
            };
        };
        $monthNames = [1 => 'Ene', 2 => 'Feb', 3 => 'Mar', 4 => 'Abr', 5 => 'May', 6 => 'Jun', 7 => 'Jul', 8 => 'Ago', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dic'];
        $today = now();
        $todayLabel = $today->format('d').' de '.$monthNames[(int) $today->format('n')].', '.$today->format('Y');
    ?>

    <section class="inventario-page" data-inventory-page>
        <header class="inventario-hero">
            <div>
                <span class="inventario-eyebrow">Operaciones</span>
                <h1>Inventario <i class="bi bi-boxes" aria-hidden="true"></i></h1>
                <p>Controla existencias, entradas, salidas y ajustes con trazabilidad completa.</p>
            </div>
            <div class="inventario-date-card">
                <i class="bi bi-calendar3" aria-hidden="true"></i>
                <span><small>Hoy</small><strong><?php echo e($todayLabel); ?></strong></span>
                <i class="bi bi-chevron-down" aria-hidden="true"></i>
            </div>
        </header>

        <section class="inventario-kpi-grid" aria-label="Resumen del inventario">
            <article class="inventario-kpi inventario-kpi--blue">
                <span class="inventario-kpi-icon"><i class="bi bi-box-seam" aria-hidden="true"></i></span>
                <div><small>Productos en stock</small><strong><?php echo e(number_format($activeProducts)); ?></strong><span>Productos disponibles para la venta</span></div>
                <b class="inventario-kpi-trend is-positive"><i class="bi bi-arrow-up-right" aria-hidden="true"></i> Stock disponible</b>
            </article>
            <article class="inventario-kpi inventario-kpi--orange">
                <span class="inventario-kpi-icon"><i class="bi bi-exclamation-triangle" aria-hidden="true"></i></span>
                <div><small>Stock bajo</small><strong><?php echo e(number_format($lowStock)); ?></strong><span>Productos por debajo del mínimo</span></div>
                <b class="inventario-kpi-trend <?php echo e($lowStock > 0 ? 'is-negative' : 'is-positive'); ?>"><i class="bi bi-<?php echo e($lowStock > 0 ? 'arrow-up-right' : 'check'); ?>" aria-hidden="true"></i> <?php echo e($lowStock > 0 ? 'Revisar' : 'Correcto'); ?></b>
            </article>
            <article class="inventario-kpi inventario-kpi--indigo">
                <span class="inventario-kpi-icon"><i class="bi bi-arrow-left-right" aria-hidden="true"></i></span>
                <div><small>Movimientos hoy</small><strong><?php echo e(number_format($movementsToday)); ?></strong><span>Entradas, salidas y ajustes</span></div>
                <?php if($movementsTrend !== null): ?>
                    <b class="inventario-kpi-trend <?php echo e($movementsTrend >= 0 ? 'is-positive' : 'is-negative'); ?>"><i class="bi bi-arrow-<?php echo e($movementsTrend >= 0 ? 'up' : 'down'); ?>-right" aria-hidden="true"></i> <?php echo e(number_format(abs($movementsTrend), 1)); ?>%</b>
                <?php else: ?>
                    <b class="inventario-kpi-trend">Sin periodo anterior</b>
                <?php endif; ?>
            </article>
            <article class="inventario-kpi inventario-kpi--green">
                <span class="inventario-kpi-icon"><i class="bi bi-cash-stack" aria-hidden="true"></i></span>
                <div><small>Valor inventario</small><strong>S/ <?php echo e(number_format($inventoryValue, 2)); ?></strong><span>Valor registrado en productos activos</span></div>
                <b class="inventario-kpi-trend is-positive"><i class="bi bi-graph-up-arrow" aria-hidden="true"></i> Valor actual</b>
            </article>
        </section>

        <div class="inventario-toolbar">
            <button class="inventario-primary-button" type="button" data-open-inventory-movement><i class="bi bi-plus-lg" aria-hidden="true"></i> Registrar movimiento <i class="bi bi-chevron-down" aria-hidden="true"></i></button>
            <button class="inventario-toolbar-button inventario-toolbar-button--green" type="button" data-open-inventory-movement data-movement-type="entrada"><i class="bi bi-arrow-down" aria-hidden="true"></i> Entrada</button>
            <button class="inventario-toolbar-button inventario-toolbar-button--red" type="button" data-open-inventory-movement data-movement-type="salida"><i class="bi bi-arrow-up" aria-hidden="true"></i> Salida</button>
            <button class="inventario-toolbar-button inventario-toolbar-button--purple" type="button" data-open-inventory-movement data-movement-type="ajuste"><i class="bi bi-pencil" aria-hidden="true"></i> Ajuste</button>
            <button class="inventario-toolbar-button" type="button" disabled><i class="bi bi-file-earmark-excel" aria-hidden="true"></i> Importar Excel</button>
        </div>

        <form class="inventario-filters" method="get" action="<?php echo e(route('management.inventory')); ?>">
            <label class="inventario-search"><i class="bi bi-search" aria-hidden="true"></i><span class="visually-hidden">Buscar producto</span><input type="search" name="buscar" value="<?php echo e($filters['buscar'] ?? ''); ?>" placeholder="Buscar producto, SKU..."></label>
            <label><span class="visually-hidden">Filtrar por categoría</span><select name="categoria"><option value="">Todas las categorías</option><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($category->id); ?>" <?php if(($filters['categoria'] ?? null) === $category->id): echo 'selected'; endif; ?>><?php echo e($category->nombre); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
            <label><span class="visually-hidden">Filtrar por estado</span><select name="estado"><option value="">Todos los estados</option><option value="optimo" <?php if(($filters['estado'] ?? null) === 'optimo'): echo 'selected'; endif; ?>>Óptimo</option><option value="bajo" <?php if(($filters['estado'] ?? null) === 'bajo'): echo 'selected'; endif; ?>>Bajo</option><option value="critico" <?php if(($filters['estado'] ?? null) === 'critico'): echo 'selected'; endif; ?>>Crítico</option></select></label>
            <label><span class="visually-hidden">Filtrar por proveedor</span><select name="proveedor"><option value="">Todos los proveedores</option><?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($supplier->id); ?>" <?php if(($filters['proveedor'] ?? null) === $supplier->id): echo 'selected'; endif; ?>><?php echo e($supplier->nombre); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
            <button class="inventario-filter-button" type="submit"><i class="bi bi-search" aria-hidden="true"></i> Buscar</button>
            <?php if(($filters['buscar'] ?? null) || ($filters['categoria'] ?? null) || ($filters['estado'] ?? null) || ($filters['proveedor'] ?? null)): ?>
                <a class="inventario-clear-button" href="<?php echo e(route('management.inventory')); ?>">Limpiar filtros</a>
            <?php endif; ?>
        </form>

        <section class="inventario-table-card">
            <header class="inventario-card-header">
                <div class="inventario-card-title"><i class="bi bi-boxes" aria-hidden="true"></i><div><h2>Lista de inventario</h2><p><?php echo e(number_format($products->total())); ?> productos en total</p></div></div>
                <button class="inventario-view-all" type="button" data-open-inventory-movement>Registrar movimiento</button>
            </header>
            <div class="inventario-table-wrap">
                <table class="inventario-table">
                    <thead><tr><th><span class="inventario-checkbox" aria-hidden="true"></span></th><th>Producto</th><th>SKU</th><th>Categoría</th><th>Stock actual</th><th>Stock mínimo</th><th>Proveedor</th><th>Último movimiento</th><th>Estado</th><th>Acción</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $image = $productImage($product->url_imagen);
                                $status = $statusForStock((int) $product->existencias);
                                $movement = $latestMovements->get($product->id);
                                $movementLabel = match ($movement?->tipo_movimiento) { 'entrada' => 'Entrada', 'salida' => 'Salida', 'ajuste' => 'Ajuste', default => 'Sin movimientos' };
                                $movementClass = match ($movement?->tipo_movimiento) { 'entrada' => 'entry', 'salida' => 'exit', 'ajuste' => 'adjustment', default => 'empty' };
                            ?>
                            <tr>
                                <td><span class="inventario-checkbox" aria-hidden="true"></span></td>
                                <td class="inventario-product-cell">
                                    <?php if($image): ?><img src="<?php echo e($image); ?>" alt="<?php echo e($product->nombre); ?>"><?php else: ?><span class="inventario-product-image"><i class="bi bi-box-seam" aria-hidden="true"></i></span><?php endif; ?>
                                    <span><strong><?php echo e($product->marca); ?> <?php echo e($product->nombre); ?></strong><small><?php echo e($product->nombre); ?></small></span>
                                </td>
                                <td class="inventario-sku"><?php echo e($product->etiqueta ?: 'SKU-'.str_pad((string) $product->id, 4, '0', STR_PAD_LEFT)); ?></td>
                                <td><?php echo e($product->category?->nombre ?: ($product->categoria ?: 'Sin categoría')); ?></td>
                                <td><span class="inventario-stock inventario-stock--<?php echo e($status['class']); ?>"><?php echo e(number_format($product->existencias)); ?> unidades</span></td>
                                <td class="inventario-minimum">10</td>
                                <td><?php echo e($product->suppliers->first()?->nombre ?: 'Sin proveedor'); ?></td>
                                <td class="inventario-movement inventario-movement--<?php echo e($movementClass); ?>">
                                    <?php if($movement): ?>
                                        <strong><i class="bi bi-arrow-<?php echo e($movement->tipo_movimiento === 'entrada' ? 'down' : 'up'); ?>" aria-hidden="true"></i> <?php echo e($movementLabel); ?></strong><small><?php echo e($movement->creado_en?->format('d/m/Y, H:i')); ?></small>
                                    <?php else: ?>
                                        <span>Sin movimientos</span>
                                    <?php endif; ?>
                                </td>
                                <td><span class="inventario-status inventario-status--<?php echo e($status['class']); ?>"><i class="bi bi-circle-fill" aria-hidden="true"></i><?php echo e($status['label']); ?></span></td>
                                <td class="inventario-actions-cell"><button class="inventario-view-button" type="button" data-open-inventory-movement data-inventory-product="<?php echo e($product->id); ?>" title="Registrar movimiento para <?php echo e($product->nombre); ?>"><i class="bi bi-eye" aria-hidden="true"></i><span>Ver</span></button><button class="inventario-more-button" type="button" disabled aria-label="Más opciones"><i class="bi bi-three-dots-vertical" aria-hidden="true"></i></button></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="10" class="inventario-empty"><i class="bi bi-inbox" aria-hidden="true"></i><strong>No hay productos para mostrar.</strong><span>Prueba con otros filtros de inventario.</span></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <footer class="inventario-pagination">
                <span>Mostrando <?php echo e($products->firstItem() ?? 0); ?> a <?php echo e($products->lastItem() ?? 0); ?> de <?php echo e($products->total()); ?> productos</span>
                <form class="inventario-per-page-form" method="get" action="<?php echo e(route('management.inventory')); ?>">
                    <?php $__currentLoopData = request()->except(['page', 'por_pagina']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(is_scalar($value)): ?><input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>"><?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <label for="inventario-por-pagina">Productos por página</label>
                    <select id="inventario-por-pagina" name="por_pagina" onchange="this.form.submit()" aria-label="Productos por página"><?php $__currentLoopData = [7, 8, 10, 20, 50]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($option); ?>" <?php if(($filters['por_pagina'] ?? 7) === $option): echo 'selected'; endif; ?>><?php echo e($option); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
                </form>
                <?php echo e($products->onEachSide(1)->links()); ?>

            </footer>
        </section>

        <div class="inventario-bottom-grid">
            <section class="inventario-secondary-card">
                <header class="inventario-card-header"><div class="inventario-card-title"><i class="bi bi-exclamation-triangle-fill inventario-title-icon--orange" aria-hidden="true"></i><div><h2>Alertas de inventario</h2><p>Productos con stock igual o menor al mínimo.</p></div></div><a class="inventario-view-all" href="<?php echo e(route('management.inventory', ['estado' => 'critico'])); ?>">Ver todas</a></header>
                <div class="inventario-alert-list">
                    <?php $__empty_1 = true; $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $status = $statusForStock((int) $product->existencias);
                        ?>
                        <div class="inventario-alert-row"><span class="inventario-alert-icon inventario-alert-icon--<?php echo e($status['class']); ?>"><i class="bi bi-<?php echo e($status['class'] === 'critical' ? 'box' : 'exclamation-triangle'); ?>" aria-hidden="true"></i></span><span><strong><?php echo e($product->nombre); ?></strong><small><?php echo e($product->suppliers->first()?->nombre ?: 'Sin proveedor'); ?></small></span><b class="inventario-alert-stock"><?php echo e(number_format($product->existencias)); ?></b><span class="inventario-status inventario-status--<?php echo e($status['class']); ?>"><?php echo e($status['label']); ?></span><button type="button" class="inventario-register-alert" data-open-inventory-movement data-inventory-product="<?php echo e($product->id); ?>">Registrar</button></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="inventario-secondary-empty"><i class="bi bi-shield-check" aria-hidden="true"></i><strong>Sin alertas de inventario</strong><span>Los productos activos están sobre el mínimo.</span></div>
                    <?php endif; ?>
                </div>
            </section>

            <section class="inventario-secondary-card">
                <header class="inventario-card-header"><div class="inventario-card-title"><i class="bi bi-clock-history" aria-hidden="true"></i><div><h2>Movimientos recientes</h2><p>Últimos movimientos de inventario.</p></div></div><a class="inventario-view-all" href="<?php echo e(route('management.inventory')); ?>">Ver todos</a></header>
                <div class="inventario-recent-table-wrap">
                    <table class="inventario-recent-table"><thead><tr><th>Tipo</th><th>Producto</th><th>Cantidad</th><th>Motivo</th><th>Usuario</th><th>Fecha</th></tr></thead><tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentMovements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $movementClass = $movement->tipo_movimiento === 'entrada' ? 'entry' : ($movement->tipo_movimiento === 'salida' ? 'exit' : 'adjustment');
                                $movementQuantity = $movement->tipo_movimiento === 'salida' ? -abs((int) $movement->cantidad) : (int) $movement->cantidad;
                            ?>
                            <tr><td><span class="inventario-recent-type inventario-recent-type--<?php echo e($movementClass); ?>"><i class="bi bi-<?php echo e($movement->tipo_movimiento === 'ajuste' ? 'pencil' : 'arrow-'.($movement->tipo_movimiento === 'entrada' ? 'down' : 'up')); ?>" aria-hidden="true"></i><?php echo e(ucfirst($movement->tipo_movimiento)); ?></span></td><td><?php echo e($movement->product?->marca); ?> <?php echo e($movement->product?->nombre ?: 'Producto eliminado'); ?></td><td class="inventario-quantity <?php echo e($movementQuantity >= 0 ? 'is-positive' : 'is-negative'); ?>"><?php echo e($movementQuantity >= 0 ? '+' : ''); ?><?php echo e($movementQuantity); ?></td><td><?php echo e(\Illuminate\Support\Str::limit($movement->notas, 24)); ?></td><td><?php echo e($movement->user?->nombre ?: 'Sistema'); ?></td><td><?php echo e($movement->creado_en?->format('d/m/Y H:i')); ?></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="6" class="inventario-recent-empty">Todavía no hay movimientos registrados.</td></tr>
                        <?php endif; ?>
                    </tbody></table>
                </div>
            </section>
        </div>
    </section>

    <dialog class="inventario-dialog" id="registrar-movimiento-inventario">
        <div class="inventario-dialog-card">
            <header class="inventario-dialog-header"><div class="inventario-card-title"><span class="inventario-dialog-icon"><i class="bi bi-arrow-left-right" aria-hidden="true"></i></span><div><h2>Registrar movimiento</h2><p>Actualiza las existencias y conserva la trazabilidad.</p></div></div><button class="inventario-dialog-close" type="button" data-close-inventory-movement aria-label="Cerrar"><i class="bi bi-x-lg" aria-hidden="true"></i></button></header>
            <form method="post" action="<?php echo e(route('legacy.admin.inventory.store')); ?>" class="inventario-movement-form">
                <?php echo csrf_field(); ?>
                <label><span>Producto <b>*</b></span><select name="producto_id" data-inventory-product-select required><option value="">Selecciona un producto</option><?php $__currentLoopData = $movementProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($product->id); ?>" <?php if((string) old('producto_id') === (string) $product->id): echo 'selected'; endif; ?>><?php echo e($product->marca); ?> <?php echo e($product->nombre); ?> · Stock: <?php echo e($product->existencias); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
                <label><span>Tipo de movimiento <b>*</b></span><select name="tipo_movimiento" data-inventory-type-select required><option value="entrada" <?php if(old('tipo_movimiento') === 'entrada'): echo 'selected'; endif; ?>>Entrada</option><option value="salida" <?php if(old('tipo_movimiento') === 'salida'): echo 'selected'; endif; ?>>Salida</option><option value="ajuste" <?php if(old('tipo_movimiento') === 'ajuste'): echo 'selected'; endif; ?>>Ajuste</option></select></label>
                <label><span>Cantidad <b>*</b></span><input type="number" name="cantidad" min="1" value="<?php echo e(old('cantidad')); ?>" required></label>
                <label class="inventario-form-wide"><span>Motivo u observación <b>*</b></span><textarea name="notas" maxlength="500" rows="3" required><?php echo e(old('notas')); ?></textarea></label>
                <footer class="inventario-dialog-footer"><button class="inventario-cancel-button" type="button" data-close-inventory-movement>Cancelar</button><button class="inventario-primary-button" type="submit"><i class="bi bi-check2" aria-hidden="true"></i> Guardar movimiento</button></footer>
            </form>
        </div>
    </dialog>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        (() => {
            const dialog = document.querySelector('#registrar-movimiento-inventario');
            const page = document.querySelector('[data-inventory-page]');
            const productSelect = dialog?.querySelector('[data-inventory-product-select]');
            const typeSelect = dialog?.querySelector('[data-inventory-type-select]');

            if (!dialog || !page || !productSelect || !typeSelect) {
                return;
            }

            page.querySelectorAll('[data-open-inventory-movement]').forEach((button) => {
                button.addEventListener('click', () => {
                    if (button.dataset.inventoryProduct) {
                        productSelect.value = button.dataset.inventoryProduct;
                    }
                    if (button.dataset.movementType) {
                        typeSelect.value = button.dataset.movementType;
                    }
                    dialog.showModal();
                });
            });

            document.querySelectorAll('[data-close-inventory-movement]').forEach((button) => button.addEventListener('click', () => dialog.close()));
            dialog.addEventListener('click', (event) => {
                if (event.target === dialog) {
                    dialog.close();
                }
            });

            <?php if($errors->any()): ?>
                dialog.showModal();
            <?php endif; ?>
        })();
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.administracion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\gestion\inventario\listar.blade.php ENDPATH**/ ?>