<?php $__env->startSection('title', 'Cotizaciones mayoristas'); ?>

<?php $__env->startSection('content'); ?>
    <section class="container content-page">
        <h1>Cotizaciones mayoristas</h1>

        <?php echo $__env->make('gestion.cotizaciones.crear', ['customers' => $customers, 'products' => $products], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php if (isset($component)) { $__componentOriginal87d62af1e8235b1ff48680c674499972 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87d62af1e8235b1ff48680c674499972 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inteligencia.cotizador.resumen','data' => ['quotations' => $quotations]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inteligencia.cotizador.resumen'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['quotations' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($quotations)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87d62af1e8235b1ff48680c674499972)): ?>
<?php $attributes = $__attributesOriginal87d62af1e8235b1ff48680c674499972; ?>
<?php unset($__attributesOriginal87d62af1e8235b1ff48680c674499972); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87d62af1e8235b1ff48680c674499972)): ?>
<?php $component = $__componentOriginal87d62af1e8235b1ff48680c674499972; ?>
<?php unset($__componentOriginal87d62af1e8235b1ff48680c674499972); ?>
<?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(in_array(auth()->user()->rol, ['cliente_mayorista'], true) ? 'layouts.tienda' : 'layouts.administracion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\gestion\cotizaciones\listar.blade.php ENDPATH**/ ?>