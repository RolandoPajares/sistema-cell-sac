<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['product']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['product']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $imagePath = $product->images->first()?->ruta_imagen ?: $product->url_imagen;
    $imagePath = $imagePath ? ltrim(preg_replace('~^assets/~', '', $imagePath), '/') : null;
    $salePrice = (float) ($product->precio_oferta ?? $product->precio);
    $originalPrice = (float) ($product->precio_original ?? $product->precio);
    $discount = $originalPrice > $salePrice && $originalPrice > 0 ? round((1 - ($salePrice / $originalPrice)) * 100) : 0;
?>

<article class="product-card catalog-product-card">
    <div class="product-art catalog-product-art">
        <?php if($product->etiqueta || $discount > 0): ?><span class="badge"><?php echo e($product->etiqueta ?: 'Oferta'); ?></span><?php endif; ?>
        <?php if($imagePath): ?><img class="catalog-product-photo" src="<?php echo e(asset('assets/cell-legacy/'.$imagePath)); ?>" alt="<?php echo e($product->marca); ?> <?php echo e($product->nombre); ?>" loading="lazy"><?php else: ?><div class="catalog-accessory-shape" role="img" aria-label="Imagen no disponible"><i class="bi bi-box-seam"></i></div><?php endif; ?>
    </div>
    <div class="product-body catalog-product-body">
        <div class="catalog-product-meta"><span><?php echo e($product->marca); ?></span><span><?php echo e($product->category?->nombre ?: $product->categoria); ?></span></div>
        <h2><?php echo e($product->nombre); ?></h2>
        <div class="catalog-product-specs"><?php echo e(trim(($product->almacenamiento ? $product->almacenamiento.' · ' : '').\Illuminate\Support\Str::limit(strip_tags((string) $product->descripcion), 38))); ?></div>
        <div class="catalog-product-pricing"><?php if($discount > 0): ?><div><del>S/ <?php echo e(number_format($originalPrice, 2)); ?></del><span>-<?php echo e($discount); ?>%</span></div><?php endif; ?></div>
        <p class="price catalog-product-sale-price">S/ <?php echo e(number_format($salePrice, 2)); ?></p>
        <div class="stock catalog-product-stock"><?php echo e($product->existencias > 0 ? $product->existencias.' unidades disponibles' : 'Agotado'); ?></div>
        <div class="catalog-product-actions">
            <?php if(auth()->guard()->check()): ?>
                <form action="<?php echo e(route('cart.add', $product)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="cantidad" value="1">
                    <button
                        class="btn btn-primary catalog-buy-button"
                        type="submit"
                        <?php if($product->existencias <= 0): echo 'disabled'; endif; ?>
                    >
                        <i class="bi bi-cart3" aria-hidden="true"></i>
                        <?php echo e($product->existencias > 0 ? 'Comprar' : 'Agotado'); ?>

                    </button>
                </form>
            <?php else: ?>
                <a class="btn btn-primary catalog-buy-button" href="<?php echo e(route('login')); ?>"><i class="bi bi-cart3" aria-hidden="true"></i> Comprar</a>
            <?php endif; ?>
            <a class="btn btn-ghost catalog-details-button" href="<?php echo e(route('catalog.show', $product)); ?>">Ver detalles</a>
        </div>
    </div>
</article>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\components\publico\catalogo\tarjeta-producto.blade.php ENDPATH**/ ?>