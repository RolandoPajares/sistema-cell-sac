<dialog class="tc-org__dialog" data-org-dialog aria-labelledby="tc-org-modal-title">
    <div class="tc-org__dialog-card">
        <header class="tc-org__dialog-header">
            <span class="tc-org__dialog-icon"><i class="bi bi-<?php echo e(['empresa' => 'buildings', 'sedes' => 'shop', 'almacenes' => 'box-seam', 'personal' => 'people', 'responsables' => 'person-check'][$tipo]); ?>" aria-hidden="true"></i></span>
            <div><small>Organización y Sedes · Vista de diseño</small><h2 id="tc-org-modal-title" data-org-modal-title></h2><p data-org-modal-description></p></div>
            <button type="button" class="tc-org__dialog-close" data-org-close aria-label="Cerrar formulario"><i class="bi bi-x-lg" aria-hidden="true"></i></button>
        </header>
        <form class="tc-org__dialog-form" data-org-form novalidate>
            <div class="tc-org__dialog-steps" data-org-steps aria-label="Pasos del formulario"><span data-org-step-indicator="1">1 · Información</span><span data-org-step-indicator="2">2 · Detalles</span><span data-org-step-indicator="3">3 · Confirmación</span></div>
            <div class="tc-org__dialog-body">
                <?php if($tipo === 'empresa'): ?>
                    <section data-org-step="1"><h3><i class="bi bi-buildings"></i> Identidad empresarial</h3><div class="tc-org__field-grid">
                        <label>Razón social <b>*</b><input name="razon_social" required maxlength="160" value="Technology CELL S.A.C."></label>
                        <label>Nombre comercial <b>*</b><input name="nombre_comercial" required maxlength="160" value="Technology CELL"></label>
                        <label>RUC <b>*</b><input name="ruc" required inputmode="numeric" pattern="[0-9]{11}" maxlength="11" value="20604567891"><small>11 dígitos. La unicidad se validará al integrar Laravel y MySQL.</small></label>
                        <label>Actividad económica (CIIU)<input name="ciiu" maxlength="180" value="4652 - Venta al por mayor de equipos"></label>
                        <label>Representante legal<input name="representante_legal" maxlength="160" value="Carlos Alberto Mendoza Rojas"></label>
                    </div></section>
                    <section data-org-step="2" hidden><h3><i class="bi bi-geo-alt"></i> Contacto y dirección fiscal</h3><div class="tc-org__field-grid">
                        <label>Correo corporativo <b>*</b><input name="correo_corporativo" type="email" required value="contacto@technologycell.com.pe"></label>
                        <label>Teléfono<input name="telefono" type="tel" maxlength="30" value="(01) 437-8900"></label>
                        <label>Sitio web<input name="sitio_web" type="url" placeholder="https://..." value="https://technologycell.com.pe"></label>
                        <label>Dirección fiscal <b>*</b><input name="direccion_fiscal" required maxlength="255" value="Av. Javier Prado Este 560"></label>
                        <label>Distrito<input name="distrito" maxlength="100" value="San Isidro"></label>
                        <label>Provincia<input name="provincia" maxlength="100" value="Lima"></label>
                        <label>Departamento<input name="departamento" maxlength="100" value="Lima"></label>
                    </div></section>
                    <section data-org-step="3" hidden><h3><i class="bi bi-image"></i> Logotipo y documentos</h3><div class="tc-org__field-grid">
                        <label>Logotipo (opcional)<input name="logo" type="file" accept="image/png,image/jpeg,image/svg+xml"><small>Solo vista previa local; máximo 5 MB. No se subirá ningún archivo.</small></label>
                        <label>Documento corporativo (opcional)<input name="documento" type="file" accept="application/pdf,image/png,image/jpeg"><small>PDF, PNG o JPG; máximo 10 MB. No se guardará.</small></label>
                        <label>Tipo de documento<select name="tipo_documento"><option value="">Seleccionar…</option><option>Ficha RUC</option><option>Escritura de constitución</option><option>Poder del representante legal</option><option>Otro</option></select></label>
                        <label>Observaciones<textarea name="observaciones" maxlength="500" rows="3"></textarea></label>
                    </div></section>
                <?php elseif($tipo === 'sedes'): ?>
                    <section data-org-step="1"><h3><i class="bi bi-shop"></i> Identificación de la sede</h3><div class="tc-org__field-grid">
                        <label>Nombre de la sede <b>*</b><input name="nombre" required maxlength="160" placeholder="Ej. Sede Principal - Lima"></label>
                        <label>Código de sede <b>*</b><input name="codigo" required maxlength="30" pattern="[A-Za-z0-9_-]+" placeholder="Ej. SED-LIM-01"><small>Unicidad pendiente de validación backend.</small></label>
                        <label>Tipo<select name="tipo"><option>Tienda</option><option>Oficina</option><option>Centro de distribución</option></select></label>
                        <label>Estado propuesto<select name="estado"><option>Activa</option><option>En implementación</option><option>Inactiva</option></select></label>
                    </div></section>
                    <section data-org-step="2" hidden><h3><i class="bi bi-geo-alt"></i> Ubicación y contacto</h3><div class="tc-org__field-grid">
                        <label>Ciudad <b>*</b><input name="ciudad" required maxlength="100"></label><label>Dirección <b>*</b><input name="direccion" required maxlength="255"></label>
                        <label>Teléfono<input name="telefono" type="tel" maxlength="30"></label><label>Correo<input name="correo" type="email"></label>
                        <label>Responsable existente<select name="responsable"><option value="">Asignar posteriormente</option><option>Rosa Campos</option><option>José Mendoza</option><option>Luis Vargas</option><option>María Gómez</option></select></label>
                    </div></section>
                <?php elseif($tipo === 'almacenes'): ?>
                    <section data-org-step="1"><h3><i class="bi bi-box-seam"></i> Identificación del almacén</h3><div class="tc-org__field-grid">
                        <label>Nombre del almacén <b>*</b><input name="nombre" required maxlength="160"></label><label>Código <b>*</b><input name="codigo" required maxlength="30" pattern="[A-Za-z0-9_-]+"><small>Unicidad pendiente de validación backend.</small></label>
                        <label>Sede <b>*</b><select name="sede" required><option value="">Seleccionar sede…</option><option>Sede Principal</option><option>Sede Norte</option><option>Sede Sur</option><option>Sede Este</option></select></label>
                        <label>Tipo<select name="tipo"><option>General</option><option>Tecnológico</option><option>Accesorios</option><option>Repuestos</option><option>Garantías</option><option>Temporal</option></select></label>
                    </div></section>
                    <section data-org-step="2" hidden><h3><i class="bi bi-layers"></i> Capacidad y gestión</h3><div class="tc-org__field-grid">
                        <label data-org-capacity-target hidden>Almacén <b>*</b><select name="almacen_objetivo"><option value="">Seleccionar almacén…</option></select></label>
                        <label>Capacidad máxima (unidades) <b>*</b><input name="capacidad" type="number" min="1" step="1" required></label>
                        <label>Encargado existente<select name="encargado"><option value="">Asignar posteriormente</option><option>Carlos Mendoza</option><option>Ana Ruiz</option><option>Luis Torres</option><option>María López</option></select></label>
                        <label>Estado<select name="estado"><option>Activo</option><option>Inactivo</option></select></label>
                        <label>Observaciones<textarea name="observaciones" maxlength="500" rows="3"></textarea></label>
                    </div></section>
                <?php elseif($tipo === 'personal'): ?>
                    <section data-org-step="1"><h3><i class="bi bi-person-check"></i> Usuario existente</h3><div class="tc-org__field-grid">
                        <label>Colaborador <b>*</b><select name="colaborador" required><option value="">Seleccionar usuario existente…</option><option>Carlos Mendoza</option><option>Lucía Ramírez</option><option>José Vargas</option><option>Paola Aguilar</option><option>Diego Rojas</option></select><small>Lista ilustrativa; se cargará desde la gestión de usuarios.</small></label>
                        <label>Sede <b>*</b><select name="sede" required><option value="">Seleccionar sede…</option><option>Sede Central</option><option>Sede Norte</option><option>Sede Sur</option><option>Sede Este</option><option>Sede Oeste</option></select></label>
                        <label>Área<input name="area" maxlength="100"></label><label>Cargo<input name="cargo" maxlength="100"></label>
                        <label>Fecha de inicio <b>*</b><input name="inicio" type="date" required></label><label>Fecha de fin<input name="fin" type="date"></label>
                    </div></section>
                <?php else: ?>
                    <section data-org-step="1"><h3><i class="bi bi-diagram-3"></i> Recurso y responsable</h3><div class="tc-org__field-grid">
                        <label>Tipo de recurso <b>*</b><select name="tipo_recurso" required><option value="">Seleccionar…</option><option>Sede</option><option>Almacén</option><option>Área</option></select></label>
                        <label>Recurso o unidad <b>*</b><input name="recurso" required maxlength="160" placeholder="Seleccionar recurso existente al integrar datos"></label>
                        <label>Sede <b>*</b><select name="sede" required><option value="">Seleccionar sede…</option><option>Oficina Central</option><option>Sede Principal</option><option>Sede Norte</option><option>Sede Sur</option></select></label>
                        <label>Nuevo responsable <b>*</b><select name="responsable" required><option value="">Seleccionar usuario existente…</option><option>Carlos Mendoza</option><option>Ana Torres</option><option>Luis Rojas</option><option>María Gómez</option><option>Javier Salazar</option><option>Elena Paredes</option><option>Ricardo Vega</option><option>Daniel Castro</option></select></label>
                        <label>Cargo <b>*</b><input name="cargo" required maxlength="100"></label>
                    </div></section>
                    <section data-org-step="2" hidden><h3><i class="bi bi-calendar-check"></i> Vigencia y relevo</h3><div class="tc-org__field-grid">
                        <label>Fecha de inicio <b>*</b><input name="inicio" type="date" required></label><label>Fecha de fin<input name="fin" type="date"></label>
                        <label>Motivo <b>*</b><textarea name="motivo" required minlength="10" maxlength="500" rows="3" placeholder="Explica el motivo de la asignación o relevo"></textarea></label>
                        <label>Responsable anterior<input name="anterior" readonly placeholder="Se mostrará al seleccionar una asignación"></label>
                    </div><p class="tc-org__dialog-note">El relevo de una persona responsable requerirá confirmación y trazabilidad cuando exista integración backend.</p></section>
                <?php endif; ?>
            </div>
            <p class="tc-org__dialog-feedback" data-org-feedback role="status" aria-live="polite"></p>
            <footer class="tc-org__dialog-footer"><button type="button" class="tc-org__button" data-org-close>Cancelar</button><button type="button" class="tc-org__button" data-org-prev hidden>Anterior</button><button type="button" class="tc-org__button tc-org__button--primary" data-org-next>Siguiente</button><button type="button" class="tc-org__button tc-org__button--primary" data-org-save hidden>Guardar</button></footer>
        </form>
    </div>
</dialog>
<dialog class="tc-org__dialog tc-org__dialog--small" data-org-detail-dialog aria-labelledby="tc-org-detail-title"><div class="tc-org__dialog-card"><header class="tc-org__dialog-header"><span class="tc-org__dialog-icon"><i class="bi bi-eye" aria-hidden="true"></i></span><div><small>Organización y Sedes · Datos ilustrativos</small><h2 id="tc-org-detail-title">Detalle</h2><p>Consulta del registro mostrado en esta pantalla.</p></div><button type="button" class="tc-org__dialog-close" data-org-close aria-label="Cerrar detalle"><i class="bi bi-x-lg"></i></button></header><div class="tc-org__dialog-body"><dl class="tc-org__detail-list" data-org-detail-list></dl></div><footer class="tc-org__dialog-footer"><button type="button" class="tc-org__button tc-org__button--primary" data-org-close>Cerrar</button></footer></div></dialog>
<dialog class="tc-org__dialog tc-org__dialog--small" data-org-confirm-dialog aria-labelledby="tc-org-confirm-title"><div class="tc-org__dialog-card"><header class="tc-org__dialog-header"><span class="tc-org__dialog-icon"><i class="bi bi-exclamation-triangle" aria-hidden="true"></i></span><div><small>Organización y Sedes · Vista de diseño</small><h2 id="tc-org-confirm-title">Confirmar cambio de estado</h2><p data-org-confirm-description></p></div><button type="button" class="tc-org__dialog-close" data-org-close aria-label="Cerrar confirmación"><i class="bi bi-x-lg"></i></button></header><div class="tc-org__dialog-body"><label class="tc-org__confirm-label">Motivo del cambio <b>*</b><textarea required minlength="10" maxlength="500" rows="3" data-org-confirm-reason placeholder="Explica el motivo del cambio de estado"></textarea></label><p class="tc-org__dialog-note">Esta confirmación es visual; no modificará el estado del registro.</p><p class="tc-org__dialog-feedback" data-org-confirm-feedback role="status" aria-live="polite"></p></div><footer class="tc-org__dialog-footer"><button type="button" class="tc-org__button" data-org-close>Cancelar</button><button type="button" class="tc-org__button tc-org__button--primary" data-org-confirm>Confirmar</button></footer></div></dialog>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\paneles\administrador\organizacion\componentes\modales.blade.php ENDPATH**/ ?>