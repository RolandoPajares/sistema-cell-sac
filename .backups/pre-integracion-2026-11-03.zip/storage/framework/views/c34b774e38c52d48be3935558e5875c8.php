<?php $__env->startSection('title', 'Editar perfil — ventas minoristas'); ?>
<?php $__env->startSection('body_class', 'modulo-cuenta-admin'); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal42b1880e0caaf13c52610cf97b311d29 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal42b1880e0caaf13c52610cf97b311d29 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.perfil.pagina','data' => ['mode' => 'editar','role' => 'ventas_minoristas']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('perfil.pagina'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['mode' => 'editar','role' => 'ventas_minoristas']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal42b1880e0caaf13c52610cf97b311d29)): ?>
<?php $attributes = $__attributesOriginal42b1880e0caaf13c52610cf97b311d29; ?>
<?php unset($__attributesOriginal42b1880e0caaf13c52610cf97b311d29); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal42b1880e0caaf13c52610cf97b311d29)): ?>
<?php $component = $__componentOriginal42b1880e0caaf13c52610cf97b311d29; ?>
<?php unset($__componentOriginal42b1880e0caaf13c52610cf97b311d29); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.administracion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\paneles\ventas-minoristas\perfil\editar.blade.php ENDPATH**/ ?>