<div class="tc-sec__panels">
    <?php $__currentLoopData = $paneles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $panel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="tc-sec__card"><div class="tc-sec__card-heading"><h2><i class="bi <?php echo e($panel['icono'] ?? 'bi-bar-chart'); ?>" aria-hidden="true"></i><?php echo e($panel['titulo']); ?></h2></div>
            <?php if(($panel['tipo'] ?? 'barras') === 'anillo'): ?>
                <div class="tc-sec__donut-layout"><div class="tc-sec__donut" style="--tc-sec-donut: <?php echo e($panel['gradiente'] ?? 'conic-gradient(#1285f9 0 35%, #61d981 35% 58%, #a37afa 58% 80%, #ff789a 80% 100%)'); ?>"><span><strong><?php echo e($panel['valor']); ?></strong><small><?php echo e($panel['unidad'] ?? 'Total'); ?></small></span></div><ul class="tc-sec__legend"><?php $__currentLoopData = $panel['filas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><i></i><span><?php echo e($item[0]); ?></span><strong><?php echo e($item[1]); ?></strong></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
            <?php elseif(($panel['tipo'] ?? 'barras') === 'lista'): ?>
                <ul class="tc-sec__activity"><?php $__currentLoopData = $panel['filas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><span class="tc-sec__avatar"><?php echo e($item[0]); ?></span><strong><?php echo e($item[1]); ?></strong><small><?php echo e($item[2] ?? ''); ?></small></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
            <?php else: ?>
                <div class="tc-sec__bars"><?php $__currentLoopData = $panel['filas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><span><?php echo e($item[0]); ?></span><i><b style="width: <?php echo e($item[2] ?? 60); ?>%"></b></i><strong><?php echo e($item[1]); ?></strong></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
            <?php endif; ?>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views/paneles/administrador/seguridad/componentes/paneles.blade.php ENDPATH**/ ?>