<?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(\Illuminate\Support\Facades\Route::has($link['route'])): ?>
        <a class="<?php echo e(request()->routeIs($link['route']) ? 'is-active' : ''); ?>" href="<?php echo e(route($link['route'])); ?>" title="<?php echo e($link['label']); ?>">
            <i class="bi <?php echo e($link['icon']); ?>" aria-hidden="true"></i>
            <span><?php echo e($link['label']); ?></span>
        </a>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\components\panel\menu-enlaces.blade.php ENDPATH**/ ?>