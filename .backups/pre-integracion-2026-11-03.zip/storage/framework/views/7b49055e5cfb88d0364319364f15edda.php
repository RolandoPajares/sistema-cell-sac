<?php $__env->startSection('body_class', 'modulo-autenticacion'); ?>
<?php $__env->startSection('title', 'Crear cuenta'); ?>

<?php $__env->startSection('content'); ?>
<div class="auth-wrap panel">
    <h1>Crear cuenta</h1>
    <p>El registro público crea una cuenta de cliente. El acceso administrativo se concede según el rol autorizado.</p>
    <?php if($errors->any()): ?><div class="alert alert-error"><?php echo e($errors->first()); ?></div><?php endif; ?>
    <form method="post" action="<?php echo e(route('register.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Nombre completo</label>
            <input
                class="input"
                name="nombre"
                value="<?php echo e(old('nombre')); ?>"
                maxlength="120"
                required
                autocomplete="name"
            >
        </div>

        <div class="form-group">
            <label>Correo</label>
            <input
                class="input"
                type="email"
                name="correo"
                value="<?php echo e(old('correo')); ?>"
                maxlength="160"
                required
                autocomplete="email"
            >
        </div>

        <div class="form-group">
            <label>Contraseña</label>
            <input
                class="input"
                type="password"
                name="password"
                minlength="10"
                maxlength="4096"
                required
                autocomplete="new-password"
            >
        </div>

        <div class="form-group">
            <label>Confirmar contraseña</label>
            <input
                class="input"
                type="password"
                name="password_confirmation"
                maxlength="4096"
                required
                autocomplete="new-password"
            >
        </div>
        <button class="btn btn-primary" style="width:100%">Registrarme</button>
    </form>
    <p>¿Ya tienes cuenta? <a style="color: var(--primary)" href="<?php echo e(route('login')); ?>">Inicia sesión</a>.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.tienda', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\auth\register.blade.php ENDPATH**/ ?>