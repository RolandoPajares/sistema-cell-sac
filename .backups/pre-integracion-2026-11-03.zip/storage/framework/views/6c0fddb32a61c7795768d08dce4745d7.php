<!doctype html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="description" content="Celulares y accesorios originales de MD Technology Digital Cell.">
        <title><?php echo $__env->yieldContent('title', 'MD Technology Cell'); ?></title>

        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/tienda.css', 'resources/js/tienda.js']); ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap-icons/bootstrap-icons.min.css')); ?>">
        <?php echo $__env->yieldPushContent('styles'); ?>
    </head>
    <body class="<?php echo $__env->yieldContent('body_class'); ?>">
        <?php echo $__env->make('layouts.publico.encabezado', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php if (! (request()->routeIs('home'))): ?>
            <?php echo $__env->make('components.publico.publicidad', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>

        <?php if(session('status')): ?><div class="container flash-success" role="status"><?php echo e(session('status')); ?></div><?php endif; ?>
        <?php if($errors->any()): ?><div class="container flash-error" role="alert"><?php echo e($errors->first()); ?></div><?php endif; ?>

        <main><?php echo $__env->yieldContent('content'); ?></main>

        <?php echo $__env->make('layouts.publico.pie-pagina', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <button id="toTop" class="to-top" aria-label="Subir"><i class="bi bi-arrow-up" aria-hidden="true"></i></button>
        <?php echo $__env->yieldPushContent('scripts'); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\layouts\tienda.blade.php ENDPATH**/ ?>