<?php
    $paginas = [
        'general' => [
            'titulo' => 'Configuración general', 'icono' => 'bi-gear',
            'descripcion' => 'Administra los parámetros principales del sistema, la operación del negocio y las preferencias de la plataforma.',
            'acciones' => [['Editar configuración', 'bi-pencil', 'editar'], ['Guardar preferencias', 'bi-floppy', 'preferencias']],
            'metricas' => [['Sedes configuradas', '3', 'bi-shop', 'azul', 'Ejemplo'], ['Usuarios del sistema', '18', 'bi-people', 'azul', 'Ejemplo'], ['Integraciones activas', '4', 'bi-layers', 'verde', 'Ejemplo'], ['Último respaldo', 'Hoy, 02:00', 'bi-database', 'violeta', 'Ejemplo']],
            'ruta_actual' => 'management.general_settings', 'enlace_actual' => 'Abrir configuración actual',
        ],
        'integraciones' => [
            'titulo' => 'Integraciones', 'icono' => 'bi-plug',
            'descripcion' => 'Conecta Technology CELL con servicios externos para automatizar procesos y comunicaciones.',
            'acciones' => [['Sincronizar', 'bi-arrow-repeat', 'sincronizar'], ['Nueva integración', 'bi-plus-lg', 'nueva']],
            'metricas' => [['Integraciones totales', '7', 'bi-link-45deg', 'azul', 'Ejemplo'], ['Conectadas', '6', 'bi-check-circle', 'verde', 'Ejemplo'], ['Con advertencias', '1', 'bi-exclamation-triangle', 'ambar', 'Ejemplo'], ['Desconectadas', '0', 'bi-link-45deg', 'gris', 'Ejemplo']],
            'ruta_actual' => 'management.integrations', 'enlace_actual' => 'Abrir integraciones actuales',
        ],
        'notificaciones' => [
            'titulo' => 'Notificaciones', 'icono' => 'bi-bell',
            'descripcion' => 'Gestiona canales, reglas, plantillas y preferencias de notificaciones para todo el sistema.',
            'acciones' => [['Enviar prueba', 'bi-send', 'prueba'], ['Nueva regla', 'bi-plus-lg', 'regla']],
            'metricas' => [['Notificaciones enviadas', '12 846', 'bi-send', 'azul', 'Últimos 30 días · ejemplo'], ['Pendientes', '238', 'bi-clock', 'ambar', 'En cola · ejemplo'], ['Fallidas', '97', 'bi-x-circle', 'rojo', 'Ejemplo'], ['Plantillas activas', '18', 'bi-layers', 'violeta', 'Ejemplo']],
            'ruta_actual' => 'management.notifications', 'enlace_actual' => 'Abrir notificaciones actuales',
        ],
        'seguridad' => [
            'titulo' => 'Configuración de seguridad', 'icono' => 'bi-shield-check',
            'descripcion' => 'Administra las políticas, accesos y controles de seguridad de Technology CELL.',
            'acciones' => [['Revisar seguridad', 'bi-shield-check', 'revisar'], ['Nueva política', 'bi-plus-lg', 'politica']],
            'metricas' => [['Sesiones activas', '142', 'bi-people', 'azul', 'Ejemplo'], ['Intentos bloqueados', '37', 'bi-shield-x', 'rojo', 'Ejemplo'], ['Políticas vigentes', '8', 'bi-layers', 'azul', 'Ejemplo'], ['Alertas críticas', '2', 'bi-exclamation-triangle', 'rojo', 'Ejemplo']],
            'ruta_actual' => 'management.security_settings', 'enlace_actual' => 'Abrir seguridad actual',
        ],
        'respaldos' => [
            'titulo' => 'Respaldos y recuperación', 'icono' => 'bi-database-gear',
            'descripcion' => 'Administra la programación, destinos e historial de copias de seguridad.',
            'acciones' => [['Crear respaldo', 'bi-plus-lg', 'crear'], ['Programar respaldo', 'bi-calendar', 'programar'], ['Restaurar', 'bi-arrow-counterclockwise', 'restaurar']],
            'metricas' => [['Respaldos totales', '142', 'bi-database', 'azul', 'Ejemplo'], ['Último respaldo', 'Hoy, 10:30', 'bi-calendar-check', 'verde', 'Ejemplo'], ['Almacenamiento usado', '278,4 GB', 'bi-hdd', 'azul', 'Ejemplo'], ['Puntos de recuperación', '36', 'bi-shield-check', 'violeta', 'Ejemplo']],
            'ruta_actual' => 'management.backups', 'enlace_actual' => 'Abrir respaldos actuales',
        ],
    ];
    $pagina = $paginas[$tipo];
?>

<section class="tc-cs" data-configuracion-sistema data-cs-type="<?php echo e($tipo); ?>">
    <nav class="tc-cs__breadcrumb" aria-label="Ruta de navegación"><i class="bi bi-house"></i><span>Configuración del Sistema</span><i class="bi bi-chevron-right"></i><strong><?php echo e($pagina['titulo']); ?></strong></nav>
    <header class="tc-cs__header"><div class="tc-cs__title"><span class="tc-cs__title-icon"><i class="bi <?php echo e($pagina['icono']); ?>"></i></span><div><h1><?php echo e($pagina['titulo']); ?></h1><p><?php echo e($pagina['descripcion']); ?></p></div></div><div class="tc-cs__actions"><?php $__currentLoopData = $pagina['acciones']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><button type="button" class="tc-cs__button <?php echo e($loop->last ? 'tc-cs__button--primary' : ''); ?>" data-cs-action="<?php echo e($accion[2]); ?>"><i class="bi <?php echo e($accion[1]); ?>"></i><?php echo e($accion[0]); ?></button><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></header>
    <div class="tc-cs__notice"><i class="bi bi-eye"></i><strong>Vista de diseño</strong><span>Las cifras y estados son ilustrativos. Ninguna opción de esta pantalla altera la configuración.</span></div>
    <div class="tc-cs__metrics"><?php $__currentLoopData = $pagina['metricas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metrica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><article class="tc-cs__metric tc-cs__metric--<?php echo e($metrica[3]); ?>"><span><i class="bi <?php echo e($metrica[2]); ?>"></i></span><div><small><?php echo e($metrica[0]); ?></small><strong><?php echo e($metrica[1]); ?></strong><em><?php echo e($metrica[4]); ?></em></div></article><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
    <?php echo $__env->make('paneles.administrador.configuracion-sistema.componentes.'.$tipo, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <dialog class="tc-cs__dialog" data-cs-dialog aria-labelledby="tc-cs-dialog-title"><div class="tc-cs__dialog-card"><header><span class="tc-cs__title-icon"><i class="bi <?php echo e($pagina['icono']); ?>"></i></span><div><h2 id="tc-cs-dialog-title" data-cs-dialog-title>Configuración</h2><p>Formulario de diseño; no se guardan cambios.</p></div><button type="button" data-cs-close aria-label="Cerrar"><i class="bi bi-x-lg"></i></button></header><div class="tc-cs__dialog-body"><div data-cs-dialog-fields></div><p data-cs-feedback>Esta vista no envía datos al servidor.</p></div><footer><button type="button" class="tc-cs__button" data-cs-close>Cancelar</button><button type="button" class="tc-cs__button tc-cs__button--primary" data-cs-confirm>Continuar cuando se integre</button></footer></div></dialog>
</section>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\paneles\administrador\configuracion-sistema\componentes\pagina.blade.php ENDPATH**/ ?>