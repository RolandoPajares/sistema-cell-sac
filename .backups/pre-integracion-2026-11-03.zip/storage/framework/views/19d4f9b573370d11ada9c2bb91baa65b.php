
<?php
    $visibleRoutes = [
        'home',
        'dashboard',
        'recommendations',
        'comparison',
        'assistant',
        'smart.optimizer',
        'management.inventory',
        'management.suppliers',
        'management.purchases',
    ];
    $links = array_values(array_filter($links ?? [], static fn (array $link): bool => in_array($link['route'], $visibleRoutes, true)));
?>

<?php echo $__env->make('components.panel.menu-enlaces', ['links' => $links], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views/paneles/compras-logistica/menu.blade.php ENDPATH**/ ?>