<?php ($module = require resource_path('views/gestion/pagos/datos.php')); ?>

<?php echo $__env->make('paneles.administrador.componentes.finanzas-modulo', ['module' => $module], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\paneles\administrador\finanzas\pagos\listar.blade.php ENDPATH**/ ?>