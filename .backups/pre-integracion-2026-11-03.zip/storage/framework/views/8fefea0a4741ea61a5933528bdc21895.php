<?php $__env->startSection('title', 'Asignación de roles'); ?>
<?php $__env->startSection('content'); ?>
    <section class="admin-page">
        <header class="admin-page-head"><div><span class="eyebrow">Seguridad y delegación</span><h1>Asignaciones de roles</h1><p>Asigna acceso global o por sede sin sustituir las asignaciones existentes.</p></div></header>

        <?php if (! ($ready)): ?>
            <div class="admin-alert admin-alert--error" role="status">Las tablas RBAC aún no existen en esta base. Aplica y revisa la migración aditiva antes de administrar asignaciones.</div>
        <?php else: ?>
            <div class="form-card">
                <div class="table-responsive"><table class="table align-middle"><thead><tr><th>Usuario</th><th>Asignaciones actuales</th><th>Nueva asignación</th></tr></thead><tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><strong><?php echo e($user->nombre); ?></strong><br><small><?php echo e($user->correo); ?></small></td>
                            <td>
                                <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="role-assignment-row"><span><?php echo e($role->nombre); ?> · Empresa</span><?php if($role->pivot->activo): ?><form method="post" action="<?php echo e(route('management.user_assignments.revoke', [$user->id, $role->id])); ?>" data-confirm="¿Revocar este rol global?"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-outline-danger btn-sm" type="submit">Revocar</button></form><?php else: ?><span>Revocado</span><?php endif; ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $user->rolesPorSede; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="role-assignment-row"><span><?php echo e($role->nombre); ?> · Sede #<?php echo e($role->pivot->sede_id); ?></span><?php if($role->pivot->activo): ?><form method="post" action="<?php echo e(route('management.user_assignments.revoke_site', [$user->id, $role->id, $role->pivot->sede_id])); ?>" data-confirm="¿Revocar este rol en la sede?"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-outline-danger btn-sm" type="submit">Revocar</button></form><?php else: ?><span>Revocado</span><?php endif; ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if($user->roles->isEmpty() && $user->rolesPorSede->isEmpty()): ?><span>Sin asignaciones RBAC</span><?php endif; ?>
                            </td>
                            <td>
                                <form method="post" action="<?php echo e(route('management.user_assignments.store', $user)); ?>" class="assignment-form">
                                    <?php echo csrf_field(); ?>
                                    <label>Rol<select name="rol_id" required><option value="">Selecciona</option><?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($role->id); ?>"><?php echo e($role->nombre); ?> · <?php echo e($role->alcance_permitido); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
                                    <label>Asignación<select name="alcance" required><option value="empresa">Cuenta / empresa</option><option value="sede">Sede</option></select></label>
                                    <label>Sede<select name="sede_id"><option value="">Selecciona si corresponde</option><?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($site->id); ?>"><?php echo e($site->nombre); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
                                    <label>Vigente hasta<input type="date" name="vigente_hasta" min="<?php echo e(now()->addDay()->toDateString()); ?>"></label>
                                    <button class="btn btn-primary btn-sm" type="submit">Asignar rol</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="3">No hay usuarios en el sistema.</td></tr>
                    <?php endif; ?>
                </tbody></table></div>
                <?php echo e($users->links()); ?>

            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.administracion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\gestion\roles-permisos\asignaciones.blade.php ENDPATH**/ ?>