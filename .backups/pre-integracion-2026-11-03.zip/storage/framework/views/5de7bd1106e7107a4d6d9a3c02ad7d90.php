<?php $__env->startSection('title', $pagina['titulo'].' — Vista de diseño'); ?>
<?php $__env->startSection('body_class', 'modulo-finanzas-facturacion'); ?>
<?php $__env->startSection('content'); ?>
<section class="tc-ff" data-finanzas-diseno>
    <header class="tc-ff__header">
        <div>
            <div class="tc-ff__breadcrumb"><i class="bi bi-house" aria-hidden="true"></i><span>Finanzas y Facturación</span><i class="bi bi-chevron-right" aria-hidden="true"></i><strong><?php echo e($pagina['titulo']); ?></strong></div>
            <h1><i class="bi <?php echo e($pagina['icono']); ?>" aria-hidden="true"></i><?php echo e($pagina['titulo']); ?></h1>
            <p><?php echo e($pagina['descripcion']); ?></p>
        </div>
        <div class="tc-ff__header-actions">
            <?php $__currentLoopData = $pagina['acciones']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button class="tc-ff__button <?php echo e(($accion['primaria'] ?? false) ? 'tc-ff__button--primary' : ''); ?>" type="button" disabled title="Disponible al conectar la operación real"><i class="bi <?php echo e($accion['icono']); ?>" aria-hidden="true"></i><?php echo e($accion['texto']); ?></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </header>

    <div class="tc-ff__notice" role="status"><i class="bi bi-eye" aria-hidden="true"></i><strong>Vista de diseño</strong><span>Las cifras y registros son ejemplos; ninguna acción modifica datos.</span><?php if(! empty($pagina['rutaReal'])): ?><a href="<?php echo e(route($pagina['rutaReal'])); ?>">Abrir pantalla actual <i class="bi bi-arrow-right" aria-hidden="true"></i></a><?php endif; ?></div>

    <div class="tc-ff__metrics">
        <?php $__currentLoopData = $pagina['metricas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metrica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="tc-ff__metric tc-ff__metric--<?php echo e($metrica['tono'] ?? 'azul'); ?>"><span class="tc-ff__metric-icon"><i class="bi <?php echo e($metrica['icono']); ?>" aria-hidden="true"></i></span><div><small><?php echo e($metrica['titulo']); ?></small><strong><?php echo e($metrica['valor']); ?></strong><span><?php echo e($metrica['detalle'] ?? 'Dato ilustrativo'); ?></span></div></article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="tc-ff__filters">
        <label class="tc-ff__search"><i class="bi bi-search" aria-hidden="true"></i><input type="search" data-ff-search placeholder="<?php echo e($pagina['buscar']); ?>" aria-label="<?php echo e($pagina['buscar']); ?>"></label>
        <div class="tc-ff__filter-fields">
            <?php $__currentLoopData = $pagina['filtros']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filtro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label><span><?php echo e($filtro['titulo']); ?></span><select data-ff-filter="<?php echo e($filtro['campo']); ?>"><option value=""><?php echo e($filtro['todos'] ?? 'Todos'); ?></option><?php $__currentLoopData = $filtro['opciones']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($opcion); ?>"><?php echo e($opcion); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <button class="tc-ff__button tc-ff__button--primary" type="button" data-ff-apply><i class="bi bi-funnel" aria-hidden="true"></i>Aplicar filtros</button>
        </div>
    </div>

    <div class="tc-ff__main-grid">
        <article class="tc-ff__card tc-ff__table-card">
            <div class="tc-ff__card-heading"><h2><i class="bi <?php echo e($pagina['tablaIcono'] ?? 'bi-list-ul'); ?>" aria-hidden="true"></i><?php echo e($pagina['tablaTitulo']); ?></h2><small>Mostrando <?php echo e(count($pagina['filas'])); ?> registros de ejemplo</small></div>
            <div class="tc-ff__table-wrap"><table><thead><tr><?php $__currentLoopData = $pagina['columnas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $columna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th><?php echo e($columna); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><th>Acciones</th></tr></thead><tbody>
                <?php $__currentLoopData = $pagina['filas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-ff-row <?php $__currentLoopData = ($fila['filtros'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campo => $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> data-ff-<?php echo e($campo); ?>="<?php echo e($valor); ?>" <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php $__currentLoopData = $fila['celdas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $celda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><td><?php if(is_array($celda)): ?><span class="tc-ff__pill tc-ff__pill--<?php echo e($celda['tono'] ?? 'azul'); ?>"><?php echo e($celda['texto']); ?></span><?php else: ?><?php echo e($celda); ?><?php endif; ?></td><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><td><div class="tc-ff__row-actions"><button type="button" disabled title="Registro de ejemplo"><i class="bi bi-eye" aria-hidden="true"></i></button><button type="button" disabled title="Acciones pendientes"><i class="bi bi-three-dots-vertical" aria-hidden="true"></i></button></div></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody></table></div><p class="tc-ff__empty" data-ff-empty hidden>No hay registros de ejemplo que coincidan con los filtros.</p>
        </article>
        <aside class="tc-ff__card tc-ff__aside"><h2><i class="bi <?php echo e($pagina['aside']['icono']); ?>" aria-hidden="true"></i><?php echo e($pagina['aside']['titulo']); ?></h2><p><?php echo e($pagina['aside']['descripcion'] ?? 'Panel ilustrativo.'); ?></p>
            <?php if(($pagina['aside']['tipo'] ?? 'formulario') === 'resumen'): ?>
                <div class="tc-ff__summary"><strong><?php echo e($pagina['aside']['destacado']); ?></strong><?php $__currentLoopData = $pagina['aside']['filas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><span><?php echo e($fila[0]); ?></span><b><?php echo e($fila[1]); ?></b></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
            <?php else: ?>
                <div class="tc-ff__form-grid"><?php $__currentLoopData = $pagina['aside']['campos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><label class="<?php echo e(($campo['ancho'] ?? '') === 'completo' ? 'tc-ff__form-full' : ''); ?>"><?php echo e($campo['etiqueta']); ?> <?php if($campo['requerido'] ?? false): ?><em>*</em><?php endif; ?> <?php if(($campo['tipo'] ?? 'select') === 'textarea'): ?><textarea disabled placeholder="<?php echo e($campo['ayuda']); ?>"></textarea><?php elseif(($campo['tipo'] ?? '') === 'texto'): ?><input type="text" disabled placeholder="<?php echo e($campo['ayuda']); ?>"><?php else: ?><select disabled><option><?php echo e($campo['ayuda']); ?></option></select><?php endif; ?></label><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
                <button class="tc-ff__button tc-ff__button--primary tc-ff__submit" type="button" disabled><i class="bi <?php echo e($pagina['aside']['icono']); ?>" aria-hidden="true"></i><?php echo e($pagina['aside']['accion']); ?></button>
            <?php endif; ?>
        </aside>
    </div>

    <div class="tc-ff__bottom-grid">
        <?php $__currentLoopData = $pagina['paneles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $panel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="tc-ff__card"><div class="tc-ff__card-heading"><h2><i class="bi <?php echo e($panel['icono']); ?>" aria-hidden="true"></i><?php echo e($panel['titulo']); ?></h2></div>
                <?php if($panel['tipo'] === 'anillo'): ?>
                    <div class="tc-ff__donut-layout"><div class="tc-ff__donut" style="--tc-ff-donut: <?php echo e($panel['gradiente']); ?>"><span><strong><?php echo e($panel['valor']); ?></strong><small><?php echo e($panel['unidad']); ?></small></span></div><ul class="tc-ff__legend"><?php $__currentLoopData = $panel['filas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><i></i><span><?php echo e($fila[0]); ?></span><b><?php echo e($fila[1]); ?></b></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
                <?php elseif($panel['tipo'] === 'columnas'): ?>
                    <div class="tc-ff__columns" role="img" aria-label="Gráfico ilustrativo: <?php echo e($panel['titulo']); ?>"><?php $__currentLoopData = $panel['filas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><b><?php echo e($fila[1]); ?></b><i style="height: <?php echo e($fila[2]); ?>%"></i><small><?php echo e($fila[0]); ?></small></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
                <?php elseif($panel['tipo'] === 'barras'): ?>
                    <div class="tc-ff__bars"><?php $__currentLoopData = $panel['filas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><span><?php echo e($fila[0]); ?></span><i><b style="width: <?php echo e($fila[2]); ?>%"></b></i><strong><?php echo e($fila[1]); ?></strong></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
                <?php else: ?>
                    <div class="tc-ff__ranking"><?php $__currentLoopData = $panel['filas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><b><?php echo e($loop->iteration); ?></b><span><?php echo e($fila[0]); ?></span><strong><?php echo e($fila[1]); ?></strong></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
                <?php endif; ?>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.administracion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\paneles\administrador\finanzas-facturacion\componentes\pagina.blade.php ENDPATH**/ ?>