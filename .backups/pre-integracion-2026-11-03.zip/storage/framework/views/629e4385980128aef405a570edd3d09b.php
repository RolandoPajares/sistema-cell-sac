<?php $__env->startSection('body_class', 'modulo-autenticacion'); ?>
<?php $__env->startSection('title', 'Iniciar sesión'); ?>

<?php $__env->startSection('content'); ?>
<div class="auth-wrap panel">
    <h1>Iniciar sesión</h1>
    <p>Los administradores son enviados automáticamente al panel de gestión.</p>
    <?php if($errors->any()): ?><div class="alert alert-error"><?php echo e($errors->first()); ?></div><?php endif; ?>
    <form method="post" action="<?php echo e(route('login.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Correo</label>
            <input
                class="input"
                type="email"
                name="correo"
                value="<?php echo e(old('correo')); ?>"
                maxlength="160"
                required
                autocomplete="email"
            >
        </div>
        <div class="form-group">
            <label>Contraseña</label>
            <input
                class="input"
                type="password"
                name="password"
                maxlength="4096"
                required
                autocomplete="current-password"
            >
        </div>
        <button class="btn btn-primary" style="width:100%">Ingresar</button>
    </form>
    <p>¿No tienes cuenta? <a style="color: var(--primary)" href="<?php echo e(route('register')); ?>">Regístrate aquí</a>.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.tienda', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views/auth/login.blade.php ENDPATH**/ ?>