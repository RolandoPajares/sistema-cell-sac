<?php
    $moduleKey = $module['key'];
    $pageTitles = [
        'configuracion-empresa' => 'Datos de empresa',
        'configuracion-comercial' => 'Configuración comercial',
        'configuracion-seguridad' => 'Seguridad del sistema',
        'configuracion-general' => 'Configuración general',
    ];
    $pageTitle = $pageTitles[$moduleKey] ?? $module['title'];
?>

<section class="admin-settings-page admin-settings-page--<?php echo e($moduleKey); ?>" data-admin-settings="<?php echo e($moduleKey); ?>">
    <header class="admin-settings-header">
        <nav class="admin-settings-breadcrumb" aria-label="Ruta de navegación">
            <span>Administración</span>
            <i class="bi bi-chevron-right" aria-hidden="true"></i>
            <span>Configuración</span>
            <i class="bi bi-chevron-right" aria-hidden="true"></i>
            <strong><?php echo e($pageTitle); ?></strong>
        </nav>
        <div class="admin-settings-heading-row">
            <div>
                <span class="admin-settings-eyebrow"><i class="bi <?php echo e($module['icon']); ?>" aria-hidden="true"></i> Configuración</span>
                <h1><?php echo e($pageTitle); ?></h1>
                <p><?php echo e($module['description']); ?></p>
            </div>
            <div class="admin-settings-actions">
                <button class="admin-settings-button admin-settings-button--secondary" type="button" data-settings-reset>
                    <i class="bi bi-arrow-counterclockwise" aria-hidden="true"></i>
                    Descartar cambios
                </button>
                <button class="admin-settings-button admin-settings-button--primary" type="submit" form="admin-settings-form-<?php echo e($moduleKey); ?>">
                    <i class="bi bi-save" aria-hidden="true"></i>
                    Guardar cambios
                </button>
            </div>
        </div>
    </header>

    <div class="admin-settings-notice" role="note">
        <i class="bi bi-info-circle" aria-hidden="true"></i>
        <span>Vista administrativa preparada para CELL SAC. Los cambios quedarán disponibles cuando este módulo se conecte al backend.</span>
    </div>

    <form class="admin-settings-form" id="admin-settings-form-<?php echo e($moduleKey); ?>" data-settings-form>
        <?php echo $__env->make('paneles.administrador.configuracion.' . $moduleKey . '.editar', ['module' => $module], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </form>

    <div class="admin-settings-feedback" data-settings-feedback role="status" aria-live="polite" hidden></div>
</section>
<?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\paneles\administrador\componentes\configuracion-modulo.blade.php ENDPATH**/ ?>