<?php $__env->startSection('title', 'Exportaciones autorizadas · Vista de diseño'); ?>
<?php $__env->startSection('body_class', 'modulo-analisis-auditoria'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('paneles.administrador.analisis-auditoria.componentes.pagina', ['tipo' => 'exportaciones'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.administracion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dwa2\sistema-cell-sac\resources\views\paneles\administrador\analisis-auditoria\exportaciones\listar.blade.php ENDPATH**/ ?>