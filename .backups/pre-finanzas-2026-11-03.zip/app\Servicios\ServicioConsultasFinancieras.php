<?php

namespace App\Servicios;

use App\Models\Finanzas\Pago;
use App\Models\Finanzas\Reembolso;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;

class ServicioConsultasFinancieras
{
    public function __construct(private ServicioAutorizacion $authorization) {}

    /**
     * @param  array{buscar?:string|null,tipo?:string|null,estado?:string|null,desde?:string|null,hasta?:string|null}  $filters
     * @return Builder<Pago>
     */
    public function pagos(User $actor, array $filters): Builder
    {
        $this->authorization->assertAllowed($actor, 'gestion.pagos.consultar');

        return $this->authorization->scopeRecordsFor(Pago::query(), $actor, 'gestion.pagos.consultar')
            ->with([
                'medioPago:id,nombre',
                'usuario:id,nombre',
                'pedido:id,usuario_id',
                'pedido.user:id,nombre',
                'venta:id,cliente_id,codigo',
                'venta.cliente:id,nombre_contacto,razon_social',
                'compra:id,proveedor_id,numero_referencia',
                'compra.supplier:id,nombre',
            ])
            ->when($filters['buscar'] ?? null, static function (Builder $query, string $search): void {
                $query->where(static function (Builder $searchQuery) use ($search): void {
                    $searchQuery->where('codigo', 'like', '%'.$search.'%')
                        ->orWhere('referencia', 'like', '%'.$search.'%');
                    if (ctype_digit($search)) {
                        $searchQuery->orWhere('pedido_id', (int) $search)
                            ->orWhere('venta_id', (int) $search)
                            ->orWhere('compra_id', (int) $search);
                    }
                });
            })
            ->when($filters['tipo'] ?? null, static fn (Builder $query, string $type): Builder => $query->where('tipo', $type))
            ->when($filters['estado'] ?? null, static fn (Builder $query, string $state): Builder => $query->where('estado', $state))
            ->when($filters['desde'] ?? null, static fn (Builder $query, string $date): Builder => $query->whereDate('fecha_pago', '>=', $date))
            ->when($filters['hasta'] ?? null, static fn (Builder $query, string $date): Builder => $query->whereDate('fecha_pago', '<=', $date));
    }

    /**
     * @param  array{buscar?:string|null,estado?:string|null,desde?:string|null,hasta?:string|null}  $filters
     * @return Builder<Reembolso>
     */
    public function reembolsos(User $actor, array $filters): Builder
    {
        $this->authorization->assertAllowed($actor, 'gestion.reembolsos.consultar');

        return Reembolso::query()
            ->with([
                'pago:id,codigo,empresa_id,sede_id',
                'devolucion:id,codigo,cliente_id',
                'devolucion.customer:id,nombre_contacto,razon_social',
            ])
            ->whereHas('pago', function (Builder $paymentQuery) use ($actor): void {
                $this->authorization->scopeRecordsFor($paymentQuery, $actor, 'gestion.reembolsos.consultar');
            })
            ->when($filters['buscar'] ?? null, static function (Builder $query, string $search): void {
                $query->where(static function (Builder $searchQuery) use ($search): void {
                    $searchQuery->whereHas('pago', static fn (Builder $paymentQuery): Builder => $paymentQuery->where('codigo', 'like', '%'.$search.'%'))
                        ->orWhereHas('devolucion', static fn (Builder $returnQuery): Builder => $returnQuery->where('codigo', 'like', '%'.$search.'%'));
                    if (ctype_digit($search)) {
                        $searchQuery->orWhere('id', (int) $search);
                    }
                });
            })
            ->when($filters['estado'] ?? null, static fn (Builder $query, string $state): Builder => $query->where('estado', $state))
            ->when($filters['desde'] ?? null, static fn (Builder $query, string $date): Builder => $query->whereDate('creado_en', '>=', $date))
            ->when($filters['hasta'] ?? null, static fn (Builder $query, string $date): Builder => $query->whereDate('creado_en', '<=', $date));
    }
}
