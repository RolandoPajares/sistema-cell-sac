<?php

namespace App\Servicios;

use App\Models\Catalogo\Producto;
use App\Models\Compras\Compra;
use App\Models\Compras\Proveedor;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class ServicioCompras
{
    private const MAX_CENTIMOS = 999999999999;

    public function __construct(
        private readonly ServicioInventario $inventario,
        private readonly RegistradorAuditoria $auditoria,
        private readonly ServicioAutorizacion $autorizacion,
    ) {}

    public function registrar(array $datos, User $actor, string $token, ?string $ip): Compra
    {
        $this->autorizacion->assertAllowed($actor, 'gestion.compras.crear');
        abort_unless(Schema::hasColumn('registros_auditoria', 'identificador_universal_evento'), 503, 'No está disponible la protección contra compras duplicadas.');
        abort_unless(preg_match('/\A[a-f0-9]{64}\z/', $token) === 1, 422, 'La solicitud de compra no es válida.');
        $ubicacion = $this->autorizacion->operationLocation($actor);
        abort_unless($ubicacion['empresa_id'] !== null && $ubicacion['sede_id'] !== null && $ubicacion['almacen_id'] !== null, 503, 'No hay un almacén autorizado disponible.');
        abort_unless($this->autorizacion->allowsRecord($actor, 'gestion.compras.crear', $ubicacion['empresa_id'], $ubicacion['sede_id']), 403);
        $hash = hash('sha256', 'compra:'.$actor->getKey().':'.$token);
        $evento = substr($hash, 0, 8).'-'.substr($hash, 8, 4).'-4'.substr($hash, 13, 3).'-a'.substr($hash, 17, 3).'-'.substr($hash, 20, 12);

        return DB::transaction(function () use ($datos, $actor, $ip, $ubicacion, $evento): Compra {
            DB::table('empresas')->where('id', $ubicacion['empresa_id'])->lockForUpdate()->firstOrFail();
            $previo = DB::table('registros_auditoria')->where('identificador_universal_evento', $evento)->lockForUpdate()->first();
            if ($previo !== null) {
                abort_unless($previo->accion === 'compra.registrada' && $previo->entidad === 'compras' && (int) $previo->usuario_id === (int) $actor->id, 409, 'La solicitud ya fue utilizada.');
                $compra = Compra::query()->whereKey($previo->entidad_id)->lockForUpdate()->firstOrFail();
                abort_unless((int) $compra->empresa_id === $ubicacion['empresa_id'] && (int) $compra->sede_id === $ubicacion['sede_id']
                    && (int) $compra->almacen_id === $ubicacion['almacen_id'] && (int) $compra->proveedor_id === (int) $datos['proveedor_id']
                    && $compra->fecha_compra->toDateString() === $datos['fecha_compra'], 409, 'La solicitud ya corresponde a otra compra.');
                $anteriores = $compra->details()->orderBy('producto_id')->get()->map(fn ($linea): array => [(int) $linea->producto_id, (int) $linea->cantidad, $this->centimos((string) $linea->costo_unitario)])->all();
                $solicitados = collect($datos['items'])->sortBy('producto_id')->map(fn (array $linea): array => [(int) $linea['producto_id'], (int) $linea['cantidad'], $this->centimos((string) $linea['costo_unitario'])])->values()->all();
                abort_unless($anteriores === $solicitados, 409, 'La solicitud ya corresponde a otros productos o costos.');

                return $compra;
            }

            $proveedor = Proveedor::query()->whereKey($datos['proveedor_id'])->where('empresa_id', $ubicacion['empresa_id'])->where('activo', true)->first();
            abort_unless($proveedor !== null, 422, 'El proveedor no está activo en la empresa autorizada.');
            $items = collect($datos['items'])->sortBy('producto_id')->values();
            abort_if($items->isEmpty() || $items->count() > 100 || $items->pluck('producto_id')->unique()->count() !== $items->count(), 422, 'Los productos de la compra no son válidos.');
            $productos = Producto::query()->whereIn('id', $items->pluck('producto_id'))->orderBy('id')->lockForUpdate()->get()->keyBy('id');
            $lineas = [];
            $total = 0;
            foreach ($items as $item) {
                $producto = $productos->get((int) $item['producto_id']);
                $cantidad = filter_var($item['cantidad'], FILTER_VALIDATE_INT);
                abort_unless($producto instanceof Producto && $producto->activo && (int) $producto->empresa_id === $ubicacion['empresa_id'], 422, 'Un producto no está activo en la empresa autorizada.');
                abort_if($cantidad === false || $cantidad < 1 || $cantidad > 1000, 422, 'La cantidad no es válida.');
                $costo = $this->centimos((string) $item['costo_unitario']);
                $importe = $costo * $cantidad;
                abort_if($importe > self::MAX_CENTIMOS - $total, 422, 'La compra supera el importe permitido.');
                $total += $importe;
                $lineas[] = ['producto_id' => $producto->id, 'cantidad' => $cantidad, 'costo_unitario' => $this->importe($costo)];
            }
            $compra = Compra::create([
                ...$ubicacion, 'proveedor_id' => $proveedor->id, 'creado_por_usuario_id' => $actor->id,
                'total' => $this->importe($total), 'estado' => 'Pendiente', 'fecha_compra' => $datos['fecha_compra'],
                'activo' => true, 'creado_en' => now(),
            ]);
            foreach ($lineas as $linea) {
                $compra->details()->create($linea);
            }
            $this->auditoria->record($actor->id, 'compra.registrada', 'compras', $compra->id, null,
                ['proveedor_id' => $proveedor->id, 'total' => $compra->total, 'items' => count($lineas)], $ip,
                scope: ['empresa_id' => $ubicacion['empresa_id'], 'sede_id' => $ubicacion['sede_id']], eventId: $evento);

            return $compra;
        }, 3);
    }

    public function aprobar(Compra $compra, User $actor, ?string $ip): Compra
    {
        return $this->cambiarEstado($compra, $actor, $ip, false);
    }

    public function recibir(Compra $compra, User $actor, ?string $ip): Compra
    {
        return $this->cambiarEstado($compra, $actor, $ip, true);
    }

    private function cambiarEstado(Compra $compra, User $actor, ?string $ip, bool $recibir): Compra
    {
        $permiso = $recibir ? 'gestion.compras.recibir' : 'gestion.compras.aprobar';
        $this->autorizacion->assertAllowed($actor, $permiso);

        return DB::transaction(function () use ($compra, $actor, $ip, $recibir, $permiso): Compra {
            $bloqueada = Compra::query()->whereKey($compra->id)->lockForUpdate()->firstOrFail();
            abort_unless($this->autorizacion->allowsRecord($actor, $permiso, (int) $bloqueada->empresa_id, (int) $bloqueada->sede_id), 403);
            $ubicacion = $this->autorizacion->operationLocation($actor);
            abort_unless((int) $bloqueada->empresa_id === $ubicacion['empresa_id'] && (int) $bloqueada->sede_id === $ubicacion['sede_id']
                && (int) $bloqueada->almacen_id === $ubicacion['almacen_id'], 409, 'La operación requiere el almacén original de la compra.');
            $destino = $recibir ? 'Recibida' : 'Aprobada';
            if ($bloqueada->estado === $destino) {
                if ($recibir) {
                    $this->comprobarRecepcion($bloqueada);
                }

                return $bloqueada;
            }
            abort_unless($bloqueada->activo && $bloqueada->estado === ($recibir ? 'Aprobada' : 'Pendiente'), 409, 'El estado de la compra no permite esta operación.');
            abort_unless(DB::table('registros_auditoria')->where('accion', 'compra.registrada')->where('entidad', 'compras')->where('entidad_id', $bloqueada->id)->exists(), 409, 'La compra requiere conciliación antes de continuar.');
            if ($recibir) {
                $lineas = $bloqueada->details()->orderBy('producto_id')->lockForUpdate()->get();
                abort_if($lineas->isEmpty() || $lineas->pluck('producto_id')->unique()->count() !== $lineas->count(), 409, 'Los detalles de compra requieren conciliación.');
                $productos = Producto::query()->whereIn('id', $lineas->pluck('producto_id'))->orderBy('id')->lockForUpdate()->get()->keyBy('id');
                foreach ($lineas as $linea) {
                    $producto = $productos->get((int) $linea->producto_id);
                    abort_unless($producto instanceof Producto && (int) $producto->empresa_id === $ubicacion['empresa_id'] && (int) $linea->cantidad > 0, 409, 'Un producto de la compra requiere conciliación.');
                    abort_if(Schema::hasTable('dispositivos') && DB::table('dispositivos')->where('producto_id', $producto->id)->exists(), 409, 'La recepción de equipos serializados requiere sus identificadores.');
                    $movimiento = $this->inventario->changeLockedProduct($producto, 'entrada', (int) $linea->cantidad, 'Ingreso por compra #'.$bloqueada->id, $actor);
                    $variante = $movimiento->variante_id === null ? null : DB::table('variantes_productos')->where('id', $movimiento->variante_id)->first(['controla_serie']);
                    abort_if($variante !== null && $variante->controla_serie, 409, 'La recepción de equipos serializados requiere sus identificadores.');
                    abort_if($linea->variante_id !== null && (int) $linea->variante_id !== (int) $movimiento->variante_id, 409, 'La variante recibida no coincide con el detalle.');
                    if ($linea->variante_id === null && $movimiento->variante_id !== null) {
                        $linea->update(['variante_id' => $movimiento->variante_id]);
                    }
                    $movimiento->update(['documento_tipo' => 'compra', 'documento_id' => (string) $bloqueada->id]);
                }
                $this->comprobarRecepcion($bloqueada);
            }
            $anterior = $bloqueada->estado;
            $bloqueada->update(['estado' => $destino]);
            $this->auditoria->record($actor->id, $recibir ? 'compra.recibida' : 'compra.aprobada', 'compras', $bloqueada->id,
                ['estado' => $anterior], ['estado' => $destino], $ip,
                scope: ['empresa_id' => $ubicacion['empresa_id'], 'sede_id' => $ubicacion['sede_id']]);

            return $bloqueada;
        }, 3);
    }

    private function comprobarRecepcion(Compra $compra): void
    {
        $lineas = $compra->details()->get(['producto_id', 'variante_id', 'cantidad']);
        $entradas = DB::table('movimientos_inventario')->where('documento_tipo', 'compra')
            ->where('documento_id', (string) $compra->id)->where('tipo_movimiento', 'entrada')
            ->where('empresa_id', $compra->empresa_id)->where('sede_id', $compra->sede_id)
            ->where('almacen_id', $compra->almacen_id)->get();
        abort_unless($lineas->isNotEmpty() && $lineas->count() === $entradas->count(), 409, 'La recepción no coincide con sus entradas de inventario.');
        foreach ($lineas as $linea) {
            $clave = $entradas->search(fn (object $movimiento): bool => (int) $movimiento->producto_id === (int) $linea->producto_id
                && (float) $movimiento->cantidad === (float) $linea->cantidad
                && $movimiento->variante_id == $linea->variante_id);
            abort_unless($clave !== false, 409, 'Un detalle de compra no coincide con su entrada de inventario.');
            $entradas->forget($clave);
        }
    }

    private function centimos(string $valor): int
    {
        abort_unless(preg_match('/\A\d{1,8}(?:\.\d{1,2})?\z/', $valor) === 1, 422, 'El costo unitario no es válido.');
        [$entero, $decimal] = array_pad(explode('.', $valor, 2), 2, '');

        return (int) $entero * 100 + (int) str_pad($decimal, 2, '0');
    }

    private function importe(int $centimos): string
    {
        return intdiv($centimos, 100).'.'.str_pad((string) ($centimos % 100), 2, '0', STR_PAD_LEFT);
    }
}
