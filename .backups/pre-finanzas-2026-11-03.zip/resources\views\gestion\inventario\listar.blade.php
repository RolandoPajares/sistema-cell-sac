@extends('layouts.administracion')

@section('title', 'Inventario')
@section('body_class', 'modulo-inventario')

@section('content')
    @php
        $productImage = static function (?string $path): ?string {
            if (!$path) {
                return null;
            }

            return str_starts_with($path, 'http') ? $path : asset(ltrim($path, '/'));
        };
        $statusForStock = static function (int $stock): array {
            return match (true) {
                $stock > 10 => ['label' => 'Óptimo', 'class' => 'optimal'],
                $stock > 0 => ['label' => 'Bajo', 'class' => 'low'],
                default => ['label' => 'Crítico', 'class' => 'critical'],
            };
        };
        $monthNames = [1 => 'Ene', 2 => 'Feb', 3 => 'Mar', 4 => 'Abr', 5 => 'May', 6 => 'Jun', 7 => 'Jul', 8 => 'Ago', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dic'];
        $today = now();
        $todayLabel = $today->format('d').' de '.$monthNames[(int) $today->format('n')].', '.$today->format('Y');
    @endphp

    <section class="inventario-page" data-inventory-page>
        <header class="inventario-hero">
            <div>
                <span class="inventario-eyebrow">Operaciones</span>
                <h1>Inventario <i class="bi bi-boxes" aria-hidden="true"></i></h1>
                <p>Controla existencias, entradas, salidas y ajustes con trazabilidad completa.</p>
            </div>
            <div class="inventario-date-card">
                <i class="bi bi-calendar3" aria-hidden="true"></i>
                <span><small>Hoy</small><strong>{{ $todayLabel }}</strong></span>
                <i class="bi bi-chevron-down" aria-hidden="true"></i>
            </div>
        </header>

        <section class="inventario-kpi-grid" aria-label="Resumen del inventario">
            <article class="inventario-kpi inventario-kpi--blue">
                <span class="inventario-kpi-icon"><i class="bi bi-box-seam" aria-hidden="true"></i></span>
                <div><small>Productos en stock</small><strong>{{ number_format($activeProducts) }}</strong><span>Productos disponibles para la venta</span></div>
                <b class="inventario-kpi-trend is-positive"><i class="bi bi-arrow-up-right" aria-hidden="true"></i> Stock disponible</b>
            </article>
            <article class="inventario-kpi inventario-kpi--orange">
                <span class="inventario-kpi-icon"><i class="bi bi-exclamation-triangle" aria-hidden="true"></i></span>
                <div><small>Stock bajo</small><strong>{{ number_format($lowStock) }}</strong><span>Productos por debajo del mínimo</span></div>
                <b class="inventario-kpi-trend {{ $lowStock > 0 ? 'is-negative' : 'is-positive' }}"><i class="bi bi-{{ $lowStock > 0 ? 'arrow-up-right' : 'check' }}" aria-hidden="true"></i> {{ $lowStock > 0 ? 'Revisar' : 'Correcto' }}</b>
            </article>
            <article class="inventario-kpi inventario-kpi--indigo">
                <span class="inventario-kpi-icon"><i class="bi bi-arrow-left-right" aria-hidden="true"></i></span>
                <div><small>Movimientos hoy</small><strong>{{ number_format($movementsToday) }}</strong><span>Entradas, salidas y ajustes</span></div>
                @if ($movementsTrend !== null)
                    <b class="inventario-kpi-trend {{ $movementsTrend >= 0 ? 'is-positive' : 'is-negative' }}"><i class="bi bi-arrow-{{ $movementsTrend >= 0 ? 'up' : 'down' }}-right" aria-hidden="true"></i> {{ number_format(abs($movementsTrend), 1) }}%</b>
                @else
                    <b class="inventario-kpi-trend">Sin periodo anterior</b>
                @endif
            </article>
            <article class="inventario-kpi inventario-kpi--green">
                <span class="inventario-kpi-icon"><i class="bi bi-cash-stack" aria-hidden="true"></i></span>
                <div><small>Valor inventario</small><strong>S/ {{ number_format($inventoryValue, 2) }}</strong><span>Valor a precio de catálogo del stock autorizado</span></div>
                <b class="inventario-kpi-trend is-positive"><i class="bi bi-graph-up-arrow" aria-hidden="true"></i> Valor actual</b>
            </article>
        </section>

        <div class="inventario-toolbar">
            <button class="inventario-primary-button" type="button" data-open-inventory-movement><i class="bi bi-plus-lg" aria-hidden="true"></i> Registrar movimiento <i class="bi bi-chevron-down" aria-hidden="true"></i></button>
            <button class="inventario-toolbar-button inventario-toolbar-button--green" type="button" data-open-inventory-movement data-movement-type="entrada"><i class="bi bi-arrow-down" aria-hidden="true"></i> Entrada</button>
            <button class="inventario-toolbar-button inventario-toolbar-button--red" type="button" data-open-inventory-movement data-movement-type="salida"><i class="bi bi-arrow-up" aria-hidden="true"></i> Salida</button>
            <button class="inventario-toolbar-button inventario-toolbar-button--purple" type="button" data-open-inventory-movement data-movement-type="ajuste"><i class="bi bi-pencil" aria-hidden="true"></i> Ajuste</button>
            <button class="inventario-toolbar-button" type="button" data-open-inventory-count><i class="bi bi-file-earmark-excel" aria-hidden="true"></i> Importar Excel</button>
        </div>

        <form class="inventario-filters" method="get" action="{{ route('management.inventory') }}">
            <label class="inventario-search"><i class="bi bi-search" aria-hidden="true"></i><span class="visually-hidden">Buscar producto</span><input type="search" name="buscar" value="{{ $filters['buscar'] ?? '' }}" placeholder="Buscar producto, SKU..."></label>
            <label><span class="visually-hidden">Filtrar por categoría</span><select name="categoria"><option value="">Todas las categorías</option>@foreach ($categories as $category)<option value="{{ $category->id }}" @selected(($filters['categoria'] ?? null) === $category->id)>{{ $category->nombre }}</option>@endforeach</select></label>
            <label><span class="visually-hidden">Filtrar por estado</span><select name="estado"><option value="">Todos los estados</option><option value="optimo" @selected(($filters['estado'] ?? null) === 'optimo')>Óptimo</option><option value="bajo" @selected(($filters['estado'] ?? null) === 'bajo')>Bajo</option><option value="critico" @selected(($filters['estado'] ?? null) === 'critico')>Crítico</option></select></label>
            <label><span class="visually-hidden">Filtrar por proveedor</span><select name="proveedor"><option value="">Todos los proveedores</option>@foreach ($suppliers as $supplier)<option value="{{ $supplier->id }}" @selected(($filters['proveedor'] ?? null) === $supplier->id)>{{ $supplier->nombre }}</option>@endforeach</select></label>
            <button class="inventario-filter-button" type="submit"><i class="bi bi-search" aria-hidden="true"></i> Buscar</button>
            @if (($filters['buscar'] ?? null) || ($filters['categoria'] ?? null) || ($filters['estado'] ?? null) || ($filters['proveedor'] ?? null))
                <a class="inventario-clear-button" href="{{ route('management.inventory') }}">Limpiar filtros</a>
            @endif
        </form>

        <section class="inventario-table-card">
            <header class="inventario-card-header">
                <div class="inventario-card-title"><i class="bi bi-boxes" aria-hidden="true"></i><div><h2>Lista de inventario</h2><p>{{ number_format($products->total()) }} productos en total</p></div></div>
                <button class="inventario-view-all" type="button" data-open-inventory-movement>Registrar movimiento</button>
            </header>
            <div class="inventario-table-wrap">
                <table class="inventario-table">
                    <thead><tr><th><span class="inventario-checkbox" aria-hidden="true"></span></th><th>Producto</th><th>SKU</th><th>Categoría</th><th>Stock actual</th><th>Stock mínimo</th><th>Proveedor</th><th>Último movimiento</th><th>Estado</th><th>Acción</th></tr></thead>
                    <tbody>
                        @forelse ($products as $product)
                            @php
                                $image = $productImage($product->url_imagen);
                                $status = $statusForStock((int) $product->existencias_alcance);
                                $movement = $latestMovements->get($product->id);
                                $movementLabel = match ($movement?->tipo_movimiento) { 'entrada' => 'Entrada', 'salida' => 'Salida', 'ajuste' => 'Ajuste', default => 'Sin movimientos' };
                                $movementClass = match ($movement?->tipo_movimiento) { 'entrada' => 'entry', 'salida' => 'exit', 'ajuste' => 'adjustment', default => 'empty' };
                            @endphp
                            <tr>
                                <td><span class="inventario-checkbox" aria-hidden="true"></span></td>
                                <td class="inventario-product-cell">
                                    @if ($image)<img src="{{ $image }}" alt="{{ $product->nombre }}">@else<span class="inventario-product-image"><i class="bi bi-box-seam" aria-hidden="true"></i></span>@endif
                                    <span><strong>{{ $product->marca }} {{ $product->nombre }}</strong><small>{{ $product->nombre }}</small></span>
                                </td>
                                <td class="inventario-sku">{{ $product->etiqueta ?: 'SKU-'.str_pad((string) $product->id, 4, '0', STR_PAD_LEFT) }}</td>
                                <td>{{ $product->category?->nombre ?: ($product->categoria ?: 'Sin categoría') }}</td>
                                <td><span class="inventario-stock inventario-stock--{{ $status['class'] }}">{{ number_format($product->existencias_alcance) }} unidades</span></td>
                                <td class="inventario-minimum">10</td>
                                <td>{{ $product->suppliers->first()?->nombre ?: 'Sin proveedor' }}</td>
                                <td class="inventario-movement inventario-movement--{{ $movementClass }}">
                                    @if ($movement)
                                        <strong><i class="bi bi-arrow-{{ $movement->tipo_movimiento === 'entrada' ? 'down' : 'up' }}" aria-hidden="true"></i> {{ $movementLabel }}</strong><small>{{ $movement->creado_en?->format('d/m/Y, H:i') }}</small>
                                    @else
                                        <span>Sin movimientos</span>
                                    @endif
                                </td>
                                <td><span class="inventario-status inventario-status--{{ $status['class'] }}"><i class="bi bi-circle-fill" aria-hidden="true"></i>{{ $status['label'] }}</span></td>
                                <td class="inventario-actions-cell"><button class="inventario-view-button" type="button" data-open-inventory-movement data-inventory-product="{{ $product->id }}" title="Registrar movimiento para {{ $product->nombre }}"><i class="bi bi-eye" aria-hidden="true"></i><span>Ver</span></button><button class="inventario-more-button" type="button" data-open-inventory-detail aria-label="Consultar información de inventario"><i class="bi bi-three-dots-vertical" aria-hidden="true"></i></button></td>
                            </tr>
                        @empty
                            <tr><td colspan="10" class="inventario-empty"><i class="bi bi-inbox" aria-hidden="true"></i><strong>No hay productos para mostrar.</strong><span>Prueba con otros filtros de inventario.</span></td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            <footer class="inventario-pagination">
                <span>Mostrando {{ $products->firstItem() ?? 0 }} a {{ $products->lastItem() ?? 0 }} de {{ $products->total() }} productos</span>
                <form class="inventario-per-page-form" method="get" action="{{ route('management.inventory') }}">
                    @foreach (request()->except(['page', 'por_pagina']) as $key => $value)
                        @if (is_scalar($value))<input type="hidden" name="{{ $key }}" value="{{ $value }}">@endif
                    @endforeach
                    <label for="inventario-por-pagina">Productos por página</label>
                    <select id="inventario-por-pagina" name="por_pagina" onchange="this.form.submit()" aria-label="Productos por página">@foreach ([7, 8, 10, 20, 50] as $option)<option value="{{ $option }}" @selected(($filters['por_pagina'] ?? 7) === $option)>{{ $option }}</option>@endforeach</select>
                </form>
                {{ $products->onEachSide(1)->links() }}
            </footer>
        </section>

        <div class="inventario-bottom-grid">
            <section class="inventario-secondary-card">
                <header class="inventario-card-header"><div class="inventario-card-title"><i class="bi bi-exclamation-triangle-fill inventario-title-icon--orange" aria-hidden="true"></i><div><h2>Alertas de inventario</h2><p>Productos con stock igual o menor al mínimo.</p></div></div><a class="inventario-view-all" href="{{ route('management.inventory', ['estado' => 'critico']) }}">Ver todas</a></header>
                <div class="inventario-alert-list">
                    @forelse ($lowStockProducts as $product)
                        @php
                            $status = $statusForStock((int) $product->existencias_alcance);
                        @endphp
                        <div class="inventario-alert-row"><span class="inventario-alert-icon inventario-alert-icon--{{ $status['class'] }}"><i class="bi bi-{{ $status['class'] === 'critical' ? 'box' : 'exclamation-triangle' }}" aria-hidden="true"></i></span><span><strong>{{ $product->nombre }}</strong><small>{{ $product->suppliers->first()?->nombre ?: 'Sin proveedor' }}</small></span><b class="inventario-alert-stock">{{ number_format($product->existencias_alcance) }}</b><span class="inventario-status inventario-status--{{ $status['class'] }}">{{ $status['label'] }}</span><button type="button" class="inventario-register-alert" data-open-inventory-movement data-inventory-product="{{ $product->id }}">Registrar</button></div>
                    @empty
                        <div class="inventario-secondary-empty"><i class="bi bi-shield-check" aria-hidden="true"></i><strong>Sin alertas de inventario</strong><span>Los productos activos están sobre el mínimo.</span></div>
                    @endforelse
                </div>
            </section>

            <section class="inventario-secondary-card">
                <header class="inventario-card-header"><div class="inventario-card-title"><i class="bi bi-clock-history" aria-hidden="true"></i><div><h2>Movimientos recientes</h2><p>Últimos movimientos de inventario.</p></div></div><a class="inventario-view-all" href="{{ route('management.inventory') }}">Ver todos</a></header>
                <div class="inventario-recent-table-wrap">
                    <table class="inventario-recent-table"><thead><tr><th>Tipo</th><th>Producto</th><th>Cantidad</th><th>Motivo</th><th>Usuario</th><th>Fecha</th></tr></thead><tbody>
                        @forelse ($recentMovements as $movement)
                            @php
                                $movementClass = $movement->tipo_movimiento === 'entrada' ? 'entry' : ($movement->tipo_movimiento === 'salida' ? 'exit' : 'adjustment');
                                $movementQuantity = $movement->tipo_movimiento === 'salida' ? -abs((int) $movement->cantidad) : (int) $movement->cantidad;
                            @endphp
                            <tr><td><span class="inventario-recent-type inventario-recent-type--{{ $movementClass }}"><i class="bi bi-{{ $movement->tipo_movimiento === 'ajuste' ? 'pencil' : 'arrow-'.($movement->tipo_movimiento === 'entrada' ? 'down' : 'up') }}" aria-hidden="true"></i>{{ ucfirst($movement->tipo_movimiento) }}</span></td><td>{{ $movement->product?->marca }} {{ $movement->product?->nombre ?: 'Producto eliminado' }}</td><td class="inventario-quantity {{ $movementQuantity >= 0 ? 'is-positive' : 'is-negative' }}">{{ $movementQuantity >= 0 ? '+' : '' }}{{ $movementQuantity }}</td><td>{{ \Illuminate\Support\Str::limit($movement->notas, 24) }}</td><td>{{ $movement->user?->nombre ?: 'Sistema' }}</td><td>{{ $movement->creado_en?->format('d/m/Y H:i') }}</td></tr>
                        @empty
                            <tr><td colspan="6" class="inventario-recent-empty">Todavía no hay movimientos registrados.</td></tr>
                        @endforelse
                    </tbody></table>
                </div>
            </section>
        </div>
    </section>

    <dialog class="inventario-dialog" id="registrar-movimiento-inventario" aria-labelledby="inventario-movimiento-titulo">
        <div class="inventario-dialog-card">
            <header class="inventario-dialog-header"><div class="inventario-card-title"><span class="inventario-dialog-icon"><i class="bi bi-arrow-left-right" aria-hidden="true"></i></span><div><h2 id="inventario-movimiento-titulo">Registrar movimiento</h2><p>Actualiza las existencias y conserva la trazabilidad.</p></div></div><button class="inventario-dialog-close" type="button" data-close-inventory-movement aria-label="Cerrar"><i class="bi bi-x-lg" aria-hidden="true"></i></button></header>
            <form method="post" action="{{ route('legacy.admin.inventory.store') }}" class="inventario-movement-form">
                @csrf
                <label><span>Producto <b>*</b></span><select name="producto_id" data-inventory-product-select required><option value="">Selecciona un producto</option>@foreach ($movementProducts as $product)<option value="{{ $product->id }}" @selected((string) old('producto_id') === (string) $product->id)>{{ $product->marca }} {{ $product->nombre }} · Stock: {{ $product->existencias_alcance }}</option>@endforeach</select></label>
                <label><span>Tipo de movimiento <b>*</b></span><select name="tipo_movimiento" data-inventory-type-select required><option value="entrada" @selected(old('tipo_movimiento') === 'entrada')>Entrada</option><option value="salida" @selected(old('tipo_movimiento') === 'salida')>Salida</option><option value="ajuste" @selected(old('tipo_movimiento') === 'ajuste')>Ajuste</option></select></label>
                <label><span>Cantidad <b>*</b></span><input type="number" name="cantidad" min="0" value="{{ old('cantidad') }}" required></label>
                <label class="inventario-form-wide"><span>Motivo u observación <b>*</b></span><textarea name="notas" maxlength="500" rows="3" required>{{ old('notas') }}</textarea></label>
                <footer class="inventario-dialog-footer"><button class="inventario-cancel-button" type="button" data-close-inventory-movement>Cancelar</button><button class="inventario-primary-button" type="submit"><i class="bi bi-check2" aria-hidden="true"></i> Guardar movimiento</button></footer>
            </form>
        </div>
    </dialog>

    <dialog class="inventario-dialog inventario-count-dialog" data-inventory-count-dialog aria-labelledby="inventory-count-title">
        <div class="inventario-dialog-card">
            <header class="inventario-dialog-header"><div class="inventario-card-title"><span class="inventario-dialog-icon"><i class="bi bi-clipboard-check" aria-hidden="true"></i></span><div><h2 id="inventory-count-title">Conteo físico de inventario</h2><p>Asistente visual; no registra ajustes ni cambia existencias.</p></div></div><button class="inventario-dialog-close" type="button" data-close-inventory-count aria-label="Cerrar"><i class="bi bi-x-lg" aria-hidden="true"></i></button></header>
            <div class="inventario-count-body">
                <p class="inventario-count-notice"><i class="bi bi-info-circle" aria-hidden="true"></i>Este flujo representa un conteo físico para revisión. No es una importación de catálogo ni una entrada de stock; aquí no se consulta el stock actual.</p>
                <nav class="inventario-count-steps" aria-label="Etapas del conteo físico"><span data-count-indicator="0">1. Plantilla</span><span data-count-indicator="1">2. Archivo</span><span data-count-indicator="2">3. Vista previa</span><span data-count-indicator="3">4. Validar</span><span data-count-indicator="4">5. Confirmar</span></nav>
                <section data-count-stage="0"><h3>1. Descargar plantilla CSV</h3><p>Plantilla compatible con Excel para registrar conteo por SKU y almacén.</p><button class="inventario-primary-button" type="button" data-count-download><i class="bi bi-download" aria-hidden="true"></i> Descargar plantilla CSV</button></section>
                <section data-count-stage="1" hidden><label class="inventario-count-field">Archivo CSV o XLSX<input type="file" accept=".csv,.xlsx" data-count-file></label><small data-count-file-name>No se ha seleccionado un archivo.</small><p>Solo se mostrará el nombre. El archivo no se leerá, transmitirá ni guardará.</p></section>
                <section data-count-stage="2" hidden><h3>3. Vista previa ilustrativa</h3><p>Ejemplo estático; no corresponde al archivo elegido.</p><div class="inventario-count-table-wrap"><table><thead><tr><th>SKU</th><th>Almacén</th><th>Unidades contadas</th><th>Motivo</th></tr></thead><tbody><tr><td>SKU-DEMO-001</td><td>Principal (ejemplo)</td><td>12</td><td>Conteo físico</td></tr></tbody></table></div></section>
                <section data-count-stage="3" hidden><h3>4. Validaciones ilustrativas</h3><ul><li>SKU y almacén deben identificarse antes de una futura conciliación.</li><li>Las unidades contadas deben ser mayores o iguales a cero.</li><li>No se comparó con existencias reales ni se calculó una diferencia.</li><li>Un ajuste requerirá motivo y confirmación en el flujo real autorizado.</li></ul></section>
                <section data-count-stage="4" hidden><label class="inventario-count-check"><input type="checkbox" data-count-ack> Confirmo que revisé el ejemplo y entiendo que la conciliación sigue pendiente.</label><p class="inventario-count-feedback" data-count-feedback role="status" aria-live="polite" hidden></p></section>
                <p class="inventario-count-error" data-count-error role="alert" hidden></p>
            </div>
            <footer class="inventario-dialog-footer inventario-count-footer"><button class="inventario-cancel-button" type="button" data-close-inventory-count>Cancelar</button><button class="inventario-cancel-button" type="button" data-count-previous hidden>Anterior</button><button class="inventario-primary-button" type="button" data-count-next>Siguiente</button><button class="inventario-primary-button" type="button" data-count-confirm hidden>Confirmar (demostración)</button></footer>
        </div>
    </dialog>

    <dialog class="inventario-dialog inventario-detail-dialog" data-inventory-detail-dialog aria-labelledby="inventory-detail-title">
        <div class="inventario-dialog-card"><header class="inventario-dialog-header"><div class="inventario-card-title"><span class="inventario-dialog-icon"><i class="bi bi-box-seam" aria-hidden="true"></i></span><div><h2 id="inventory-detail-title">Detalle de inventario</h2><p>Consulta de solo lectura con la información de esta pantalla.</p></div></div><button class="inventario-dialog-close" type="button" data-close-inventory-detail aria-label="Cerrar"><i class="bi bi-x-lg" aria-hidden="true"></i></button></header><dl class="inventario-detail-list" data-inventory-detail-fields></dl><footer class="inventario-dialog-footer"><button class="inventario-cancel-button" type="button" data-close-inventory-detail>Cerrar</button></footer></div>
    </dialog>
@endsection

@push('scripts')
    <script>
        (() => {
            const dialog = document.querySelector('#registrar-movimiento-inventario');
            const page = document.querySelector('[data-inventory-page]');
            const productSelect = dialog?.querySelector('[data-inventory-product-select]');
            const typeSelect = dialog?.querySelector('[data-inventory-type-select]');
            const countDialog = document.querySelector('[data-inventory-count-dialog]');
            const detailDialog = document.querySelector('[data-inventory-detail-dialog]');

            if (!dialog || !page || !productSelect || !typeSelect) {
                return;
            }

            page.querySelectorAll('[data-open-inventory-movement]').forEach((button) => {
                button.addEventListener('click', () => {
                    if (button.dataset.inventoryProduct) {
                        productSelect.value = button.dataset.inventoryProduct;
                    }
                    if (button.dataset.movementType) {
                        typeSelect.value = button.dataset.movementType;
                    }
                    dialog.showModal();
                });
            });

            document.querySelectorAll('[data-close-inventory-movement]').forEach((button) => button.addEventListener('click', () => dialog.close()));
            dialog.addEventListener('click', (event) => {
                if (event.target === dialog) {
                    dialog.close();
                }
            });

            const countStages = [...countDialog.querySelectorAll('[data-count-stage]')];
            const countIndicators = [...countDialog.querySelectorAll('[data-count-indicator]')];
            const countFile = countDialog.querySelector('[data-count-file]');
            const countFileName = countDialog.querySelector('[data-count-file-name]');
            const countError = countDialog.querySelector('[data-count-error]');
            const countFeedback = countDialog.querySelector('[data-count-feedback]');
            const countPrevious = countDialog.querySelector('[data-count-previous]');
            const countNext = countDialog.querySelector('[data-count-next]');
            const countConfirm = countDialog.querySelector('[data-count-confirm]');
            const countAcknowledgement = countDialog.querySelector('[data-count-ack]');
            let countStep = 0;
            let selectedCountFileName = '';

            const renderCountStep = (step) => {
                countStep = step;
                countStages.forEach((stage) => { stage.hidden = Number(stage.dataset.countStage) !== step; });
                countIndicators.forEach((indicator) => indicator.classList.toggle('is-current', Number(indicator.dataset.countIndicator) === step));
                countPrevious.hidden = step === 0;
                countNext.hidden = step === 4;
                countConfirm.hidden = step !== 4;
                countError.hidden = true;
                countFeedback.hidden = true;
            };

            page.querySelector('[data-open-inventory-count]')?.addEventListener('click', () => {
                selectedCountFileName = '';
                countFile.value = '';
                countFileName.textContent = 'No se ha seleccionado un archivo.';
                countAcknowledgement.checked = false;
                countConfirm.disabled = false;
                renderCountStep(0);
                countDialog.showModal();
            });
            page.querySelectorAll('[data-open-inventory-detail]').forEach((button) => button.addEventListener('click', () => {
                const row = button.closest('tr');
                const details = detailDialog.querySelector('[data-inventory-detail-fields]');
                const headings = [...row.closest('table').querySelectorAll('thead th')];
                const cells = [...row.querySelectorAll('td')];
                details.replaceChildren();
                cells.slice(1, headings.length - 1).forEach((cell, index) => {
                    const wrapper = document.createElement('div');
                    const term = document.createElement('dt');
                    const description = document.createElement('dd');
                    term.textContent = headings[index + 1]?.textContent.trim() ?? `Dato ${index + 1}`;
                    description.textContent = cell.textContent.trim();
                    wrapper.append(term, description);
                    details.append(wrapper);
                });
                detailDialog.showModal();
            }));
            detailDialog.querySelectorAll('[data-close-inventory-detail]').forEach((button) => button.addEventListener('click', () => detailDialog.close()));
            detailDialog.addEventListener('click', (event) => {
                if (event.target === detailDialog) {
                    detailDialog.close();
                }
            });
            countDialog.querySelectorAll('[data-close-inventory-count]').forEach((button) => button.addEventListener('click', () => countDialog.close()));
            countDialog.addEventListener('click', (event) => {
                if (event.target === countDialog) {
                    countDialog.close();
                }
            });
            countDialog.querySelector('[data-count-download]')?.addEventListener('click', () => {
                const csv = '\uFEFFsku,almacen,existencias_contadas,motivo\r\n';
                const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
                const link = document.createElement('a');
                link.href = url;
                link.download = 'plantilla-conteo-fisico.csv';
                link.click();
                window.setTimeout(() => URL.revokeObjectURL(url), 1000);
            });
            countFile.addEventListener('change', () => {
                const file = countFile.files?.[0] ?? null;
                if (file && !/\.(csv|xlsx)$/i.test(file.name)) {
                    selectedCountFileName = '';
                    countFile.value = '';
                    countFileName.textContent = 'No se ha seleccionado un archivo.';
                    countError.textContent = 'Selecciona un archivo CSV o XLSX.';
                    countError.hidden = false;
                    return;
                }
                selectedCountFileName = file?.name ?? '';
                countFileName.textContent = file ? `Seleccionado: ${file.name}` : 'No se ha seleccionado un archivo.';
                countError.hidden = true;
            });
            countPrevious.addEventListener('click', () => renderCountStep(Math.max(0, countStep - 1)));
            countNext.addEventListener('click', () => {
                if (countStep === 1 && !selectedCountFileName) {
                    countError.textContent = 'Selecciona un archivo para continuar con la vista previa ilustrativa.';
                    countError.hidden = false;
                    return;
                }
                renderCountStep(Math.min(4, countStep + 1));
            });
            countConfirm.addEventListener('click', () => {
                if (!countAcknowledgement.checked) {
                    countError.textContent = 'Confirma que revisaste el ejemplo y sus validaciones ilustrativas.';
                    countError.hidden = false;
                    return;
                }
                countFeedback.textContent = 'Funcionalidad visual. Integración pendiente. No se realizaron cambios. No se leyó el archivo, no se comparó stock y no se aplicó ningún ajuste.';
                countFeedback.hidden = false;
                countConfirm.disabled = true;
                countError.hidden = true;
            });

            @if ($errors->any())
                dialog.showModal();
            @endif
        })();
    </script>
@endpush
