@extends('layouts.administracion')

@section('title', 'Gestión de productos')
@section('body_class', 'modulo-productos')

@php
    $exportParameters = request()->query();
    $productImage = static fn (?string $path): ?string => $path
        ? (\Illuminate\Support\Str::startsWith($path, ['http://', 'https://']) ? $path : asset($path))
        : null;
@endphp

@section('content')
    <section class="productos-page" data-product-page>
        <header class="productos-hero">
            <div>
                <span class="productos-eyebrow">Administración</span>
                <h1>Gestión de productos <span aria-hidden="true">📦</span></h1>
                <p>Administra el catálogo, stock, precios y estado de tus productos.</p>
            </div>
            <div class="productos-actions">
                <button class="productos-primary-button" type="button" data-open-product-create>
                    <i class="bi bi-plus-lg" aria-hidden="true"></i>
                    Registrar nuevo producto
                </button>
                <details class="productos-export-menu">
                    <summary><i class="bi bi-upload" aria-hidden="true"></i><span>Exportar</span><i class="bi bi-chevron-down" aria-hidden="true"></i></summary>
                    <div class="productos-export-options">
                        <a href="{{ route('management.products.export', array_merge(['format' => 'pdf'], $exportParameters)) }}"><i class="bi bi-file-earmark-pdf" aria-hidden="true"></i><span>Exportar PDF<small>Documento imprimible</small></span></a>
                        <a href="{{ route('management.products.export', array_merge(['format' => 'excel'], $exportParameters)) }}"><i class="bi bi-file-earmark-spreadsheet" aria-hidden="true"></i><span>Exportar Excel<small>Archivo compatible .xls</small></span></a>
                        <a href="{{ route('management.products.export', array_merge(['format' => 'csv'], $exportParameters)) }}"><i class="bi bi-filetype-csv" aria-hidden="true"></i><span>Exportar CSV<small>Datos delimitados</small></span></a>
                    </div>
                </details>
            </div>
        </header>

        <div class="productos-kpi-grid">
            <article class="productos-kpi productos-kpi--green">
                <span class="productos-kpi-icon"><i class="bi bi-box-seam" aria-hidden="true"></i></span>
                <div><small>Productos activos</small><strong>{{ number_format($activeProducts) }}</strong>@if ($productsTrendPercent !== null)<span class="productos-kpi-trend {{ $productsTrendPercent >= 0 ? 'is-positive' : 'is-negative' }}"><i class="bi bi-arrow-{{ $productsTrendPercent >= 0 ? 'up' : 'down' }}" aria-hidden="true"></i> {{ number_format(abs($productsTrendPercent), 1) }}% <em>vs. mes anterior</em></span>@else<span class="productos-kpi-trend">Sin periodo anterior</span>@endif</div>
            </article>
            <article class="productos-kpi productos-kpi--red">
                <span class="productos-kpi-icon"><i class="bi bi-box" aria-hidden="true"></i></span>
                <div><small>Sin stock</small><strong>{{ number_format($outOfStock) }}</strong><span class="productos-kpi-trend {{ $outOfStock > 0 ? 'is-negative' : 'is-positive' }}"><i class="bi bi-{{ $outOfStock > 0 ? 'arrow-up' : 'check-circle' }}" aria-hidden="true"></i> {{ $outOfStock > 0 ? 'Reponer inventario' : 'Inventario saludable' }}</span></div>
            </article>
            <article class="productos-kpi productos-kpi--purple">
                <span class="productos-kpi-icon"><i class="bi bi-diagram-3" aria-hidden="true"></i></span>
                <div><small>Categorías</small><strong>{{ number_format($categoryCount) }}</strong><span class="productos-kpi-trend">Sin cambios</span></div>
            </article>
            <article class="productos-kpi productos-kpi--blue">
                <span class="productos-kpi-icon"><i class="bi bi-coin" aria-hidden="true"></i></span>
                <div><small>Valor inventario</small><strong>S/ {{ number_format($inventoryValue, 2) }}</strong><span class="productos-kpi-trend is-positive"><i class="bi bi-arrow-up" aria-hidden="true"></i> Valor actual</span></div>
            </article>
        </div>

        <form class="productos-filters" method="get" action="{{ route('management.products') }}">
            <label class="productos-search"><i class="bi bi-search" aria-hidden="true"></i><span class="visually-hidden">Buscar producto</span><input type="search" name="buscar" value="{{ $filters['buscar'] ?? '' }}" placeholder="Buscar producto, SKU o marca..."></label>
            <label><span class="visually-hidden">Filtrar por categoría</span><select name="categoria"><option value="">Todas las categorías</option>@foreach ($categories as $category)<option value="{{ $category->id }}" @selected(($filters['categoria'] ?? null) === $category->id)>{{ $category->nombre }}</option>@endforeach</select></label>
            <label><span class="visually-hidden">Filtrar por stock</span><select name="stock"><option value="">Todo el stock</option><option value="disponible" @selected(($filters['stock'] ?? null) === 'disponible')>Stock disponible</option><option value="bajo" @selected(($filters['stock'] ?? null) === 'bajo')>Stock bajo</option><option value="sin_stock" @selected(($filters['stock'] ?? null) === 'sin_stock')>Sin stock</option></select></label>
            <label><span class="visually-hidden">Filtrar por estado</span><select name="estado"><option value="">Todos los estados</option><option value="activo" @selected(($filters['estado'] ?? null) === 'activo')>Activos</option><option value="inactivo" @selected(($filters['estado'] ?? null) === 'inactivo')>Inactivos</option></select></label>
            <button class="productos-filter-reset" type="submit"><i class="bi bi-arrow-repeat" aria-hidden="true"></i> Aplicar filtros</button>
            @if (array_filter($filters))
                <a class="productos-filter-clear" href="{{ route('management.products') }}">Limpiar filtros</a>
            @endif
        </form>

        <div class="productos-layout">
            <section class="productos-list-card">
                <header class="productos-card-header">
                    <div class="productos-card-title"><i class="bi bi-box-seam" aria-hidden="true"></i><div><h2>Listado de productos</h2><p>Mostrando {{ $products->firstItem() ?? 0 }} - {{ $products->lastItem() ?? 0 }} de {{ $products->total() }} productos</p></div></div>
                    <label class="productos-sort"><span>Ordenar por:</span><select aria-label="Orden de productos"><option>Más recientes</option></select></label>
                </header>
                <div class="productos-table-wrap">
                    <table class="productos-table">
                        <thead><tr><th><span class="productos-checkbox" aria-hidden="true"></span></th><th>Imagen</th><th>Producto</th><th>SKU</th><th>Categoría</th><th>Precio</th><th>Stock</th><th>Estado</th><th>Acciones</th></tr></thead>
                        <tbody>
                            @forelse ($products as $product)
                                @php
                                    $image = $productImage($product->url_imagen);
                                    $productStatus = !$product->activo ? 'Inactivo' : ($product->existencias === 0 ? 'Sin stock' : ($product->precio_oferta ? 'Oferta' : 'Activo'));
                                    $statusClass = match ($productStatus) { 'Sin stock' => 'danger', 'Oferta' => 'warning', 'Inactivo' => 'muted', default => 'success' };
                                    $stockClass = $product->existencias === 0 || $product->existencias <= 5 ? 'danger' : 'success';
                                @endphp
                                <tr>
                                    <td><span class="productos-checkbox" aria-hidden="true"></span></td>
                                    <td>
                                        @if ($image)<img class="productos-image" src="{{ $image }}" alt="{{ $product->nombre }}">@else<span class="productos-image productos-image--placeholder"><i class="bi bi-phone" aria-hidden="true"></i></span>@endif
                                    </td>
                                    <td class="productos-name"><strong>{{ $product->nombre }}</strong><small>{{ $product->marca }} {{ $product->nombre }} · {{ $product->categoria ?: 'Sin categoría' }}</small></td>
                                    <td class="productos-sku">{{ $product->etiqueta ?: 'SKU-'.str_pad((string) $product->id, 4, '0', STR_PAD_LEFT) }}</td>
                                    <td><span class="productos-category">{{ $product->category?->nombre ?: 'Sin categoría' }}</span></td>
                                    <td><strong class="productos-price">S/ {{ number_format((float) $product->effective_price, 2) }}</strong></td>
                                    <td><span class="productos-stock productos-stock--{{ $stockClass }}">{{ number_format($product->existencias) }}</span></td>
                                    <td><span class="productos-status productos-status--{{ $statusClass }}">{{ $productStatus }}</span></td>
                                    <td class="productos-actions-cell">
                                        <button class="productos-action" type="button" title="Ver producto" aria-label="Ver {{ $product->nombre }}" data-open-product-view data-product-view-dialog="ver-producto-{{ $product->id }}"><i class="bi bi-eye" aria-hidden="true"></i></button>
                                        <button class="productos-action" type="button" title="Editar producto" aria-label="Editar {{ $product->nombre }}" data-open-product-edit data-product-dialog="editar-producto-{{ $product->id }}"><i class="bi bi-pencil" aria-hidden="true"></i></button>
                                        @if ($product->activo)<form method="post" action="{{ route('management.products.deactivate', $product) }}">@csrf @method('DELETE')<button class="productos-action productos-action--danger" type="submit" title="Desactivar producto" aria-label="Desactivar {{ $product->nombre }}" data-confirm="¿Desactivar este producto? La operación real existente recibirá la confirmación."><i class="bi bi-trash3" aria-hidden="true"></i></button></form>@endif
                                    </td>
                                </tr>
                            @empty
                                <tr><td colspan="9" class="productos-empty"><i class="bi bi-inbox" aria-hidden="true"></i><strong>No hay productos que coincidan con los filtros.</strong><span>Prueba con otros criterios de búsqueda.</span></td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
                <footer class="productos-pagination">
                    <form class="productos-per-page-form" method="get" action="{{ route('management.products') }}">
                        @foreach (request()->except(['page', 'por_pagina']) as $key => $value)
                            @if (is_scalar($value))
                                <input type="hidden" name="{{ $key }}" value="{{ $value }}">
                            @endif
                        @endforeach
                        <label for="productos-por-pagina">Mostrar</label>
                        <select id="productos-por-pagina" name="por_pagina" onchange="this.form.submit()" aria-label="Productos por página">
                            @foreach ([8, 10, 20, 50] as $option)
                                <option value="{{ $option }}" @selected(($filters['por_pagina'] ?? 8) === $option)>{{ $option }}</option>
                            @endforeach
                        </select>
                        <span>productos por página</span>
                    </form>
                    {{ $products->onEachSide(1)->links() }}
                </footer>
            </section>

            <aside class="productos-sidebar">
                <section class="productos-side-card">
                    <header class="productos-card-header"><div class="productos-card-title"><i class="bi bi-grid-3x3-gap-fill" aria-hidden="true"></i><div><h2>Accesos rápidos</h2></div></div></header>
                    <div class="productos-quick-grid">
                        <button type="button" data-open-product-create><span><i class="bi bi-plus-circle" aria-hidden="true"></i></span><b>Registrar<br>producto</b></button>
                        <button type="button" data-open-product-import><span><i class="bi bi-upload" aria-hidden="true"></i></span><b>Importar<br>productos</b></button>
                        <a href="{{ route('management.categories') }}"><span><i class="bi bi-diagram-3" aria-hidden="true"></i></span><b>Gestionar<br>categorías</b></a>
                        <a href="{{ route('management.inventory') }}"><span><i class="bi bi-box-seam" aria-hidden="true"></i></span><b>Ajuste de<br>inventario</b></a>
                        <button type="button" data-open-product-labels><span><i class="bi bi-tag" aria-hidden="true"></i></span><b>Etiquetas<br>masivas</b></button>
                        <a href="{{ route('management.products.export', array_merge(['format' => 'csv'], $exportParameters)) }}"><span><i class="bi bi-file-earmark-arrow-down" aria-hidden="true"></i></span><b>Exportar<br>catálogo</b></a>
                    </div>
                </section>

                <section class="productos-side-card productos-advice-card">
                    <header class="productos-card-header"><div class="productos-card-title"><i class="bi bi-lightbulb-fill" aria-hidden="true"></i><div><h2>Consejos de inventario</h2></div></div><a href="{{ route('management.inventory') }}">Ver todos</a></header>
                    <div class="productos-advice-list">
                        <a href="{{ route('management.inventory') }}"><span class="productos-advice-icon is-danger"><i class="bi bi-box" aria-hidden="true"></i></span><span><b>{{ number_format($outOfStock) }} productos sin stock</b><small>Revisa y repone el inventario.</small></span><i class="bi bi-chevron-right" aria-hidden="true"></i></a>
                        <a href="{{ route('management.inventory') }}"><span class="productos-advice-icon is-warning"><i class="bi bi-exclamation-triangle" aria-hidden="true"></i></span><span><b>{{ number_format($lowStock) }} productos con stock bajo</b><small>Considera realizar un nuevo pedido.</small></span><i class="bi bi-chevron-right" aria-hidden="true"></i></a>
                        <a href="{{ route('management.reports') }}"><span class="productos-advice-icon is-success"><i class="bi bi-currency-dollar" aria-hidden="true"></i></span><span><b>Valor total del inventario</b><small>S/ {{ number_format($inventoryValue, 2) }} en productos activos.</small></span><i class="bi bi-chevron-right" aria-hidden="true"></i></a>
                        <a href="{{ route('management.products', ['stock' => 'disponible']) }}"><span class="productos-advice-icon is-purple"><i class="bi bi-percent" aria-hidden="true"></i></span><span><b>{{ number_format($offerCount) }} productos en oferta</b><small>Aprovecha para impulsar tus ventas.</small></span><i class="bi bi-chevron-right" aria-hidden="true"></i></a>
                    </div>
                </section>
            </aside>
        </div>
    </section>

    <dialog class="productos-dialog" id="nuevo-producto" aria-labelledby="producto-crear-titulo">
        <div class="productos-dialog-card">
            <header class="productos-dialog-header">
                <div class="productos-dialog-title">
                    <span class="productos-dialog-icon"><i class="bi bi-box-seam" aria-hidden="true"></i></span>
                    <div>
                        <h2 id="producto-crear-titulo">Registrar nuevo producto</h2>
                        <p>Completa la información del producto o importa una plantilla Excel.</p>
                    </div>
                </div>
                <button type="button" class="productos-dialog-close" data-close-product-create aria-label="Cerrar"><i class="bi bi-x-lg" aria-hidden="true"></i></button>
            </header>
            @include('gestion.productos.crear', ['categories' => $categories, 'brands' => $brands, 'suppliers' => $suppliers])
        </div>
    </dialog>

    <dialog class="productos-dialog productos-import-dialog" id="importar-productos" aria-labelledby="productos-import-title" data-product-import-dialog>
        <div class="productos-dialog-card">
            <header class="productos-dialog-header productos-import-header">
                <div class="productos-dialog-title"><span class="productos-dialog-icon"><i class="bi bi-file-earmark-spreadsheet" aria-hidden="true"></i></span><div><h2 id="productos-import-title">Importar catálogo de productos</h2><p>Revisa la plantilla y ejemplos antes de una futura integración.</p></div></div>
                <button type="button" class="productos-dialog-close" data-close-product-import aria-label="Cerrar"><i class="bi bi-x-lg" aria-hidden="true"></i></button>
            </header>
            <div class="productos-import-body">
                <p class="productos-import-notice"><i class="bi bi-info-circle" aria-hidden="true"></i>Asistente visual: el archivo no se lee, procesa, transmite ni guarda. El SKU no se compara con el catálogo real.</p>
                <nav class="productos-import-steps" aria-label="Etapas de importación de productos"><span data-product-import-indicator="0"><b>1</b> Plantilla</span><i></i><span data-product-import-indicator="1"><b>2</b> Archivo</span><i></i><span data-product-import-indicator="2"><b>3</b> Vista previa</span><i></i><span data-product-import-indicator="3"><b>4</b> Validaciones</span><i></i><span data-product-import-indicator="4"><b>5</b> Confirmar</span></nav>
                <section class="productos-import-stage" data-product-import-stage="0"><h3>1. Descargar plantilla CSV</h3><p>CSV UTF-8 compatible con Excel. Usa los campos del producto: nombre, etiqueta (mostrada como SKU), categoria_id, marca, precio, precio_original (costo), precio_oferta, proveedor_id, descripcion y url_imagen. Los campos opcionales se describen en las validaciones; no incluye existencias ni archivos de imagen.</p><button class="productos-create-submit" type="button" data-product-import-download><i class="bi bi-download" aria-hidden="true"></i> Descargar plantilla CSV</button></section>
                <section class="productos-import-stage" data-product-import-stage="1" hidden><h3>2. Seleccionar archivo</h3><label class="productos-import-field">Archivo CSV o XLSX<input type="file" accept=".csv,.xlsx" data-product-import-file></label><small>Solo se mostrará el nombre; no se abrirá ni enviará el archivo.</small><p data-product-import-file-name>No se ha seleccionado un archivo.</p></section>
                <section class="productos-import-stage" data-product-import-stage="2" hidden><h3>3. Vista previa ilustrativa</h3><p>Columnas alineadas con la plantilla. Todos los valores son ejemplos estáticos; no proceden del archivo seleccionado ni del catálogo.</p><div class="productos-import-table-wrap"><table><thead><tr><th>nombre</th><th>etiqueta (SKU visible)</th><th>categoria_id</th><th>marca</th><th>precio</th><th>precio_original (costo)</th><th>precio_oferta</th><th>proveedor_id</th><th>descripcion</th><th>url_imagen</th><th>Revisión</th></tr></thead><tbody><tr><td>Producto de ejemplo</td><td>ETIQUETA-DEMO-001</td><td>ID-CATEGORIA-DEMO</td><td>Marca de ejemplo</td><td>199.90</td><td>150.00</td><td>179.90</td><td>ID-PROVEEDOR-DEMO</td><td>Descripción ilustrativa</td><td>https://example.invalid/imagen.jpg</td><td>Fila ilustrativa</td></tr><tr class="is-warning"><td>Producto de ejemplo repetido</td><td>ETIQUETA-DEMO-001</td><td>ID-CATEGORIA-DEMO</td><td>Marca de ejemplo</td><td>199.90</td><td>150.00</td><td>179.90</td><td>ID-PROVEEDOR-DEMO</td><td>Descripción ilustrativa</td><td>https://example.invalid/imagen.jpg</td><td>Etiqueta repetida solo en este ejemplo</td></tr></tbody></table></div></section>
                <section class="productos-import-stage" data-product-import-stage="3" hidden><h3>4. Validaciones ilustrativas</h3><ul class="productos-import-validations"><li class="is-valid"><i class="bi bi-check-circle" aria-hidden="true"></i> nombre, etiqueta, categoria_id, marca y precio son requeridos por el formulario de alta; etiqueta es nullable en la validación backend actual.</li><li><i class="bi bi-info-circle" aria-hidden="true"></i> etiqueta se muestra como SKU, pero no se encontró unicidad para ese campo. codigo_sku pertenece a variantes y no se importa aquí.</li><li><i class="bi bi-info-circle" aria-hidden="true"></i> precio_original representa el costo y es opcional. precio_oferta es opcional y el request actual exige que no supere precio; está soportado por el modelo, aunque no aparece en los formularios activos de alta/edición.</li><li><i class="bi bi-info-circle" aria-hidden="true"></i> categoria_id y proveedor_id son referencias numéricas; no se consultan ni validan contra datos reales. proveedor_id, descripcion y url_imagen son opcionales.</li><li class="is-warning"><i class="bi bi-exclamation-triangle" aria-hidden="true"></i> La fila repetida solo ilustra una etiqueta duplicada; no confirma duplicidad real ni una regla de unicidad.</li><li><i class="bi bi-info-circle" aria-hidden="true"></i> No se incluye existencias, no se crean movimientos y no se altera el inventario. imagen es un archivo binario y no forma parte del CSV; se puede indicar url_imagen.</li></ul></section>
                <section class="productos-import-stage" data-product-import-stage="4" hidden><h3>5. Confirmar importación</h3><p>Archivo seleccionado: <strong data-product-import-final-file>—</strong></p><label class="productos-import-ack"><input type="checkbox" data-product-import-ack> Confirmo que revisé los ejemplos y que la integración sigue pendiente.</label><p class="productos-import-feedback" data-product-import-feedback role="status" aria-live="polite" hidden></p></section>
                <p class="productos-import-error" data-product-import-error role="alert" hidden></p>
            </div>
            <footer class="productos-create-footer productos-import-footer"><button class="productos-create-cancel" type="button" data-close-product-import>Cancelar</button><button class="productos-create-cancel" type="button" data-product-import-previous hidden>Anterior</button><button class="productos-create-submit" type="button" data-product-import-next>Siguiente</button><button class="productos-create-submit" type="button" data-product-import-confirm hidden>Confirmar (demostración)</button></footer>
        </div>
    </dialog>

    <dialog class="productos-dialog productos-label-dialog" id="etiquetas-masivas-productos" aria-labelledby="productos-label-title" data-product-label-dialog>
        <div class="productos-dialog-card">
            <header class="productos-dialog-header"><div class="productos-dialog-title"><span class="productos-dialog-icon"><i class="bi bi-tag" aria-hidden="true"></i></span><div><h2 id="productos-label-title">Etiquetas masivas</h2><p>Prepara una vista previa de parámetros para etiquetado.</p></div></div><button type="button" class="productos-dialog-close" data-close-product-labels aria-label="Cerrar"><i class="bi bi-x-lg" aria-hidden="true"></i></button></header>
            <div class="productos-label-body"><p class="productos-import-notice"><i class="bi bi-info-circle" aria-hidden="true"></i>Demostración visual: no se generan archivos, códigos ni impresiones.</p><label class="productos-import-field">Identificador de producto<input type="text" required maxlength="80" placeholder="SKU o nombre"></label><label class="productos-import-field">Cantidad de etiquetas<input type="number" required min="1" step="1" placeholder="Cantidad mayor que cero"></label><label class="productos-import-field">Contenido ilustrativo<select><option value="">Selecciona una opción</option><option>SKU y nombre</option><option>Precio y nombre</option></select></label><p class="productos-import-error" data-product-label-error role="alert" hidden></p><p class="productos-import-feedback" data-product-label-feedback role="status" aria-live="polite" hidden></p></div>
            <footer class="productos-create-footer"><button class="productos-create-cancel" type="button" data-close-product-labels>Cancelar</button><button class="productos-create-submit" type="button" data-product-label-confirm>Generar etiquetas (demostración)</button></footer>
        </div>
    </dialog>

    @foreach ($products as $product)
        <dialog class="productos-dialog productos-edit-dialog" id="editar-producto-{{ $product->id }}" aria-labelledby="producto-editar-titulo-{{ $product->id }}">
            <div class="productos-dialog-card">
                <header class="productos-dialog-header">
                    <div class="productos-dialog-title">
                        <span class="productos-dialog-icon"><i class="bi bi-pencil-square" aria-hidden="true"></i></span>
                        <div><h2 id="producto-editar-titulo-{{ $product->id }}">Editar producto</h2><p>Actualiza la información de {{ $product->nombre }}.</p></div>
                    </div>
                    <button type="button" class="productos-dialog-close" data-close-product-edit aria-label="Cerrar"><i class="bi bi-x-lg" aria-hidden="true"></i></button>
                </header>
                @include('gestion.productos.editar', ['product' => $product, 'categories' => $categories, 'brands' => $brands, 'suppliers' => $suppliers])
            </div>
        </dialog>
    @endforeach

    @foreach ($products as $product)
        @php
            $viewImage = $productImage($product->url_imagen);
            $viewStatus = !$product->activo ? 'Inactivo' : ($product->existencias === 0 ? 'Sin stock' : ($product->precio_oferta ? 'Oferta' : 'Activo'));
            $viewStatusClass = match ($viewStatus) { 'Sin stock' => 'danger', 'Oferta' => 'warning', 'Inactivo' => 'muted', default => 'success' };
        @endphp
        <dialog class="productos-dialog productos-view-dialog" id="ver-producto-{{ $product->id }}" aria-labelledby="producto-detalle-titulo-{{ $product->id }}">
            <div class="productos-dialog-card">
                <header class="productos-dialog-header">
                    <div class="productos-dialog-title"><span class="productos-dialog-icon"><i class="bi bi-eye" aria-hidden="true"></i></span><div><h2 id="producto-detalle-titulo-{{ $product->id }}">Información del producto</h2><p>Consulta el detalle registrado en Administración.</p></div></div>
                    <button type="button" class="productos-dialog-close" data-close-product-view aria-label="Cerrar"><i class="bi bi-x-lg" aria-hidden="true"></i></button>
                </header>
                <div class="productos-view-body">
                    <div class="productos-view-identity">
                        @if ($viewImage)<img class="productos-view-image" src="{{ $viewImage }}" alt="{{ $product->nombre }}">@else<span class="productos-view-image productos-image--placeholder"><i class="bi bi-box-seam" aria-hidden="true"></i></span>@endif
                        <div><span class="productos-eyebrow">{{ $product->marca }}</span><h3>{{ $product->nombre }}</h3><p>{{ $product->category?->nombre ?: 'Sin categoría' }} · {{ $product->etiqueta ?: 'SKU-'.str_pad((string) $product->id, 4, '0', STR_PAD_LEFT) }}</p></div>
                    </div>
                    <div class="productos-view-stats"><div><small>Precio de venta</small><strong>S/ {{ number_format((float) $product->effective_price, 2) }}</strong></div><div><small>Stock actual</small><strong>{{ number_format($product->existencias) }} unidades</strong></div><div><small>Estado</small><span class="productos-status productos-status--{{ $viewStatusClass }}">{{ $viewStatus }}</span></div><div><small>Proveedor</small><strong>{{ $product->suppliers->first()?->nombre ?: 'Sin proveedor' }}</strong></div></div>
                    <section class="productos-view-description"><small>Descripción</small><p>{{ $product->descripcion ?: 'Sin descripción registrada.' }}</p></section>
                </div>
                <footer class="productos-create-footer productos-view-footer"><button class="productos-create-cancel" type="button" data-close-product-view>Cerrar</button><button class="productos-create-submit" type="button" data-open-product-edit data-product-dialog="editar-producto-{{ $product->id }}"><i class="bi bi-pencil" aria-hidden="true"></i> Editar producto</button></footer>
            </div>
        </dialog>
    @endforeach
@endsection

@push('scripts')
    <script>
        (() => {
            const dialog = document.querySelector('#nuevo-producto');
            const page = document.querySelector('[data-product-page]');
            const importDialog = document.querySelector('[data-product-import-dialog]');
            const labelDialog = document.querySelector('[data-product-label-dialog]');

            if (!dialog || !page || !importDialog || !labelDialog) {
                return;
            }

            page.querySelectorAll('[data-open-product-create]').forEach((button) => {
                button.addEventListener('click', () => dialog.showModal());
            });
            dialog.querySelector('[data-close-product-create]')?.addEventListener('click', () => dialog.close());
            dialog.addEventListener('click', (event) => {
                if (event.target === dialog) {
                    dialog.close();
                }
            });

            const importStages = [...importDialog.querySelectorAll('[data-product-import-stage]')];
            const importIndicators = [...importDialog.querySelectorAll('[data-product-import-indicator]')];
            const importFile = importDialog.querySelector('[data-product-import-file]');
            const importFileName = importDialog.querySelector('[data-product-import-file-name]');
            const importFinalFile = importDialog.querySelector('[data-product-import-final-file]');
            const importError = importDialog.querySelector('[data-product-import-error]');
            const importFeedback = importDialog.querySelector('[data-product-import-feedback]');
            const importPrevious = importDialog.querySelector('[data-product-import-previous]');
            const importNext = importDialog.querySelector('[data-product-import-next]');
            const importConfirm = importDialog.querySelector('[data-product-import-confirm]');
            const importAcknowledgement = importDialog.querySelector('[data-product-import-ack]');
            let importStep = 0;
            let selectedImportFile = null;
            const renderImportStep = (step) => {
                importStep = step;
                importStages.forEach((stage) => { stage.hidden = Number(stage.dataset.productImportStage) !== step; });
                importIndicators.forEach((indicator) => indicator.classList.toggle('is-current', Number(indicator.dataset.productImportIndicator) === step));
                importPrevious.hidden = step === 0;
                importNext.hidden = step === 4;
                importConfirm.hidden = step !== 4;
                importError.hidden = true;
                importFeedback.hidden = true;
                importFinalFile.textContent = selectedImportFile?.name ?? '—';
            };
            const resetImportWizard = () => {
                selectedImportFile = null;
                importFile.value = '';
                importFileName.textContent = 'No se ha seleccionado un archivo.';
                importAcknowledgement.checked = false;
                importConfirm.disabled = false;
                renderImportStep(0);
            };
            document.querySelectorAll('[data-open-product-import]').forEach((button) => button.addEventListener('click', () => {
                resetImportWizard();
                importDialog.showModal();
            }));
            page.querySelector('[data-open-product-labels]')?.addEventListener('click', () => {
                labelDialog.querySelector('[data-product-label-error]').hidden = true;
                labelDialog.querySelector('[data-product-label-feedback]').hidden = true;
                labelDialog.querySelector('[data-product-label-confirm]').disabled = false;
                labelDialog.showModal();
            });
            importDialog.querySelector('[data-product-import-download]')?.addEventListener('click', () => {
                const csv = '\uFEFFnombre,etiqueta,categoria_id,marca,precio,precio_original,precio_oferta,proveedor_id,descripcion,url_imagen\r\n';
                const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
                const link = document.createElement('a');
                link.href = url;
                link.download = 'plantilla-productos.csv';
                link.click();
                window.setTimeout(() => URL.revokeObjectURL(url), 1000);
            });
            importFile.addEventListener('change', () => {
                const file = importFile.files?.[0] ?? null;
                if (file && !/\.(csv|xlsx)$/i.test(file.name)) {
                    selectedImportFile = null;
                    importFile.value = '';
                    importFileName.textContent = 'No se ha seleccionado un archivo.';
                    importError.textContent = 'Selecciona un archivo CSV o XLSX.';
                    importError.hidden = false;
                    return;
                }
                selectedImportFile = file;
                importFileName.textContent = file ? `Seleccionado: ${file.name}` : 'No se ha seleccionado un archivo.';
                importError.hidden = true;
            });
            importPrevious.addEventListener('click', () => renderImportStep(Math.max(0, importStep - 1)));
            importNext.addEventListener('click', () => {
                if (importStep === 1 && !selectedImportFile) {
                    importError.textContent = 'Selecciona un archivo para continuar con la vista previa ilustrativa.';
                    importError.hidden = false;
                    return;
                }
                renderImportStep(Math.min(4, importStep + 1));
            });
            importConfirm.addEventListener('click', () => {
                if (!importAcknowledgement.checked) {
                    importError.textContent = 'Confirma que revisaste la vista previa y sus validaciones ilustrativas.';
                    importError.hidden = false;
                    return;
                }
                importFeedback.textContent = 'Integración pendiente: no se importó ningún producto, no se consultó el catálogo y no se modificó el stock.';
                importFeedback.hidden = false;
                importConfirm.disabled = true;
                importError.hidden = true;
            });

            const labelConfirm = labelDialog.querySelector('[data-product-label-confirm]');
            labelConfirm?.addEventListener('click', () => {
                const fields = [...labelDialog.querySelectorAll('input[required]')];
                const invalidFields = fields.filter((field) => !field.checkValidity());
                const error = labelDialog.querySelector('[data-product-label-error]');
                const feedback = labelDialog.querySelector('[data-product-label-feedback]');
                if (invalidFields.length > 0) {
                    invalidFields.forEach((field) => field.setAttribute('aria-invalid', 'true'));
                    error.textContent = 'Completa el producto y una cantidad mayor que cero.';
                    error.hidden = false;
                    invalidFields[0].focus();
                    return;
                }
                feedback.textContent = 'Integración pendiente: no se generaron archivos, códigos ni impresiones.';
                feedback.hidden = false;
                error.hidden = true;
                labelConfirm.disabled = true;
            });
            labelDialog.querySelectorAll('[data-close-product-labels]').forEach((button) => button.addEventListener('click', () => labelDialog.close()));
            importDialog.querySelectorAll('[data-close-product-import]').forEach((button) => button.addEventListener('click', () => importDialog.close()));
            [importDialog, labelDialog].forEach((currentDialog) => currentDialog.addEventListener('click', (event) => {
                if (event.target === currentDialog) {
                    currentDialog.close();
                }
            }));

            const imageInput = dialog.querySelector('[data-product-image-input]');
            const imagePreview = dialog.querySelector('[data-product-image-preview]');
            const imagePreviewImage = dialog.querySelector('[data-product-image-preview-image]');
            const clearImage = dialog.querySelector('[data-product-image-clear]');

            imageInput?.addEventListener('change', () => {
                const [file] = imageInput.files ?? [];

                if (!file || !imagePreview || !imagePreviewImage) {
                    return;
                }

                imagePreviewImage.src = URL.createObjectURL(file);
                imagePreview.hidden = false;
            });
            clearImage?.addEventListener('click', () => {
                if (imageInput) {
                    imageInput.value = '';
                }
                if (imagePreviewImage) {
                    imagePreviewImage.src = '';
                }
                if (imagePreview) {
                    imagePreview.hidden = true;
                }
            });

            document.querySelectorAll('[data-open-product-edit]').forEach((button) => {
                const editDialog = document.getElementById(button.dataset.productDialog);

                button.addEventListener('click', () => editDialog?.showModal());
            });
            document.querySelectorAll('.productos-edit-dialog').forEach((editDialog) => {
                editDialog.querySelector('[data-close-product-edit]')?.addEventListener('click', () => editDialog.close());
                editDialog.addEventListener('click', (event) => {
                    if (event.target === editDialog) {
                        editDialog.close();
                    }
                });
            });
            page.querySelectorAll('[data-open-product-view]').forEach((button) => {
                const viewDialog = document.getElementById(button.dataset.productViewDialog);
                const editDialog = document.getElementById(button.dataset.productDialog);

                button.addEventListener('click', () => {
                    if (viewDialog) {
                        viewDialog.showModal();
                    } else if (editDialog) {
                        editDialog.showModal();
                    }
                });
            });
            document.querySelectorAll('.productos-view-dialog').forEach((viewDialog) => {
                viewDialog.querySelectorAll('[data-close-product-view]').forEach((button) => button.addEventListener('click', () => viewDialog.close()));
                viewDialog.addEventListener('click', (event) => {
                    if (event.target === viewDialog) {
                        viewDialog.close();
                    }
                });
            });

            @if (session('open_product_modal') || $errors->any())
                dialog.showModal();
            @endif
        })();
    </script>
@endpush
