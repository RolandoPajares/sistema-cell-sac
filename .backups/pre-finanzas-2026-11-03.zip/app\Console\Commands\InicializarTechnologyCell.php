<?php

namespace App\Console\Commands;

use App\Models\User;
use App\Servicios\RegistradorAuditoria;
use Database\Seeders\RbacInicialSeeder;
use Illuminate\Console\Attributes\Description;
use Illuminate\Console\Attributes\Signature;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;
use Throwable;

#[Signature('technology-cell:inicializar {--confirmar : Autoriza la creación inicial de empresa y administrador} {--vista-previa : Describe las operaciones sin escribir datos}')]
#[Description('Inicializa una instalación vacía sin modificar cuentas existentes')]
class InicializarTechnologyCell extends Command
{
    private const VERSION = 'instalacion-inicial-a25';

    public function handle(RegistradorAuditoria $audit): int
    {
        if ($this->option('vista-previa')) {
            $this->mostrarPlan();

            return self::SUCCESS;
        }

        if (! $this->option('confirmar')) {
            $this->error('La inicialización requiere autorización explícita mediante --confirmar.');

            return self::FAILURE;
        }

        foreach (['usuarios', 'empresas', 'sedes', 'almacenes', 'roles', 'usuarios_roles', 'registros_auditoria', 'versiones_inicializacion_control_acceso'] as $table) {
            if (! Schema::hasTable($table)) {
                $this->error('Falta una tabla requerida: '.$table);

                return self::FAILURE;
            }
        }

        if (DB::table('versiones_inicializacion_control_acceso')->where('codigo', self::VERSION)->exists()) {
            $this->info('La instalación inicial ya fue registrada; no se modificó ningún dato.');

            return self::SUCCESS;
        }

        foreach (['usuarios', 'empresas', 'sedes', 'almacenes'] as $table) {
            if (DB::table($table)->exists()) {
                $this->error('La instalación contiene datos previos y requiere conciliación: '.$table);

                return self::FAILURE;
            }
        }

        $data = [
            'empresa_codigo' => $this->ask('Código de empresa'),
            'razon_social' => $this->ask('Razón social'),
            'sede_codigo' => $this->ask('Código de sede'),
            'sede_nombre' => $this->ask('Nombre de sede'),
            'almacen_codigo' => $this->ask('Código de almacén'),
            'almacen_nombre' => $this->ask('Nombre de almacén'),
            'nombre' => $this->ask('Nombre del administrador inicial'),
            'correo' => $this->ask('Correo del administrador inicial'),
            'password' => $this->secret('Contraseña del administrador inicial'),
            'password_confirmation' => $this->secret('Repite la contraseña'),
        ];
        $validator = Validator::make($data, [
            'empresa_codigo' => ['required', 'string', 'max:30', 'regex:/\A[a-zA-Z0-9_-]+\z/'],
            'razon_social' => ['required', 'string', 'max:180'],
            'sede_codigo' => ['required', 'string', 'max:30', 'regex:/\A[a-zA-Z0-9_-]+\z/'],
            'sede_nombre' => ['required', 'string', 'max:140'],
            'almacen_codigo' => ['required', 'string', 'max:30', 'regex:/\A[a-zA-Z0-9_-]+\z/'],
            'almacen_nombre' => ['required', 'string', 'max:140'],
            'nombre' => ['required', 'string', 'max:120'],
            'correo' => ['required', 'email', 'max:160'],
            'password' => ['required', 'confirmed', Password::min(12)->letters()->numbers()],
        ]);
        if ($validator->fails()) {
            foreach ($validator->errors()->all() as $error) {
                $this->error($error);
            }

            return self::FAILURE;
        }

        $this->mostrarPlan();
        $this->line('Base configurada: '.DB::connection()->getDatabaseName());
        $this->line('Empresa: '.$data['razon_social'].' ('.$data['empresa_codigo'].')');
        $this->line('Sede: '.$data['sede_nombre'].'; almacén: '.$data['almacen_nombre']);
        $this->line('Administrador inicial: '.$data['nombre'].' ('.$data['correo'].')');
        if (! $this->confirm('¿Crear estos registros en la base configurada?', false)) {
            $this->info('Inicialización cancelada; no se escribieron datos.');

            return self::FAILURE;
        }

        try {
            DB::transaction(function () use ($data, $audit): void {
                $inserted = DB::table('versiones_inicializacion_control_acceso')->insertOrIgnore([
                    'codigo' => self::VERSION,
                    'aplicado_en' => now(),
                ]);
                if ($inserted !== 1) {
                    return;
                }

                foreach (['usuarios', 'empresas', 'sedes', 'almacenes'] as $table) {
                    if (DB::table($table)->exists()) {
                        throw new \RuntimeException('La instalación dejó de estar vacía.');
                    }
                }

                app(RbacInicialSeeder::class)->run();
                $roleId = DB::table('roles')->where('codigo', 'administrador')->where('alcance_permitido', 'empresa')
                    ->where('es_sistema', true)->where('activo', true)->value('id');
                if ($roleId === null) {
                    throw new \RuntimeException('El rol administrador no está disponible.');
                }

                $companyId = DB::table('empresas')->insertGetId([
                    'codigo' => $data['empresa_codigo'], 'razon_social' => $data['razon_social'],
                    'activo' => true, 'creado_en' => now(), 'actualizado_en' => now(),
                ]);
                $siteId = DB::table('sedes')->insertGetId([
                    'empresa_id' => $companyId, 'codigo' => $data['sede_codigo'], 'nombre' => $data['sede_nombre'],
                    'activa' => true, 'creado_en' => now(), 'actualizado_en' => now(),
                ]);
                $warehouseId = DB::table('almacenes')->insertGetId([
                    'sede_id' => $siteId, 'codigo' => $data['almacen_codigo'], 'nombre' => $data['almacen_nombre'],
                    'activo' => true, 'creado_en' => now(), 'actualizado_en' => now(),
                ]);
                $user = User::create([
                    'nombre' => $data['nombre'], 'correo' => mb_strtolower(trim($data['correo'])),
                    'password' => $data['password'], 'rol' => 'administrador', 'acceso_controlado' => true,
                ]);
                DB::table('usuarios_roles')->insert([
                    'usuario_id' => $user->getKey(), 'rol_id' => $roleId, 'asignado_en' => now(), 'activo' => true,
                ]);
                $audit->record($user->getKey(), 'instalacion.inicializada', 'empresas', $companyId, null, [
                    'empresa_id' => $companyId, 'sede_id' => $siteId, 'almacen_id' => $warehouseId,
                ], null, scope: ['empresa_id' => $companyId, 'sede_id' => $siteId]);
            }, 3);
        } catch (Throwable) {
            $this->error('No se completó la inicialización. Se revirtió la transacción; revisa la configuración y los datos existentes.');

            return self::FAILURE;
        }

        $this->info('Instalación inicial completada. No se modificaron cuentas existentes.');

        return self::SUCCESS;
    }

    private function mostrarPlan(): void
    {
        $this->line('Vista previa: crear los catálogos RBAC iniciales, una empresa, una sede, un almacén y un administrador.');
        $this->line('Solo se asignará el rol administrador a la cuenta nueva; se registrará auditoría y no se modificarán cuentas existentes.');
        $this->line('Datos requeridos: códigos y nombres de empresa, sede y almacén; nombre, correo y contraseña del administrador.');
    }
}
