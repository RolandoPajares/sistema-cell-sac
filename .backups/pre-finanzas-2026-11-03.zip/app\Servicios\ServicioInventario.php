<?php

namespace App\Servicios;

use App\Models\Catalogo\Producto;
use App\Models\Inventario\MovimientoInventario;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class ServicioInventario
{
    public function __construct(
        private readonly ServicioAutorizacion $authorization,
        private readonly RegistradorAuditoria $audit,
    ) {}

    /** @return array{empresa_id:int,sede_id:?int} */
    public function alcanceConsulta(User $usuario): array
    {
        $permiso = 'gestion.inventario.consultar';
        $this->authorization->assertAllowed($usuario, $permiso);

        if ($this->authorization->allowsGlobal($usuario, $permiso)) {
            $empresas = DB::table('empresas')->where('activo', true)->limit(2)->pluck('id');
            abort_unless($empresas->count() === 1, 403);

            return ['empresa_id' => (int) $empresas->first(), 'sede_id' => null];
        }

        $sedeId = $this->authorization->activeSiteIdFor($usuario);
        abort_unless($sedeId !== null, 403);
        $sede = DB::table('sedes')->join('empresas', 'empresas.id', '=', 'sedes.empresa_id')
            ->where('sedes.id', $sedeId)->where('sedes.activa', true)->where('empresas.activo', true)
            ->first(['sedes.empresa_id']);
        abort_unless($sede !== null && $this->authorization->allowsRecord($usuario, $permiso, (int) $sede->empresa_id, $sedeId), 403);

        return ['empresa_id' => (int) $sede->empresa_id, 'sede_id' => $sedeId];
    }

    /**
     * @param  array{empresa_id:int,sede_id:?int}  $alcance
     * @param  array{buscar?:?string,categoria?:?int,estado?:?string,proveedor?:?int}  $filtros
     * @return Builder<Producto>
     */
    public function productosParaConsulta(array $alcance, array $filtros = []): Builder
    {
        $saldo = DB::table('existencias_almacen as saldo')
            ->whereColumn('saldo.producto_id', 'productos.id')
            ->whereColumn('saldo.empresa_id', 'productos.empresa_id')
            ->where('saldo.empresa_id', $alcance['empresa_id'])
            ->when($alcance['sede_id'] !== null, fn ($consulta) => $consulta->where('saldo.sede_id', $alcance['sede_id']));

        $consulta = Producto::query()->select('productos.*')
            ->selectSub((clone $saldo)->selectRaw('COALESCE(SUM(saldo.cantidad_fisica), 0)'), 'existencias_alcance')
            ->where('productos.empresa_id', $alcance['empresa_id'])
            ->where('productos.activo', true)
            ->whereExists((clone $saldo)->selectRaw('1'));

        $buscar = $filtros['buscar'] ?? null;
        if ($buscar !== null) {
            $consulta->where(function (Builder $busqueda) use ($buscar): void {
                $busqueda->where('productos.nombre', 'like', '%'.$buscar.'%')
                    ->orWhere('productos.marca', 'like', '%'.$buscar.'%')
                    ->orWhere('productos.etiqueta', 'like', '%'.$buscar.'%')
                    ->orWhere('productos.categoria', 'like', '%'.$buscar.'%');
            });
        }
        if (($filtros['categoria'] ?? null) !== null) {
            $consulta->where('productos.categoria_id', $filtros['categoria']);
        }
        if (($filtros['proveedor'] ?? null) !== null) {
            $consulta->whereHas('suppliers', fn (Builder $proveedores): Builder => $proveedores->whereKey($filtros['proveedor']));
        }

        $estado = $filtros['estado'] ?? null;
        if (in_array($estado, ['optimo', 'bajo', 'critico', 'bajo_o_critico'], true)) {
            $productosConSaldo = DB::table('existencias_almacen')->select('producto_id')
                ->where('empresa_id', $alcance['empresa_id'])
                ->when($alcance['sede_id'] !== null, fn ($saldos) => $saldos->where('sede_id', $alcance['sede_id']))
                ->groupBy('producto_id');
            match ($estado) {
                'optimo' => $productosConSaldo->havingRaw('SUM(cantidad_fisica) > ?', [10]),
                'bajo' => $productosConSaldo->havingRaw('SUM(cantidad_fisica) BETWEEN ? AND ?', [6, 10]),
                'critico' => $productosConSaldo->havingRaw('SUM(cantidad_fisica) <= ?', [5]),
                'bajo_o_critico' => $productosConSaldo->havingRaw('SUM(cantidad_fisica) <= ?', [10]),
            };
            $consulta->whereIn('productos.id', $productosConSaldo);
        }

        return $consulta;
    }

    /**
     * @param  array{empresa_id:int,sede_id:?int}  $alcance
     * @return array{productos:int,stock_bajo:int,valor_catalogo:float}
     */
    public function resumenConsulta(array $alcance): array
    {
        $saldos = DB::table('existencias_almacen')->select('producto_id')
            ->selectRaw('SUM(cantidad_fisica) AS unidades')
            ->where('empresa_id', $alcance['empresa_id'])
            ->when($alcance['sede_id'] !== null, fn ($consulta) => $consulta->where('sede_id', $alcance['sede_id']))
            ->groupBy('producto_id');
        $resumen = DB::query()->fromSub($saldos, 'saldos')
            ->join('productos', 'productos.id', '=', 'saldos.producto_id')
            ->where('productos.empresa_id', $alcance['empresa_id'])
            ->where('productos.activo', true)
            ->selectRaw('COUNT(CASE WHEN saldos.unidades > 0 THEN 1 END) AS productos')
            ->selectRaw('COUNT(CASE WHEN saldos.unidades <= 10 THEN 1 END) AS stock_bajo')
            ->selectRaw('COALESCE(SUM(saldos.unidades * productos.precio), 0) AS valor_catalogo')
            ->first();

        return [
            'productos' => (int) $resumen->productos,
            'stock_bajo' => (int) $resumen->stock_bajo,
            'valor_catalogo' => (float) $resumen->valor_catalogo,
        ];
    }

    /**
     * @param  array<int, int|string>  $identificadores
     * @return array<int, int>
     */
    public function disponibilidadParaOperacion(User $usuario, array $identificadores): array
    {
        $this->authorization->assertAllowed($usuario, 'gestion.pedidos.crear');
        $ubicacion = $this->authorization->operationLocation($usuario);
        abort_unless($ubicacion['empresa_id'] !== null && $ubicacion['sede_id'] !== null && $ubicacion['almacen_id'] !== null, 503, 'No hay un almacén autorizado disponible.');
        $ids = collect($identificadores)->map(fn (int|string $id): int => (int) $id)
            ->filter(fn (int $id): bool => $id > 0)->unique()->values()->all();
        if ($ids === []) {
            return [];
        }
        if (! DB::table('almacenes')->where('id', $ubicacion['almacen_id'])
            ->where('activo', true)->where('permite_venta', true)->exists()) {
            return array_fill_keys($ids, 0);
        }

        $productos = Producto::query()->whereIn('id', $ids)->where('empresa_id', $ubicacion['empresa_id'])
            ->where('activo', true)->pluck('id')->map(fn (mixed $id): int => (int) $id)->all();
        $saldos = DB::table('existencias_almacen')->where('empresa_id', $ubicacion['empresa_id'])
            ->where('sede_id', $ubicacion['sede_id'])->where('almacen_id', $ubicacion['almacen_id'])
            ->whereIn('producto_id', $productos)->get(['producto_id', 'variante_id', 'cantidad_fisica', 'cantidad_reservada'])
            ->groupBy('producto_id');
        $variantes = $saldos->flatten(1)->pluck('variante_id')->filter()->unique()->values()->all();
        $variantesSerializadas = $variantes !== [] && Schema::hasTable('variantes_productos') && Schema::hasColumn('variantes_productos', 'controla_serie')
            ? DB::table('variantes_productos')->whereIn('id', $variantes)->where('controla_serie', true)->pluck('id')->map(fn (mixed $id): int => (int) $id)->all()
            : $variantes;
        $productosSerializados = Schema::hasTable('dispositivos')
            ? DB::table('dispositivos')->whereIn('producto_id', $productos)->distinct()->pluck('producto_id')->map(fn (mixed $id): int => (int) $id)->all()
            : [];

        $disponibilidad = [];
        foreach ($productos as $productoId) {
            $registros = $saldos->get($productoId, collect());
            $saldo = $registros->count() === 1 ? $registros->first() : null;
            if ($saldo === null || in_array($productoId, $productosSerializados, true)
                || ($saldo->variante_id !== null && in_array((int) $saldo->variante_id, $variantesSerializadas, true))) {
                $disponibilidad[$productoId] = 0;

                continue;
            }
            $fisica = (float) $saldo->cantidad_fisica;
            $reservada = (float) $saldo->cantidad_reservada;
            $disponibilidad[$productoId] = $fisica >= 0 && $fisica === floor($fisica) && $reservada >= 0
                ? max(0, (int) floor($fisica - $reservada)) : 0;
        }

        return $disponibilidad;
    }

    public function registerNewProduct(Producto $product, User $user): void
    {
        abort_unless(DB::transactionLevel() > 0 && Schema::hasTable('existencias_almacen'), 503, 'El inventario requiere una transacción y un almacén configurado.');
        $location = $this->authorization->operationLocation($user);
        abort_unless($location['empresa_id'] !== null && $location['sede_id'] !== null && $location['almacen_id'] !== null, 503, 'No hay un almacén autorizado disponible.');
        abort_unless((int) $product->empresa_id === $location['empresa_id'], 403);

        $stock = (int) $product->existencias;
        if ($stock > 0) {
            $this->authorization->assertAllowed($user, 'gestion.inventario.ajustar');
        }

        DB::table('existencias_almacen')->insert([
            'almacen_id' => $location['almacen_id'],
            'producto_id' => $product->id,
            'variante_id' => null,
            'empresa_id' => $location['empresa_id'],
            'sede_id' => $location['sede_id'],
            'cantidad_fisica' => $stock,
            'cantidad_reservada' => 0,
        ]);

        if ($stock > 0) {
            MovimientoInventario::create([
                'producto_id' => $product->id,
                'usuario_id' => $user->id,
                'tipo_movimiento' => 'entrada',
                'cantidad' => $stock,
                'notas' => 'Existencia inicial del producto.',
                'creado_en' => now(),
                'variante_id' => null,
                'documento_tipo' => 'alta_producto',
                'documento_id' => (string) $product->id,
                ...$this->authorization->operationScopeAttributes($user, 'movimientos_inventario'),
            ]);
        }
    }

    public function adjust(Producto $product, string $movementType, int $quantity, string $notes, User $user): MovimientoInventario
    {
        $this->authorization->assertAllowed($user, 'gestion.inventario.ajustar');

        return DB::transaction(function () use ($product, $movementType, $quantity, $notes, $user): MovimientoInventario {
            $lockedProduct = Producto::whereKey($product->getKey())->lockForUpdate()->firstOrFail();
            $movement = $this->changeLockedProduct($lockedProduct, $movementType, $quantity, $notes, $user);
            $this->audit->record($user->id, 'inventory.adjusted', 'movimientos_inventario', $movement->id, null, [
                'producto_id' => $product->id,
                'tipo_movimiento' => $movementType,
                'cantidad' => $movement->cantidad,
            ], request()->ip());

            return $movement;
        }, 3);
    }

    public function changeLockedProduct(Producto $product, string $movementType, int $quantity, string $notes, User $user): MovimientoInventario
    {
        abort_unless(DB::transactionLevel() > 0, 503, 'El movimiento de inventario requiere una transacción.');
        abort_if($quantity < 0 || ($movementType !== 'ajuste' && $quantity === 0), 422, 'La cantidad del movimiento no es válida.');
        $location = $this->authorization->operationLocation($user);
        abort_unless($location['empresa_id'] !== null && $location['sede_id'] !== null && $location['almacen_id'] !== null, 503, 'No hay un almacén autorizado disponible.');
        abort_unless((int) $product->empresa_id === $location['empresa_id'], 403);

        $balances = DB::table('existencias_almacen')
            ->where('empresa_id', $location['empresa_id'])
            ->where('sede_id', $location['sede_id'])
            ->where('almacen_id', $location['almacen_id'])
            ->where('producto_id', $product->id)
            ->lockForUpdate()
            ->get(['id', 'variante_id', 'cantidad_fisica', 'cantidad_reservada']);
        abort_unless($balances->count() === 1, 409, 'El producto requiere conciliar o seleccionar su existencia por variante.');
        $balance = $balances->first();
        $productBalances = DB::table('existencias_almacen')->where('producto_id', $product->id)->where('empresa_id', $location['empresa_id']);
        abort_if((clone $productBalances)->whereNull('variante_id')->exists() && (clone $productBalances)->whereNotNull('variante_id')->exists(), 409, 'Las existencias por producto y variante requieren conciliación.');
        abort_if((float) $balance->cantidad_fisica !== floor((float) $balance->cantidad_fisica), 422, 'El formulario no admite existencias fraccionarias.');
        $previousStock = (int) $balance->cantidad_fisica;
        $nextStock = match ($movementType) {
            'entrada' => $previousStock + $quantity,
            'salida' => $previousStock - $quantity,
            'ajuste' => $quantity,
            default => throw new \InvalidArgumentException('Tipo de movimiento inválido.'),
        };

        abort_if($nextStock < 0, 422, 'La salida supera el stock disponible.');

        abort_if((float) $balance->cantidad_reservada > $nextStock, 422, 'El movimiento dejaría reservas sin respaldo.');
        $variantId = $balance->variante_id === null ? null : (int) $balance->variante_id;
        DB::table('existencias_almacen')->where('id', $balance->id)->update(['cantidad_fisica' => $nextStock]);

        $total = (float) DB::table('existencias_almacen')->where('producto_id', $product->id)->where('empresa_id', $location['empresa_id'])->sum('cantidad_fisica');
        abort_if($total !== floor($total) || $total > 4294967295, 422, 'No es posible actualizar la proyección heredada de existencias.');
        $product->update(['existencias' => (int) $total]);
        if ($variantId !== null) {
            $variantTotal = (float) DB::table('existencias_almacen')->where('variante_id', $variantId)->sum('cantidad_fisica');
            abort_if($variantTotal !== floor($variantTotal) || $variantTotal > 4294967295, 422, 'No es posible actualizar la proyección heredada de la variante.');
            DB::table('variantes_productos')->where('id', $variantId)->update(['existencias' => (int) $variantTotal]);
        }

        return MovimientoInventario::create([
            'producto_id' => $product->id,
            'usuario_id' => $user->id,
            'tipo_movimiento' => $movementType,
            'cantidad' => $movementType === 'ajuste' ? $nextStock - $previousStock : $quantity,
            'notas' => $notes,
            'creado_en' => now(),
            'variante_id' => $variantId,
            ...$location,
        ]);
    }

    public function changeLockedProductInWarehouse(
        Producto $product,
        ?int $variantId,
        string $movementType,
        int $quantity,
        string $notes,
        User $user,
        int $companyId,
        int $siteId,
        int $warehouseId,
        ?string $documentType = null,
        ?string $documentId = null,
        bool $createMissingBalance = false,
    ): MovimientoInventario {
        abort_unless(DB::transactionLevel() > 0, 503, 'El movimiento de inventario requiere una transaccion.');
        abort_if($quantity < 0 || ($movementType !== 'ajuste' && $quantity === 0), 422, 'La cantidad del movimiento no es valida.');
        abort_unless((int) $product->empresa_id === $companyId, 403);
        $warehouseIsValid = DB::table('almacenes')
            ->join('sedes', 'sedes.id', '=', 'almacenes.sede_id')
            ->where('almacenes.id', $warehouseId)
            ->where('almacenes.sede_id', $siteId)
            ->where('sedes.empresa_id', $companyId)
            ->where('almacenes.activo', true)
            ->where('sedes.activa', true)
            ->exists();
        abort_unless($warehouseIsValid, 422, 'El almacen no pertenece a una sede activa de la empresa.');

        $balanceQuery = DB::table('existencias_almacen')
            ->where('empresa_id', $companyId)
            ->where('sede_id', $siteId)
            ->where('almacen_id', $warehouseId)
            ->where('producto_id', $product->id);
        if ($variantId === null) {
            $balanceQuery->whereNull('variante_id');
        } else {
            $balanceQuery->where('variante_id', $variantId);
        }
        $balance = $balanceQuery->lockForUpdate()->first(['id', 'cantidad_fisica', 'cantidad_reservada']);
        if ($balance === null && $createMissingBalance && $movementType === 'entrada') {
            DB::table('existencias_almacen')->insertOrIgnore([
                'almacen_id' => $warehouseId, 'variante_id' => $variantId, 'producto_id' => $product->id,
                'empresa_id' => $companyId, 'sede_id' => $siteId, 'cantidad_fisica' => 0, 'cantidad_reservada' => 0,
            ]);
            $balanceQuery = DB::table('existencias_almacen')->where('empresa_id', $companyId)
                ->where('sede_id', $siteId)->where('almacen_id', $warehouseId)->where('producto_id', $product->id);
            if ($variantId === null) {
                $balanceQuery->whereNull('variante_id');
            } else {
                $balanceQuery->where('variante_id', $variantId);
            }
            $balance = $balanceQuery->lockForUpdate()->first(['id', 'cantidad_fisica', 'cantidad_reservada']);
        }
        abort_unless($balance !== null, 409, 'No existe saldo para el producto o variante en el almacen.');
        abort_if((float) $balance->cantidad_fisica !== floor((float) $balance->cantidad_fisica), 422, 'El formulario no admite existencias fraccionarias.');

        $previousStock = (int) $balance->cantidad_fisica;
        $nextStock = match ($movementType) {
            'entrada' => $previousStock + $quantity,
            'salida' => $previousStock - $quantity,
            'ajuste' => $quantity,
            default => throw new \InvalidArgumentException('Tipo de movimiento invalido.'),
        };
        abort_if($nextStock < 0, 422, 'La salida supera el stock disponible.');
        abort_if((float) $balance->cantidad_reservada > $nextStock, 422, 'El movimiento dejaria reservas sin respaldo.');

        DB::table('existencias_almacen')->where('id', $balance->id)->update(['cantidad_fisica' => $nextStock]);
        $total = (float) DB::table('existencias_almacen')->where('producto_id', $product->id)->where('empresa_id', $companyId)->sum('cantidad_fisica');
        abort_if($total !== floor($total) || $total > 4294967295, 422, 'No es posible actualizar la proyeccion heredada de existencias.');
        $product->update(['existencias' => (int) $total]);
        if ($variantId !== null) {
            $variantTotal = (float) DB::table('existencias_almacen')->where('variante_id', $variantId)->sum('cantidad_fisica');
            abort_if($variantTotal !== floor($variantTotal) || $variantTotal > 4294967295, 422, 'No es posible actualizar la proyeccion heredada de la variante.');
            DB::table('variantes_productos')->where('id', $variantId)->update(['existencias' => (int) $variantTotal]);
        }

        return MovimientoInventario::query()->create([
            'producto_id' => $product->id,
            'usuario_id' => $user->id,
            'tipo_movimiento' => $movementType,
            'cantidad' => $movementType === 'ajuste' ? $nextStock - $previousStock : $quantity,
            'notas' => $notes,
            'creado_en' => now(),
            'empresa_id' => $companyId,
            'sede_id' => $siteId,
            'almacen_id' => $warehouseId,
            'variante_id' => $variantId,
            'documento_tipo' => $documentType,
            'documento_id' => $documentId,
        ]);
    }
}
