<?php

use App\Http\Middleware\AsegurarRol;
use App\Http\Middleware\EstablecerContextoAuditoria;
use App\Http\Middleware\RegistrarSesionUsuario;
use App\Http\Middleware\VerificarCuentaActiva;
use App\Http\Middleware\VerificarPermiso;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->web(append: [EstablecerContextoAuditoria::class]);

        $middleware->alias([
            'role' => AsegurarRol::class,
            'permiso' => VerificarPermiso::class,
            'sesion.usuario' => RegistrarSesionUsuario::class,
            'cuenta.activa' => VerificarCuentaActiva::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(
            fn (Request $request) => $request->is('api/*') || $request->expectsJson(),
        );
    })->create();
